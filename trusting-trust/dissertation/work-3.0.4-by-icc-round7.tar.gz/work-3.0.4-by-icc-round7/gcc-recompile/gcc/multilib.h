static const char *const multilib_raw[] = {
". ;",
NULL
};

static const char *const multilib_matches_raw[] = {
NULL
};

static const char *multilib_extra = "";

static const char *const multilib_exclusions_raw[] = {
NULL
};
