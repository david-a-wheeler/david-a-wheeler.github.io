/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-3.0.4/configure --enable-languages=c";
static const char thread_model[] = "single";
