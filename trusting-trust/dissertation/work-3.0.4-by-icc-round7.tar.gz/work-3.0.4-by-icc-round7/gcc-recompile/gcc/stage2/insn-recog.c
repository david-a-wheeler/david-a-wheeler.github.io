/* Generated automatically by the program `genrecog' from the target
   machine description file.  */

#include "config.h"
#include "system.h"
#include "rtl.h"
#include "tm_p.h"
#include "function.h"
#include "insn-config.h"
#include "recog.h"
#include "real.h"
#include "output.h"
#include "flags.h"
#include "hard-reg-set.h"
#include "resource.h"



/* `recog' contains a decision tree that recognizes whether the rtx
   X0 is a valid instruction.

   recog returns -1 if the rtx is not valid.  If the rtx is valid, recog
   returns a nonnegative number which is the insn code number for the
   pattern that matched.  This is the same as the order in the machine
   description of the entry that matched.  This number can be used as an
   index into `insn_data' and other tables.

   The third argument to recog is an optional pointer to an int.  If
   present, recog will accept a pattern if it matches except for missing
   CLOBBER expressions at the end.  In that case, the value pointed to by
   the optional pointer will be set to the number of CLOBBERs that need
   to be added (it should be initialized to zero by the caller).  If it
   is set nonzero, the caller should allocate a PARALLEL of the
   appropriate size, copy the initial entries, and call add_clobbers
   (found in insn-emit.c) to fill in the CLOBBERs.


   The function split_insns returns 0 if the rtl could not
   be split or the split rtl in a SEQUENCE if it can be.

   The function peephole2_insns returns 0 if the rtl could not
   be matched. If there was a match, the new rtl is returned in a SEQUENCE,
   and LAST_INSN will point to the last recognized insn in the old sequence.
*/


extern rtx gen_split_554 PARAMS ((rtx *));
extern rtx gen_split_562 PARAMS ((rtx *));
extern rtx gen_split_563 PARAMS ((rtx *));
extern rtx gen_split_565 PARAMS ((rtx *));
extern rtx gen_split_566 PARAMS ((rtx *));
extern rtx gen_split_567 PARAMS ((rtx *));
extern rtx gen_split_569 PARAMS ((rtx *));
extern rtx gen_split_570 PARAMS ((rtx *));
extern rtx gen_split_571 PARAMS ((rtx *));
extern rtx gen_split_572 PARAMS ((rtx *));
extern rtx gen_split_575 PARAMS ((rtx *));
extern rtx gen_split_576 PARAMS ((rtx *));
extern rtx gen_split_577 PARAMS ((rtx *));
extern rtx gen_split_578 PARAMS ((rtx *));
extern rtx gen_split_579 PARAMS ((rtx *));
extern rtx gen_split_581 PARAMS ((rtx *));
extern rtx gen_split_583 PARAMS ((rtx *));
extern rtx gen_split_584 PARAMS ((rtx *));
extern rtx gen_split_585 PARAMS ((rtx *));
extern rtx gen_split_587 PARAMS ((rtx *));
extern rtx gen_split_588 PARAMS ((rtx *));
extern rtx gen_split_589 PARAMS ((rtx *));
extern rtx gen_split_590 PARAMS ((rtx *));
extern rtx gen_split_591 PARAMS ((rtx *));
extern rtx gen_split_592 PARAMS ((rtx *));
extern rtx gen_split_593 PARAMS ((rtx *));
extern rtx gen_split_594 PARAMS ((rtx *));
extern rtx gen_split_595 PARAMS ((rtx *));
extern rtx gen_split_596 PARAMS ((rtx *));
extern rtx gen_split_597 PARAMS ((rtx *));
extern rtx gen_split_598 PARAMS ((rtx *));
extern rtx gen_split_599 PARAMS ((rtx *));
extern rtx gen_split_606 PARAMS ((rtx *));
extern rtx gen_split_607 PARAMS ((rtx *));
extern rtx gen_split_609 PARAMS ((rtx *));
extern rtx gen_split_610 PARAMS ((rtx *));
extern rtx gen_split_612 PARAMS ((rtx *));
extern rtx gen_split_613 PARAMS ((rtx *));
extern rtx gen_split_615 PARAMS ((rtx *));
extern rtx gen_split_616 PARAMS ((rtx *));
extern rtx gen_split_618 PARAMS ((rtx *));
extern rtx gen_split_619 PARAMS ((rtx *));
extern rtx gen_split_624 PARAMS ((rtx *));
extern rtx gen_split_629 PARAMS ((rtx *));
extern rtx gen_split_634 PARAMS ((rtx *));
extern rtx gen_split_635 PARAMS ((rtx *));
extern rtx gen_split_636 PARAMS ((rtx *));
extern rtx gen_split_638 PARAMS ((rtx *));
extern rtx gen_split_639 PARAMS ((rtx *));
extern rtx gen_split_640 PARAMS ((rtx *));
extern rtx gen_split_641 PARAMS ((rtx *));
extern rtx gen_split_648 PARAMS ((rtx *));
extern rtx gen_split_667 PARAMS ((rtx *));
extern rtx gen_split_668 PARAMS ((rtx *));
extern rtx gen_split_673 PARAMS ((rtx *));
extern rtx gen_split_675 PARAMS ((rtx *));
extern rtx gen_split_676 PARAMS ((rtx *));
extern rtx gen_split_677 PARAMS ((rtx *));
extern rtx gen_split_688 PARAMS ((rtx *));
extern rtx gen_split_693 PARAMS ((rtx *));
extern rtx gen_split_694 PARAMS ((rtx *));
extern rtx gen_split_695 PARAMS ((rtx *));
extern rtx gen_split_697 PARAMS ((rtx *));
extern rtx gen_split_698 PARAMS ((rtx *));
extern rtx gen_split_701 PARAMS ((rtx *));
extern rtx gen_split_702 PARAMS ((rtx *));
extern rtx gen_split_703 PARAMS ((rtx *));
extern rtx gen_split_704 PARAMS ((rtx *));
extern rtx gen_split_706 PARAMS ((rtx *));
extern rtx gen_split_707 PARAMS ((rtx *));
extern rtx gen_split_708 PARAMS ((rtx *));
extern rtx gen_split_710 PARAMS ((rtx *));
extern rtx gen_split_711 PARAMS ((rtx *));
extern rtx gen_split_714 PARAMS ((rtx *));
extern rtx gen_split_715 PARAMS ((rtx *));
extern rtx gen_split_716 PARAMS ((rtx *));
extern rtx gen_split_717 PARAMS ((rtx *));
extern rtx gen_split_719 PARAMS ((rtx *));
extern rtx gen_split_721 PARAMS ((rtx *));
extern rtx gen_split_723 PARAMS ((rtx *));
extern rtx gen_split_725 PARAMS ((rtx *));
extern rtx gen_split_726 PARAMS ((rtx *));
extern rtx gen_split_730 PARAMS ((rtx *));
extern rtx gen_split_734 PARAMS ((rtx *));
extern rtx gen_split_735 PARAMS ((rtx *));
extern rtx gen_split_741 PARAMS ((rtx *));
extern rtx gen_split_742 PARAMS ((rtx *));
extern rtx gen_split_791 PARAMS ((rtx *));
extern rtx gen_split_792 PARAMS ((rtx *));
extern rtx gen_split_795 PARAMS ((rtx *));
extern rtx gen_split_796 PARAMS ((rtx *));
extern rtx gen_peephole2_797 PARAMS ((rtx, rtx *));
extern rtx gen_split_808 PARAMS ((rtx *));
extern rtx gen_split_810 PARAMS ((rtx *));
extern rtx gen_split_811 PARAMS ((rtx *));
extern rtx gen_peephole2_823 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_824 PARAMS ((rtx, rtx *));
extern rtx gen_split_833 PARAMS ((rtx *));
extern rtx gen_split_834 PARAMS ((rtx *));
extern rtx gen_split_835 PARAMS ((rtx *));
extern rtx gen_split_836 PARAMS ((rtx *));
extern rtx gen_split_837 PARAMS ((rtx *));
extern rtx gen_split_838 PARAMS ((rtx *));
extern rtx gen_peephole2_839 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_840 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_841 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_842 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_843 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_844 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_845 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_846 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_847 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_848 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_849 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_850 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_851 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_852 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_853 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_854 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_855 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_856 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_857 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_858 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_859 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_860 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_861 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_862 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_863 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_864 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_865 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_866 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_867 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_868 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_869 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_870 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_871 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_872 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_873 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_874 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_875 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_876 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_877 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_878 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_879 PARAMS ((rtx, rtx *));
extern rtx gen_peephole2_880 PARAMS ((rtx, rtx *));
extern rtx gen_split_888 PARAMS ((rtx *));
extern rtx gen_split_889 PARAMS ((rtx *));
extern rtx gen_split_890 PARAMS ((rtx *));
extern rtx gen_split_891 PARAMS ((rtx *));
extern rtx gen_split_892 PARAMS ((rtx *));
extern rtx gen_split_893 PARAMS ((rtx *));



static int recog_1 PARAMS ((rtx, rtx, int *));
static int
recog_1 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  switch (GET_CODE (x1))
    {
    case MEM:
      goto L6749;
    case REG:
      goto L6750;
    default:
     break;
   }
 L6685: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L101;
    }
 L6693: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L1027;
    }
 L6709: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L786;
    }
  goto ret0;

 L6749: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L264;
    }
  goto L6693;

 L264: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_no_elim_operand (x1, HImode))
    {
      operands[1] = x1;
      return 37;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L6750: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x1, 0) == 18)
    goto L790;
  goto L6685;

 L790: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 12)
    goto L791;
  x1 = XEXP (x0, 0);
  goto L6685;

 L791: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (memory_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L792;
    }
  x1 = XEXP (x0, 0);
  goto L6685;

 L792: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 114;
    }
  x1 = XEXP (x0, 0);
  goto L6685;

 L101: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode)
    goto L6751;
  x1 = XEXP (x0, 0);
  goto L6693;

 L6751: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case UNSPEC:
      goto L6757;
    case SIGN_EXTRACT:
      goto L360;
    case ZERO_EXTEND:
      goto L515;
    case SIGN_EXTEND:
      goto L596;
    case MULT:
      goto L1431;
    case IF_THEN_ELSE:
      goto L4392;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L6693;

 L6757: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 9)
    goto L102;
  x1 = XEXP (x0, 0);
  goto L6693;

 L102: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  switch (GET_MODE (x2))
    {
    case CCFPmode:
      goto L6758;
    case CCFPUmode:
      goto L6759;
    default:
      break;
    }
 L181: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 18
      && (TARGET_80387))
    {
      return 25;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L6758: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == COMPARE)
    goto L116;
  goto L181;

 L116: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case SFmode:
      goto L6760;
    case DFmode:
      goto L6761;
    case XFmode:
      goto L6762;
    case TFmode:
      goto L6763;
    default:
      break;
    }
 L103: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L104;
    }
  goto L181;

 L6760: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L117;
    }
  goto L103;

 L117: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[2] = x3;
      goto L118;
    }
  x3 = XEXP (x2, 0);
  goto L103;

 L118: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 15;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  x3 = XEXP (x2, 0);
  goto L103;

 L6761: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L130;
    }
  goto L103;

 L130: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, DFmode))
    {
      operands[2] = x3;
      goto L131;
    }
  x3 = XEXP (x2, 0);
  goto L103;

 L131: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 17;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  x3 = XEXP (x2, 0);
  goto L103;

 L6762: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L149;
    }
  goto L103;

 L149: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, XFmode))
    {
      operands[2] = x3;
      goto L150;
    }
  x3 = XEXP (x2, 0);
  goto L103;

 L150: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 20;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  x3 = XEXP (x2, 0);
  goto L103;

 L6763: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L156;
    }
  goto L103;

 L156: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, TFmode))
    {
      operands[2] = x3;
      goto L157;
    }
  x3 = XEXP (x2, 0);
  goto L103;

 L157: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 21;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  x3 = XEXP (x2, 0);
  goto L103;

 L104: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const0_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L105;
    }
  goto L181;

 L105: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2])))
    {
      return 13;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  goto L181;

 L6759: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == COMPARE)
    goto L168;
  goto L181;

 L168: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L169;
    }
  goto L181;

 L169: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L170;
    }
  goto L181;

 L170: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2])))
    {
      return 23;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  goto L181;

 L360: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L361;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L361: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    goto L362;
  x1 = XEXP (x0, 0);
  goto L6693;

 L362: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    {
      return 51;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L515: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L516;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L516: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_ZERO_EXTEND_WITH_AND && !optimize_size)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 79;
    }
 L528: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_ZERO_EXTEND_WITH_AND || optimize_size)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 80;
    }
 L533: ATTRIBUTE_UNUSED_LABEL
  if (((!TARGET_ZERO_EXTEND_WITH_AND || optimize_size) && reload_completed))
    {
      return 81;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L596: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      return 88;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1431: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == HImode)
    goto L6765;
  x1 = XEXP (x0, 0);
  goto L6693;

 L6765: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L1462;
    case SIGN_EXTEND:
      goto L1480;
    case SUBREG:
    case REG:
    case MEM:
      goto L6764;
    default:
      x1 = XEXP (x0, 0);
      goto L6693;
   }
 L6764: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L1432;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1462: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1463;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1463: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ZERO_EXTEND)
    goto L1464;
  x1 = XEXP (x0, 0);
  goto L6693;

 L1464: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1465;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1465: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_QIMODE_MATH)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 168;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1480: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1481;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1481: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == SIGN_EXTEND)
    goto L1482;
  x1 = XEXP (x0, 0);
  goto L6693;

 L1482: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1483;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1483: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_QIMODE_MATH)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 169;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1432: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L1433;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1433: ATTRIBUTE_UNUSED_LABEL
  if ((GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 166;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L4392: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (ix86_comparison_operator (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L4393;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L4393: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L4394;
  x1 = XEXP (x0, 0);
  goto L6693;

 L4394: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4395;
  x1 = XEXP (x0, 0);
  goto L6693;

 L4395: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L4396;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L4396: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L4397;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L4397: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE
   && (GET_CODE (operands[2]) != MEM || GET_CODE (operands[3]) != MEM)))
    {
      return 406;
    }
  x1 = XEXP (x0, 0);
  goto L6693;

 L1027: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode)
    goto L6767;
 L277: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, HImode))
    {
      operands[1] = x1;
      goto L278;
    }
  x1 = XEXP (x0, 0);
  goto L6709;

 L6767: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case PLUS:
      goto L1028;
    case MINUS:
      goto L1341;
    case AND:
      goto L1881;
    case IOR:
      goto L2117;
    case XOR:
      goto L2282;
    case NEG:
      goto L2459;
    case NOT:
      goto L2710;
    case ASHIFT:
      goto L2832;
    case ASHIFTRT:
      goto L3037;
    case LSHIFTRT:
      goto L3229;
    case ROTATE:
      goto L3365;
    case ROTATERT:
      goto L3449;
    default:
     break;
   }
  goto L277;

 L1028: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L1029;
    }
  goto L277;

 L1029: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L1030;
    }
  goto L277;

 L1030: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (PLUS, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 140;
    }
 L1044: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (PLUS, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 141;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L1341: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L1342;
    }
  goto L277;

 L1342: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L1343;
    }
  goto L277;

 L1343: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (MINUS, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 159;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L1881: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L1882;
    }
  goto L277;

 L1882: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L1883;
    }
  goto L277;

 L1883: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (AND, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 192;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L2117: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L2118;
    }
  goto L277;

 L2118: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L2119;
    }
  goto L277;

 L2119: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (IOR, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 205;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L2282: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L2283;
    }
  goto L277;

 L2283: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L2284;
    }
  goto L277;

 L2284: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (XOR, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 216;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L2459: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L2460;
    }
  goto L277;

 L2460: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_unary_operator_ok (NEG, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 227;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L2710: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L2711;
    }
  goto L277;

 L2711: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_unary_operator_ok (NOT, HImode, operands)))
    {
      return 259;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L2832: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L2833;
    }
  goto L277;

 L2833: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2834;
    }
  goto L277;

 L2834: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (ASHIFT, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 268;
    }
 L2848: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (ASHIFT, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 269;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L3037: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L3038;
    }
  goto L277;

 L3038: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3039;
    }
 L3052: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3053;
    }
  goto L277;

 L3039: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ASHIFTRT, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 282;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3052;

 L3053: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ASHIFTRT, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 283;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L3229: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L3230;
    }
  goto L277;

 L3230: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3231;
    }
 L3244: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3245;
    }
  goto L277;

 L3231: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (LSHIFTRT, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 296;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3244;

 L3245: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (LSHIFTRT, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 297;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L3365: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L3366;
    }
  goto L277;

 L3366: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3367;
    }
 L3380: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3381;
    }
  goto L277;

 L3367: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATE, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 306;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3380;

 L3381: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATE, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 307;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L3449: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L3450;
    }
  goto L277;

 L3450: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3451;
    }
 L3464: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3465;
    }
  goto L277;

 L3451: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATERT, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 312;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3464;

 L3465: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATERT, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 313;
    }
  x1 = XEXP (x0, 1);
  goto L277;

 L278: ATTRIBUTE_UNUSED_LABEL
  if ((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM))
    {
      return 39;
    }
  x1 = XEXP (x0, 0);
  goto L6709;

 L786: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 11)
    goto L787;
  goto ret0;

 L787: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18
      && (TARGET_80387))
    {
      return 113;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_2 PARAMS ((rtx, rtx, int *));
static int
recog_2 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  switch (GET_CODE (x1))
    {
    case MEM:
      goto L6783;
    case ZERO_EXTRACT:
      goto L384;
    case SUBREG:
    case REG:
      goto L6690;
    default:
      goto L6691;
   }
 L6690: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L353;
    }
 L6691: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L881;
    }
 L6715: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L1537;
    }
 L6719: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 19)
    goto L4106;
 L6716: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L950;
    }
  goto ret0;

 L6783: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L200;
    }
  goto L6691;

 L200: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_no_elim_operand (x1, SImode))
    {
      operands[1] = x1;
      return 29;
    }
  x1 = XEXP (x0, 0);
  goto L6691;

 L384: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (ext_register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L385;
    }
  goto ret0;

 L385: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    goto L386;
  goto ret0;

 L386: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    goto L387;
  goto ret0;

 L387: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode)
    goto L6785;
  goto ret0;

 L6785: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case AND:
      goto L394;
    case PLUS:
      goto L1219;
    case XOR:
      goto L2353;
    case SUBREG:
    case REG:
    case MEM:
      goto L6784;
    default:
      goto ret0;
   }
 L6784: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, SImode))
    {
      operands[1] = x1;
      return 55;
    }
  goto ret0;

 L394: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode)
    goto L6788;
  goto ret0;

 L6788: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case LSHIFTRT:
      goto L395;
    case ZERO_EXTRACT:
      goto L1975;
    default:
     break;
   }
  goto ret0;

 L395: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L396;
    }
  goto ret0;

 L396: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L397;
  goto ret0;

 L397: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 255)
    {
      return 56;
    }
  goto ret0;

 L1975: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L1976;
    }
  goto ret0;

 L1976: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L1977;
  goto ret0;

 L1977: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L2027;
  goto ret0;

 L2027: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L6790;
 L1978: ATTRIBUTE_UNUSED_LABEL
  if (const_int_operand (x2, VOIDmode))
    {
      operands[2] = x2;
      goto L1979;
    }
  goto ret0;

 L6790: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L2028;
    case ZERO_EXTRACT:
      goto L2058;
    default:
     break;
   }
  goto L1978;

 L2028: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2029;
    }
  goto L1978;

 L2029: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 200;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L1978;

 L2058: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L2059;
    }
  goto L1978;

 L2059: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L2060;
  goto L1978;

 L2060: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 201;
    }
  goto L1978;

 L1979: ATTRIBUTE_UNUSED_LABEL
  if (((unsigned HOST_WIDE_INT)INTVAL (operands[2]) <= 0xff)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 198;
    }
  goto ret0;

 L1219: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTRACT)
    goto L1220;
  goto ret0;

 L1220: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L1221;
    }
  goto ret0;

 L1221: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L1222;
  goto ret0;

 L1222: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L1252;
  goto ret0;

 L1252: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTRACT)
    goto L1253;
  if (general_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L1224;
    }
  goto ret0;

 L1253: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L1254;
    }
  goto ret0;

 L1254: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L1255;
  goto ret0;

 L1255: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 153;
    }
  goto ret0;

 L1224: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 152;
    }
  goto ret0;

 L2353: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTRACT)
    goto L2354;
  goto ret0;

 L2354: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L2355;
    }
  goto ret0;

 L2355: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L2356;
  goto ret0;

 L2356: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L2357;
  goto ret0;

 L2357: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTRACT)
    goto L2358;
  goto ret0;

 L2358: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L2359;
    }
  goto ret0;

 L2359: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L2360;
  goto ret0;

 L2360: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 220;
    }
  goto ret0;

 L353: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode)
    goto L6792;
 L239: ATTRIBUTE_UNUSED_LABEL
  if (const0_operand (x1, SImode))
    {
      operands[1] = x1;
      goto L240;
    }
 L249: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x1, SImode))
    {
      operands[1] = x1;
      goto L250;
    }
  x1 = XEXP (x0, 0);
  goto L6691;

 L6792: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case SIGN_EXTRACT:
      goto L354;
    case ZERO_EXTRACT:
      goto L372;
    case ZERO_EXTEND:
      goto L498;
    case SIGN_EXTEND:
      goto L592;
    default:
     break;
   }
  goto L239;

 L354: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L355;
    }
  goto L239;

 L355: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    goto L356;
  goto L239;

 L356: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    {
      return 50;
    }
  goto L239;

 L372: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (ext_register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L373;
    }
  goto L239;

 L373: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    goto L374;
  goto L239;

 L374: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    {
      return 53;
    }
  goto L239;

 L498: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L6796;
    case QImode:
      goto L6798;
    default:
      break;
    }
  goto L239;

 L6796: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L499;
    }
 L6797: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L504;
    }
  goto L239;

 L499: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_ZERO_EXTEND_WITH_AND && !optimize_size)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 77;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L6797;

 L504: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_ZERO_EXTEND_WITH_AND || optimize_size))
    {
      return 78;
    }
  x1 = XEXP (x0, 1);
  goto L239;

 L6798: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L545;
    }
  goto L239;

 L545: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_ZERO_EXTEND_WITH_AND && !optimize_size)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 82;
    }
 L557: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_ZERO_EXTEND_WITH_AND || optimize_size)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 83;
    }
 L562: ATTRIBUTE_UNUSED_LABEL
  if (((!TARGET_ZERO_EXTEND_WITH_AND || optimize_size) && reload_completed))
    {
      return 84;
    }
  x1 = XEXP (x0, 1);
  goto L239;

 L592: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L6799;
    case QImode:
      goto L6800;
    default:
      break;
    }
  goto L239;

 L6799: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      return 87;
    }
  goto L239;

 L6800: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      return 89;
    }
  goto L239;

 L240: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && (!TARGET_USE_MOV0 || optimize_size))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 33;
    }
  x1 = XEXP (x0, 1);
  goto L249;

 L250: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && GET_CODE (operands[1]) == CONST_INT
   && INTVAL (operands[1]) == -1
   && (TARGET_PENTIUM || optimize_size))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 34;
    }
  x1 = XEXP (x0, 0);
  goto L6691;

 L881: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode
      && GET_CODE (x1) == PLUS)
    goto L882;
  if (general_operand (x1, SImode))
    {
      operands[1] = x1;
      goto L254;
    }
  x1 = XEXP (x0, 0);
  goto L6715;

 L882: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L883;
  x1 = XEXP (x0, 0);
  goto L6715;

 L883: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == LTU)
    goto L884;
  x1 = XEXP (x0, 0);
  goto L6715;

 L884: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == CCmode
      && GET_CODE (x4) == REG
      && XINT (x4, 0) == 17)
    goto L885;
  x1 = XEXP (x0, 0);
  goto L6715;

 L885: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L886;
  x1 = XEXP (x0, 0);
  goto L6715;

 L886: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L887;
    }
  x1 = XEXP (x0, 0);
  goto L6715;

 L887: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L888;
    }
  x1 = XEXP (x0, 0);
  goto L6715;

 L888: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (PLUS, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 128;
    }
  x1 = XEXP (x0, 0);
  goto L6715;

 L254: ATTRIBUTE_UNUSED_LABEL
  if ((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM))
    {
      return 35;
    }
  x1 = XEXP (x0, 0);
  goto L6715;

 L1537: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode)
    goto L6801;
 L913: ATTRIBUTE_UNUSED_LABEL
  if (address_operand (x1, SImode))
    {
      operands[1] = x1;
      return 131;
    }
 L1416: ATTRIBUTE_UNUSED_LABEL
  if (GET_MODE (x1) == SImode
      && GET_CODE (x1) == MULT)
    goto L1417;
  x1 = XEXP (x0, 0);
  goto L6719;

 L6801: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case TRUNCATE:
      goto L1538;
    case UNSPEC_VOLATILE:
      goto L6805;
    case IF_THEN_ELSE:
      goto L4375;
    default:
     break;
   }
  goto L913;

 L1538: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L1539;
  goto L913;

 L1539: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == DImode
      && GET_CODE (x3) == MULT)
    goto L1540;
  goto L913;

 L1540: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == DImode)
    goto L6807;
  goto L913;

 L6807: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x4))
    {
    case ZERO_EXTEND:
      goto L1541;
    case SIGN_EXTEND:
      goto L1566;
    default:
     break;
   }
  goto L913;

 L1541: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, SImode))
    {
      operands[1] = x5;
      goto L1542;
    }
  goto L913;

 L1542: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == DImode
      && GET_CODE (x4) == ZERO_EXTEND)
    goto L1543;
  goto L913;

 L1543: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (nonimmediate_operand (x5, SImode))
    {
      operands[2] = x5;
      goto L1544;
    }
  goto L913;

 L1544: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 32
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 172;
    }
  goto L913;

 L1566: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, SImode))
    {
      operands[1] = x5;
      goto L1567;
    }
  goto L913;

 L1567: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == DImode
      && GET_CODE (x4) == SIGN_EXTEND)
    goto L1568;
  goto L913;

 L1568: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (nonimmediate_operand (x5, SImode))
    {
      operands[2] = x5;
      goto L1569;
    }
  goto L913;

 L1569: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 32
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 173;
    }
  goto L913;

 L6805: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1)
    goto L6809;
  goto L913;

 L6809: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x1, 1))
    {
    case 1:
      goto L3790;
    case 2:
      goto L3801;
    default:
      break;
    }
  goto L913;

 L3790: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L3791;
  goto L913;

 L3791: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L3792;
  goto L913;

 L3792: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == PLUS)
    goto L3793;
  goto L913;

 L3793: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (symbolic_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L3794;
    }
  goto L913;

 L3794: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == SImode
      && GET_CODE (x4) == MINUS)
    goto L3795;
  goto L913;

 L3795: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (GET_CODE (x5) == PC)
    goto L3796;
  goto L913;

 L3796: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  operands[2] = x5;
  goto L3797;

 L3797: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 340;
    }
  x1 = XEXP (x0, 1);
  goto L913;

 L3801: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L3802;
  goto L913;

 L3802: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == PC)
    goto L3803;
  goto L913;

 L3803: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  operands[1] = x3;
  return 341;

 L4375: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == LTU)
    goto L4376;
 L4383: ATTRIBUTE_UNUSED_LABEL
  if (ix86_comparison_operator (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L4384;
    }
  goto L913;

 L4376: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == CCmode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L4377;
  goto L4383;

 L4377: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4378;
  goto L4383;

 L4378: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == -1)
    goto L4379;
  x2 = XEXP (x1, 0);
  goto L4383;

 L4379: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 404;
    }
  x2 = XEXP (x1, 0);
  goto L4383;

 L4384: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L4385;
  goto L913;

 L4385: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4386;
  goto L913;

 L4386: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L4387;
    }
  goto L913;

 L4387: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L4388;
    }
  goto L913;

 L4388: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE
   && (GET_CODE (operands[2]) != MEM || GET_CODE (operands[3]) != MEM)))
    {
      return 405;
    }
  x1 = XEXP (x0, 1);
  goto L913;

 L1417: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L1418;
    }
  x1 = XEXP (x0, 0);
  goto L6719;

 L1418: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L1419;
    }
  x1 = XEXP (x0, 0);
  goto L6719;

 L1419: ATTRIBUTE_UNUSED_LABEL
  if ((GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 165;
    }
  x1 = XEXP (x0, 0);
  goto L6719;

 L4106: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 0)
    {
      return 390;
    }
  x1 = XEXP (x0, 0);
  goto L6716;

 L950: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode)
    goto L6811;
  goto ret0;

 L6811: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case PLUS:
      goto L951;
    case MINUS:
      goto L1285;
    case AND:
      goto L1854;
    case IOR:
      goto L2072;
    case XOR:
      goto L2237;
    case NEG:
      goto L2436;
    case NOT:
      goto L2694;
    case ASHIFT:
      goto L2805;
    case ASHIFTRT:
      goto L2969;
    case LSHIFTRT:
      goto L3175;
    case ROTATE:
      goto L3337;
    case ROTATERT:
      goto L3421;
    default:
     break;
   }
  goto ret0;

 L951: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L952;
    }
  goto ret0;

 L952: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L953;
    }
  goto ret0;

 L953: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (PLUS, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 135;
    }
  goto ret0;

 L1285: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L1286;
    }
  goto ret0;

 L1286: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L1287;
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L1305;
    }
  goto ret0;

 L1287: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == LTU)
    goto L1288;
  goto ret0;

 L1288: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == CCmode
      && GET_CODE (x4) == REG
      && XINT (x4, 0) == 17)
    goto L1289;
  goto ret0;

 L1289: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L1290;
  goto ret0;

 L1290: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1291;
    }
  goto ret0;

 L1291: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (MINUS, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 155;
    }
  goto ret0;

 L1305: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (MINUS, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 156;
    }
  goto ret0;

 L1854: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L1855;
    }
  goto ret0;

 L1855: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L1856;
    }
  goto ret0;

 L1856: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (AND, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 190;
    }
  goto ret0;

 L2072: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode)
    goto L6824;
  goto ret0;

 L6824: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ASHIFT:
      goto L2787;
    case ASHIFTRT:
      goto L2951;
    case SUBREG:
    case REG:
    case MEM:
      goto L6823;
    default:
      goto ret0;
   }
 L6823: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L2073;
    }
  goto ret0;

 L2787: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L2788;
  goto ret0;

 L2788: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2789;
    }
  goto ret0;

 L2789: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L2790;
  goto ret0;

 L2790: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2791;
    }
  goto ret0;

 L2791: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == QImode
      && GET_CODE (x3) == MINUS)
    goto L2792;
  goto ret0;

 L2792: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 32)
    goto L2793;
  goto ret0;

 L2793: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (rtx_equal_p (x4, operands[2])
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 265;
    }
  goto ret0;

 L2951: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L2952;
  goto ret0;

 L2952: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2953;
    }
  goto ret0;

 L2953: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ASHIFT)
    goto L2954;
  goto ret0;

 L2954: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2955;
    }
  goto ret0;

 L2955: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == QImode
      && GET_CODE (x3) == MINUS)
    goto L2956;
  goto ret0;

 L2956: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 32)
    goto L2957;
  goto ret0;

 L2957: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (rtx_equal_p (x4, operands[2])
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 276;
    }
  goto ret0;

 L2073: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L2074;
    }
  goto ret0;

 L2074: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (IOR, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 202;
    }
  goto ret0;

 L2237: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L2238;
    }
  goto ret0;

 L2238: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L2239;
    }
  goto ret0;

 L2239: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (XOR, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 213;
    }
  goto ret0;

 L2436: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L2437;
    }
  goto ret0;

 L2437: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_unary_operator_ok (NEG, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 225;
    }
  goto ret0;

 L2694: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L2695;
    }
  goto ret0;

 L2695: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_unary_operator_ok (NOT, SImode, operands)))
    {
      return 257;
    }
  goto ret0;

 L2805: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L2806;
    }
  goto ret0;

 L2806: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2807;
    }
  goto ret0;

 L2807: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ASHIFT, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 266;
    }
  goto ret0;

 L2969: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L2970;
    }
  goto ret0;

 L2970: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT)
    goto L6826;
 L2998: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2999;
    }
  goto ret0;

 L6826: ATTRIBUTE_UNUSED_LABEL
  if (const_int_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L2971;
    }
 L6827: ATTRIBUTE_UNUSED_LABEL
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2985;
    }
  goto L2998;

 L2971: ATTRIBUTE_UNUSED_LABEL
  if ((INTVAL (operands[2]) == 31 && (TARGET_USE_CLTD || optimize_size)
   && ix86_binary_operator_ok (ASHIFTRT, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 277;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L6827;

 L2985: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ASHIFTRT, SImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 278;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L2998;

 L2999: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ASHIFTRT, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 279;
    }
  goto ret0;

 L3175: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L3176;
    }
  goto ret0;

 L3176: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3177;
    }
 L3190: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3191;
    }
  goto ret0;

 L3177: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (LSHIFTRT, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 292;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3190;

 L3191: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (LSHIFTRT, HImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 293;
    }
  goto ret0;

 L3337: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L3338;
    }
  goto ret0;

 L3338: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3339;
    }
 L3352: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3353;
    }
  goto ret0;

 L3339: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATE, SImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 304;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3352;

 L3353: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATE, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 305;
    }
  goto ret0;

 L3421: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L3422;
    }
  goto ret0;

 L3422: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3423;
    }
 L3436: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3437;
    }
  goto ret0;

 L3423: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATERT, SImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 310;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3436;

 L3437: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATERT, SImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 311;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_3 PARAMS ((rtx, rtx, int *));
static int
recog_3 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  if (push_operand (x1, DFmode))
    {
      operands[0] = x1;
      goto L603;
    }
 L6702: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, DFmode))
    {
      operands[0] = x1;
      goto L628;
    }
 L6708: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, DFmode))
    {
      operands[0] = x1;
      goto L700;
    }
 L6712: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, DFmode))
    {
      operands[0] = x1;
      goto L810;
    }
  goto ret0;

 L603: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DFmode
      && GET_CODE (x1) == FLOAT_EXTEND)
    goto L604;
  if (general_no_elim_operand (x1, DFmode))
    {
      operands[1] = x1;
      goto L422;
    }
  x1 = XEXP (x0, 0);
  goto L6702;

 L604: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L605;
    }
  x1 = XEXP (x0, 0);
  goto L6702;

 L605: ATTRIBUTE_UNUSED_LABEL
  if ((0))
    {
      return 90;
    }
  x1 = XEXP (x0, 0);
  goto L6702;

 L422: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_INTEGER_DFMODE_MOVES))
    {
      return 62;
    }
 L426: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_INTEGER_DFMODE_MOVES))
    {
      return 63;
    }
  x1 = XEXP (x0, 0);
  goto L6702;

 L628: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DFmode)
    goto L6881;
 L429: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, DFmode))
    {
      operands[1] = x1;
      goto L430;
    }
  x1 = XEXP (x0, 0);
  goto L6708;

 L6881: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case FLOAT_EXTEND:
      goto L629;
    case NEG:
      goto L2517;
    case ABS:
      goto L2615;
    default:
     break;
   }
  goto L429;

 L629: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L630;
    }
  goto L429;

 L630: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)))
    {
      return 95;
    }
  x1 = XEXP (x0, 1);
  goto L429;

 L2517: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L2518;
    }
  goto L429;

 L2518: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && ix86_unary_operator_ok (NEG, DFmode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 232;
    }
  x1 = XEXP (x0, 1);
  goto L429;

 L2615: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L2616;
    }
  goto L429;

 L2616: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && ix86_unary_operator_ok (ABS, DFmode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 245;
    }
  x1 = XEXP (x0, 1);
  goto L429;

 L430: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && (optimize_size || !TARGET_INTEGER_DFMODE_MOVES)
   && (reload_in_progress || reload_completed
       || GET_CODE (operands[1]) != CONST_DOUBLE
       || memory_operand (operands[0], DFmode))))
    {
      return 64;
    }
 L434: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && !optimize_size && TARGET_INTEGER_DFMODE_MOVES
   && (reload_in_progress || reload_completed
       || GET_CODE (operands[1]) != CONST_DOUBLE
       || memory_operand (operands[0], DFmode))))
    {
      return 65;
    }
  x1 = XEXP (x0, 0);
  goto L6708;

 L700: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DFmode
      && GET_CODE (x1) == FLOAT_TRUNCATE)
    goto L701;
  x1 = XEXP (x0, 0);
  goto L6712;

 L701: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case XFmode:
      goto L6884;
    case TFmode:
      goto L6885;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L6712;

 L6884: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L702;
    }
  x1 = XEXP (x0, 0);
  goto L6712;

 L702: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 107;
    }
  x1 = XEXP (x0, 0);
  goto L6712;

 L6885: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L715;
    }
  x1 = XEXP (x0, 0);
  goto L6712;

 L715: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 109;
    }
  x1 = XEXP (x0, 0);
  goto L6712;

 L810: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DFmode)
    goto L6886;
  goto ret0;

 L6886: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case FLOAT:
      goto L811;
    case NEG:
      goto L2551;
    case ABS:
      goto L2649;
    case SQRT:
      goto L4010;
    case UNSPEC:
      goto L6894;
    case IF_THEN_ELSE:
      goto L4410;
    case PLUS:
    case MINUS:
    case MULT:
    case DIV:
      goto L6889;
    default:
      goto ret0;
   }
 L6889: ATTRIBUTE_UNUSED_LABEL
  if (binary_fp_operator (x1, DFmode))
    {
      operands[3] = x1;
      goto L3837;
    }
  goto ret0;

 L811: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L6896;
    case SImode:
      goto L6897;
    case DImode:
      goto L6898;
    default:
      break;
    }
  goto ret0;

 L6896: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L812;
    }
  goto ret0;

 L812: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 118;
    }
  goto ret0;

 L6897: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L817;
    }
  goto ret0;

 L817: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 119;
    }
  goto ret0;

 L6898: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L822;
    }
  goto ret0;

 L822: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 120;
    }
  goto ret0;

 L2551: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DFmode)
    goto L6900;
  goto ret0;

 L6900: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L2557;
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L2552;
    }
  goto ret0;

 L2557: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L2558;
    }
  goto ret0;

 L2558: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 237;
    }
  goto ret0;

 L2552: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return 236;
    }
  goto ret0;

 L2649: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DFmode)
    goto L6902;
  goto ret0;

 L6902: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L2655;
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L2650;
    }
  goto ret0;

 L2655: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L2656;
    }
  goto ret0;

 L2656: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 250;
    }
  goto ret0;

 L2650: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return 249;
    }
  goto ret0;

 L4010: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DFmode)
    goto L6904;
  goto ret0;

 L6904: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L4016;
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L4011;
    }
  goto ret0;

 L4016: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L4017;
    }
  goto ret0;

 L4017: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387))
    {
      return 373;
    }
  goto ret0;

 L4011: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387
   && (TARGET_IEEE_FP || flag_fast_math) ))
    {
      return 372;
    }
  goto ret0;

 L6894: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1)
    goto L6905;
  goto ret0;

 L6905: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x1, 1))
    {
    case 1:
      goto L4055;
    case 2:
      goto L4081;
    default:
      break;
    }
  goto ret0;

 L4055: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_MODE (x2) == DFmode)
    goto L6908;
  goto ret0;

 L6908: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L4066;
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L4056;
    }
  goto ret0;

 L4066: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L4067;
    }
  goto ret0;

 L4067: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 382;
    }
  goto ret0;

 L4056: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 380;
    }
  goto ret0;

 L4081: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_MODE (x2) == DFmode)
    goto L6910;
  goto ret0;

 L6910: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L4092;
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L4082;
    }
  goto ret0;

 L4092: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L4093;
    }
  goto ret0;

 L4093: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 387;
    }
  goto ret0;

 L4082: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 385;
    }
  goto ret0;

 L4410: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (fcmov_comparison_operator (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L4411;
    }
  goto ret0;

 L4411: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L4412;
  goto ret0;

 L4412: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4413;
  goto ret0;

 L4413: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L4414;
    }
  goto ret0;

 L4414: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (register_operand (x2, DFmode))
    {
      operands[3] = x2;
      goto L4415;
    }
  goto ret0;

 L4415: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE))
    {
      return 408;
    }
  goto ret0;

 L3837: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DFmode)
    goto L6913;
  goto ret0;

 L6913: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT:
      goto L3882;
    case FLOAT_EXTEND:
      goto L3896;
    case SUBREG:
    case REG:
      goto L6911;
    default:
      goto L6912;
   }
 L6911: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L3838;
    }
 L6912: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L3876;
    }
  goto ret0;

 L3882: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L3883;
    }
  goto ret0;

 L3883: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L3884;
    }
  goto ret0;

 L3884: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_USE_FIOP))
    {
      return 353;
    }
  goto ret0;

 L3896: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L3897;
    }
  goto ret0;

 L3897: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L3898;
    }
  goto ret0;

 L3898: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 355;
    }
  goto ret0;

 L3838: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DFmode)
    goto L6916;
  x2 = XEXP (x1, 0);
  goto L6912;

 L6916: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT:
      goto L3890;
    case FLOAT_EXTEND:
      goto L3904;
    case SUBREG:
    case REG:
    case MEM:
      goto L6915;
    default:
      x2 = XEXP (x1, 0);
      goto L6912;
   }
 L6915: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L3839;
    }
  x2 = XEXP (x1, 0);
  goto L6912;

 L3890: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L3891;
    }
  x2 = XEXP (x1, 0);
  goto L6912;

 L3891: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_USE_FIOP))
    {
      return 354;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L6912;

 L3904: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[2] = x3;
      goto L3905;
    }
  x2 = XEXP (x1, 0);
  goto L6912;

 L3905: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 356;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L6912;

 L3839: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && GET_RTX_CLASS (GET_CODE (operands[3])) == 'c'))
    {
      return 346;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L6912;

 L3876: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L3877;
    }
  goto ret0;

 L3877: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && GET_RTX_CLASS (GET_CODE (operands[3])) != 'c'
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 352;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_4 PARAMS ((rtx, rtx, int *));
static int
recog_4 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  if (push_operand (x1, XFmode))
    {
      operands[0] = x1;
      goto L608;
    }
 L6705: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, XFmode))
    {
      operands[0] = x1;
      goto L633;
    }
 L6713: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, XFmode))
    {
      operands[0] = x1;
      goto L825;
    }
  goto ret0;

 L608: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == XFmode
      && GET_CODE (x1) == FLOAT_EXTEND)
    goto L609;
  if (general_no_elim_operand (x1, XFmode))
    {
      operands[1] = x1;
      goto L445;
    }
  x1 = XEXP (x0, 0);
  goto L6705;

 L609: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SFmode:
      goto L6918;
    case DFmode:
      goto L6919;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L6705;

 L6918: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L610;
    }
  x1 = XEXP (x0, 0);
  goto L6705;

 L610: ATTRIBUTE_UNUSED_LABEL
  if ((0))
    {
      return 91;
    }
  x1 = XEXP (x0, 0);
  goto L6705;

 L6919: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L620;
    }
  x1 = XEXP (x0, 0);
  goto L6705;

 L620: ATTRIBUTE_UNUSED_LABEL
  if ((0))
    {
      return 93;
    }
  x1 = XEXP (x0, 0);
  goto L6705;

 L445: ATTRIBUTE_UNUSED_LABEL
  if ((optimize_size))
    {
      return 67;
    }
 L453: ATTRIBUTE_UNUSED_LABEL
  if ((!optimize_size))
    {
      return 69;
    }
  x1 = XEXP (x0, 0);
  goto L6705;

 L633: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == XFmode)
    goto L6920;
 L460: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, XFmode))
    {
      operands[1] = x1;
      goto L461;
    }
  x1 = XEXP (x0, 0);
  goto L6713;

 L6920: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case FLOAT_EXTEND:
      goto L634;
    case NEG:
      goto L2529;
    case ABS:
      goto L2627;
    default:
     break;
   }
  goto L460;

 L634: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SFmode:
      goto L6923;
    case DFmode:
      goto L6924;
    default:
      break;
    }
  goto L460;

 L6923: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L635;
    }
  goto L460;

 L635: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)))
    {
      return 96;
    }
  x1 = XEXP (x0, 1);
  goto L460;

 L6924: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L645;
    }
  goto L460;

 L645: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)))
    {
      return 98;
    }
  x1 = XEXP (x0, 1);
  goto L460;

 L2529: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L2530;
    }
  goto L460;

 L2530: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && ix86_unary_operator_ok (NEG, XFmode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 233;
    }
  x1 = XEXP (x0, 1);
  goto L460;

 L2627: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L2628;
    }
  goto L460;

 L2628: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && ix86_unary_operator_ok (ABS, XFmode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 246;
    }
  x1 = XEXP (x0, 1);
  goto L460;

 L461: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && optimize_size
   && (reload_in_progress || reload_completed
       || GET_CODE (operands[1]) != CONST_DOUBLE
       || memory_operand (operands[0], XFmode))))
    {
      return 71;
    }
 L469: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && !optimize_size
   && (reload_in_progress || reload_completed
       || GET_CODE (operands[1]) != CONST_DOUBLE
       || memory_operand (operands[0], XFmode))))
    {
      return 73;
    }
  x1 = XEXP (x0, 0);
  goto L6713;

 L825: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == XFmode)
    goto L6925;
  goto ret0;

 L6925: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case FLOAT:
      goto L826;
    case NEG:
      goto L2562;
    case ABS:
      goto L2660;
    case SQRT:
      goto L4021;
    case UNSPEC:
      goto L6933;
    case IF_THEN_ELSE:
      goto L4419;
    case PLUS:
    case MINUS:
    case MULT:
    case DIV:
      goto L6928;
    default:
      goto ret0;
   }
 L6928: ATTRIBUTE_UNUSED_LABEL
  if (binary_fp_operator (x1, XFmode))
    {
      operands[3] = x1;
      goto L3843;
    }
  goto ret0;

 L826: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L6935;
    case SImode:
      goto L6936;
    case DImode:
      goto L6937;
    default:
      break;
    }
  goto ret0;

 L6935: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L827;
    }
  goto ret0;

 L827: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 121;
    }
  goto ret0;

 L6936: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L837;
    }
  goto ret0;

 L837: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 123;
    }
  goto ret0;

 L6937: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L847;
    }
  goto ret0;

 L847: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 125;
    }
  goto ret0;

 L2562: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode)
    goto L6939;
  goto ret0;

 L6939: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L2568;
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L2563;
    }
  goto ret0;

 L2568: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L6940;
    case SFmode:
      goto L6941;
    default:
      break;
    }
  goto ret0;

 L6940: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L2569;
    }
  goto ret0;

 L2569: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 239;
    }
  goto ret0;

 L6941: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L2575;
    }
  goto ret0;

 L2575: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 240;
    }
  goto ret0;

 L2563: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return 238;
    }
  goto ret0;

 L2660: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode)
    goto L6943;
  goto ret0;

 L6943: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L2666;
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L2661;
    }
  goto ret0;

 L2666: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L6944;
    case SFmode:
      goto L6945;
    default:
      break;
    }
  goto ret0;

 L6944: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L2667;
    }
  goto ret0;

 L2667: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 252;
    }
  goto ret0;

 L6945: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L2673;
    }
  goto ret0;

 L2673: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 253;
    }
  goto ret0;

 L2661: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return 251;
    }
  goto ret0;

 L4021: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode)
    goto L6947;
  goto ret0;

 L6947: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L4032;
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L4022;
    }
  goto ret0;

 L4032: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L6948;
    case SFmode:
      goto L6949;
    default:
      break;
    }
  goto ret0;

 L6948: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L4033;
    }
  goto ret0;

 L4033: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387))
    {
      return 376;
    }
  goto ret0;

 L6949: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L4045;
    }
  goto ret0;

 L4045: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387))
    {
      return 378;
    }
  goto ret0;

 L4022: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 
   && (TARGET_IEEE_FP || flag_fast_math) ))
    {
      return 374;
    }
  goto ret0;

 L6933: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1)
    goto L6950;
  goto ret0;

 L6950: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x1, 1))
    {
    case 1:
      goto L4071;
    case 2:
      goto L4097;
    default:
      break;
    }
  goto ret0;

 L4071: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L4072;
    }
  goto ret0;

 L4072: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 383;
    }
  goto ret0;

 L4097: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L4098;
    }
  goto ret0;

 L4098: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 388;
    }
  goto ret0;

 L4419: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (fcmov_comparison_operator (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L4420;
    }
  goto ret0;

 L4420: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L4421;
  goto ret0;

 L4421: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4422;
  goto ret0;

 L4422: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, XFmode))
    {
      operands[2] = x2;
      goto L4423;
    }
  goto ret0;

 L4423: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (register_operand (x2, XFmode))
    {
      operands[3] = x2;
      goto L4424;
    }
  goto ret0;

 L4424: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE))
    {
      return 409;
    }
  goto ret0;

 L3843: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode)
    goto L6953;
  goto ret0;

 L6953: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT:
      goto L3922;
    case FLOAT_EXTEND:
      goto L3950;
    case SUBREG:
    case REG:
      goto L6952;
    default:
      goto ret0;
   }
 L6952: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L3844;
    }
  goto ret0;

 L3922: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L3923;
    }
  goto ret0;

 L3923: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, XFmode))
    {
      operands[2] = x2;
      goto L3924;
    }
  goto ret0;

 L3924: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_USE_FIOP))
    {
      return 359;
    }
  goto ret0;

 L3950: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case SFmode:
      goto L6955;
    case DFmode:
      goto L6956;
    default:
      break;
    }
  goto ret0;

 L6955: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L3951;
    }
  goto ret0;

 L3951: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, XFmode))
    {
      operands[2] = x2;
      goto L3952;
    }
  goto ret0;

 L3952: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 363;
    }
  goto ret0;

 L6956: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L3979;
    }
  goto ret0;

 L3979: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, XFmode))
    {
      operands[2] = x2;
      goto L3980;
    }
  goto ret0;

 L3980: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 367;
    }
  goto ret0;

 L3844: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == XFmode)
    goto L6958;
  goto ret0;

 L6958: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT:
      goto L3937;
    case FLOAT_EXTEND:
      goto L3965;
    case SUBREG:
    case REG:
      goto L6957;
    default:
      goto ret0;
   }
 L6957: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, XFmode))
    {
      operands[2] = x2;
      goto L3845;
    }
  goto ret0;

 L3937: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L3938;
    }
  goto ret0;

 L3938: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_USE_FIOP))
    {
      return 361;
    }
  goto ret0;

 L3965: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case SFmode:
      goto L6960;
    case DFmode:
      goto L6961;
    default:
      break;
    }
  goto ret0;

 L6960: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[2] = x3;
      goto L3966;
    }
  goto ret0;

 L3966: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 365;
    }
  goto ret0;

 L6961: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, DFmode))
    {
      operands[2] = x3;
      goto L3994;
    }
  goto ret0;

 L3994: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 369;
    }
  goto ret0;

 L3845: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && GET_RTX_CLASS (GET_CODE (operands[3])) == 'c'))
    {
      return 347;
    }
 L3911: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && GET_RTX_CLASS (GET_CODE (operands[3])) != 'c'))
    {
      return 357;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_5 PARAMS ((rtx, rtx, int *));
static int
recog_5 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  if (push_operand (x1, TFmode))
    {
      operands[0] = x1;
      goto L613;
    }
 L6706: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, TFmode))
    {
      operands[0] = x1;
      goto L638;
    }
 L6714: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, TFmode))
    {
      operands[0] = x1;
      goto L830;
    }
  goto ret0;

 L613: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == TFmode
      && GET_CODE (x1) == FLOAT_EXTEND)
    goto L614;
  if (general_no_elim_operand (x1, TFmode))
    {
      operands[1] = x1;
      goto L449;
    }
  x1 = XEXP (x0, 0);
  goto L6706;

 L614: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SFmode:
      goto L6962;
    case DFmode:
      goto L6963;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L6706;

 L6962: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L615;
    }
  x1 = XEXP (x0, 0);
  goto L6706;

 L615: ATTRIBUTE_UNUSED_LABEL
  if ((0))
    {
      return 92;
    }
  x1 = XEXP (x0, 0);
  goto L6706;

 L6963: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L625;
    }
  x1 = XEXP (x0, 0);
  goto L6706;

 L625: ATTRIBUTE_UNUSED_LABEL
  if ((0))
    {
      return 94;
    }
  x1 = XEXP (x0, 0);
  goto L6706;

 L449: ATTRIBUTE_UNUSED_LABEL
  if ((optimize_size))
    {
      return 68;
    }
 L457: ATTRIBUTE_UNUSED_LABEL
  if ((!optimize_size))
    {
      return 70;
    }
  x1 = XEXP (x0, 0);
  goto L6706;

 L638: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == TFmode)
    goto L6964;
 L464: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, TFmode))
    {
      operands[1] = x1;
      goto L465;
    }
  x1 = XEXP (x0, 0);
  goto L6714;

 L6964: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case FLOAT_EXTEND:
      goto L639;
    case NEG:
      goto L2541;
    case ABS:
      goto L2639;
    default:
     break;
   }
  goto L464;

 L639: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SFmode:
      goto L6967;
    case DFmode:
      goto L6968;
    default:
      break;
    }
  goto L464;

 L6967: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L640;
    }
  goto L464;

 L640: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)))
    {
      return 97;
    }
  x1 = XEXP (x0, 1);
  goto L464;

 L6968: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L650;
    }
  goto L464;

 L650: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)))
    {
      return 99;
    }
  x1 = XEXP (x0, 1);
  goto L464;

 L2541: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L2542;
    }
  goto L464;

 L2542: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && ix86_unary_operator_ok (NEG, TFmode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 234;
    }
  x1 = XEXP (x0, 1);
  goto L464;

 L2639: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L2640;
    }
  goto L464;

 L2640: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && ix86_unary_operator_ok (ABS, TFmode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 247;
    }
  x1 = XEXP (x0, 1);
  goto L464;

 L465: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && optimize_size
   && (reload_in_progress || reload_completed
       || GET_CODE (operands[1]) != CONST_DOUBLE
       || memory_operand (operands[0], TFmode))))
    {
      return 72;
    }
 L473: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && !optimize_size
   && (reload_in_progress || reload_completed
       || GET_CODE (operands[1]) != CONST_DOUBLE
       || memory_operand (operands[0], TFmode))))
    {
      return 74;
    }
  x1 = XEXP (x0, 0);
  goto L6714;

 L830: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == TFmode)
    goto L6969;
  goto ret0;

 L6969: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case FLOAT:
      goto L831;
    case NEG:
      goto L2579;
    case ABS:
      goto L2677;
    case SQRT:
      goto L4026;
    case UNSPEC:
      goto L6977;
    case IF_THEN_ELSE:
      goto L4428;
    case PLUS:
    case MINUS:
    case MULT:
    case DIV:
      goto L6972;
    default:
      goto ret0;
   }
 L6972: ATTRIBUTE_UNUSED_LABEL
  if (binary_fp_operator (x1, TFmode))
    {
      operands[3] = x1;
      goto L3849;
    }
  goto ret0;

 L831: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L6979;
    case SImode:
      goto L6980;
    case DImode:
      goto L6981;
    default:
      break;
    }
  goto ret0;

 L6979: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L832;
    }
  goto ret0;

 L832: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 122;
    }
  goto ret0;

 L6980: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L842;
    }
  goto ret0;

 L842: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 124;
    }
  goto ret0;

 L6981: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L852;
    }
  goto ret0;

 L852: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 126;
    }
  goto ret0;

 L2579: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == TFmode)
    goto L6983;
  goto ret0;

 L6983: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L2585;
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L2580;
    }
  goto ret0;

 L2585: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L6984;
    case SFmode:
      goto L6985;
    default:
      break;
    }
  goto ret0;

 L6984: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L2586;
    }
  goto ret0;

 L2586: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 242;
    }
  goto ret0;

 L6985: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L2592;
    }
  goto ret0;

 L2592: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 243;
    }
  goto ret0;

 L2580: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return 241;
    }
  goto ret0;

 L2677: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == TFmode)
    goto L6987;
  goto ret0;

 L6987: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L2683;
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L2678;
    }
  goto ret0;

 L2683: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L6988;
    case SFmode:
      goto L6989;
    default:
      break;
    }
  goto ret0;

 L6988: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L2684;
    }
  goto ret0;

 L2684: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 255;
    }
  goto ret0;

 L6989: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L2690;
    }
  goto ret0;

 L2690: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 256;
    }
  goto ret0;

 L2678: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return 254;
    }
  goto ret0;

 L4026: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == TFmode)
    goto L6991;
  goto ret0;

 L6991: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT_EXTEND)
    goto L4038;
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L4027;
    }
  goto ret0;

 L4038: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L6992;
    case SFmode:
      goto L6993;
    default:
      break;
    }
  goto ret0;

 L6992: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L4039;
    }
  goto ret0;

 L4039: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387))
    {
      return 377;
    }
  goto ret0;

 L6993: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L4051;
    }
  goto ret0;

 L4051: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387))
    {
      return 379;
    }
  goto ret0;

 L4027: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 
   && (TARGET_IEEE_FP || flag_fast_math) ))
    {
      return 375;
    }
  goto ret0;

 L6977: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1)
    goto L6994;
  goto ret0;

 L6994: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x1, 1))
    {
    case 1:
      goto L4076;
    case 2:
      goto L4102;
    default:
      break;
    }
  goto ret0;

 L4076: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L4077;
    }
  goto ret0;

 L4077: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 384;
    }
  goto ret0;

 L4102: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L4103;
    }
  goto ret0;

 L4103: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 389;
    }
  goto ret0;

 L4428: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (fcmov_comparison_operator (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L4429;
    }
  goto ret0;

 L4429: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L4430;
  goto ret0;

 L4430: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4431;
  goto ret0;

 L4431: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, TFmode))
    {
      operands[2] = x2;
      goto L4432;
    }
  goto ret0;

 L4432: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (register_operand (x2, TFmode))
    {
      operands[3] = x2;
      goto L4433;
    }
  goto ret0;

 L4433: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE))
    {
      return 410;
    }
  goto ret0;

 L3849: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == TFmode)
    goto L6997;
  goto ret0;

 L6997: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT:
      goto L3929;
    case FLOAT_EXTEND:
      goto L3957;
    case SUBREG:
    case REG:
      goto L6996;
    default:
      goto ret0;
   }
 L6996: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L3850;
    }
  goto ret0;

 L3929: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L3930;
    }
  goto ret0;

 L3930: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, TFmode))
    {
      operands[2] = x2;
      goto L3931;
    }
  goto ret0;

 L3931: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_USE_FIOP))
    {
      return 360;
    }
  goto ret0;

 L3957: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case SFmode:
      goto L6999;
    case DFmode:
      goto L7000;
    default:
      break;
    }
  goto ret0;

 L6999: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L3958;
    }
  goto ret0;

 L3958: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, TFmode))
    {
      operands[2] = x2;
      goto L3959;
    }
  goto ret0;

 L3959: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 364;
    }
  goto ret0;

 L7000: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L3986;
    }
  goto ret0;

 L3986: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, TFmode))
    {
      operands[2] = x2;
      goto L3987;
    }
  goto ret0;

 L3987: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 368;
    }
  goto ret0;

 L3850: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == TFmode)
    goto L7002;
  goto ret0;

 L7002: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT:
      goto L3944;
    case FLOAT_EXTEND:
      goto L3972;
    case SUBREG:
    case REG:
      goto L7001;
    default:
      goto ret0;
   }
 L7001: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, TFmode))
    {
      operands[2] = x2;
      goto L3851;
    }
  goto ret0;

 L3944: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L3945;
    }
  goto ret0;

 L3945: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_USE_FIOP))
    {
      return 362;
    }
  goto ret0;

 L3972: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case SFmode:
      goto L7004;
    case DFmode:
      goto L7005;
    default:
      break;
    }
  goto ret0;

 L7004: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[2] = x3;
      goto L3973;
    }
  goto ret0;

 L3973: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 366;
    }
  goto ret0;

 L7005: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, DFmode))
    {
      operands[2] = x3;
      goto L4001;
    }
  goto ret0;

 L4001: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 370;
    }
  goto ret0;

 L3851: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && GET_RTX_CLASS (GET_CODE (operands[3])) == 'c'))
    {
      return 348;
    }
 L3917: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && GET_RTX_CLASS (GET_CODE (operands[3])) != 'c'))
    {
      return 358;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_6 PARAMS ((rtx, rtx, int *));
static int
recog_6 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L7007;
    case HImode:
      goto L7009;
    case QImode:
      goto L7011;
    default:
      break;
    }
 L60: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L61;
    }
 L79: ATTRIBUTE_UNUSED_LABEL
  if (GET_MODE (x2) == QImode)
    goto L7031;
  goto ret0;

 L7007: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MINUS:
      goto L10;
    case NEG:
      goto L981;
    case PLUS:
      goto L1014;
    case AND:
      goto L1784;
    case ZERO_EXTRACT:
      goto L1839;
    case IOR:
      goto L2103;
    case XOR:
      goto L2268;
    case SUBREG:
    case REG:
    case MEM:
      goto L7006;
    default:
      goto L7014;
   }
 L7006: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4;
    }
 L7014: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L997;
    }
  goto ret0;

 L10: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[0] = x3;
      goto L11;
    }
  goto ret0;

 L11: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L12;
    }
  goto ret0;

 L12: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCGOCmode)))
    {
      return 1;
    }
  goto ret0;

 L981: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L982;
    }
  goto ret0;

 L982: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L983;
    }
  goto ret0;

 L983: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCZmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)
   /* Current assemblers are broken and do not allow @GOTOFF in
      ought but a memory context. */
   && ! pic_symbolic_operand (operands[2], VOIDmode))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 137;
    }
  goto ret0;

 L1014: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1015;
    }
  goto ret0;

 L1015: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1016;
    }
  goto ret0;

 L1016: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)
   /* Current assemblers are broken and do not allow @GOTOFF in
      ought but a memory context. */
   && ! pic_symbolic_operand (operands[2], VOIDmode))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 139;
    }
  goto ret0;

 L1784: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7034;
  goto ret0;

 L7034: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == ZERO_EXTRACT)
    goto L1806;
  if (nonimmediate_operand (x3, SImode))
    {
      operands[0] = x3;
      goto L1785;
    }
  goto ret0;

 L1806: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[0] = x4;
      goto L1807;
    }
  goto ret0;

 L1807: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1808;
  goto ret0;

 L1808: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1819;
  goto ret0;

 L1819: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode)
    goto L7035;
 L1809: ATTRIBUTE_UNUSED_LABEL
  if (const_int_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L1810;
    }
  goto ret0;

 L7035: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x3))
    {
    case ZERO_EXTEND:
      goto L1820;
    case ZERO_EXTRACT:
      goto L1831;
    default:
     break;
   }
  goto L1809;

 L1820: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L1821;
    }
  goto L1809;

 L1821: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return 187;
    }
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L1809;

 L1831: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L1832;
    }
  goto L1809;

 L1832: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1833;
  goto L1809;

 L1833: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1834;
  goto L1809;

 L1834: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return 188;
    }
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L1809;

 L1810: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && ((unsigned HOST_WIDE_INT) INTVAL (operands[1]) <= 0xff
   && ix86_match_ccmode (insn, CCNOmode)))
    {
      return 186;
    }
  goto ret0;

 L1785: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1786;
    }
  goto ret0;

 L1786: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return 183;
    }
  goto ret0;

 L1839: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L1840;
    }
  goto ret0;

 L1840: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1841;
    }
  goto ret0;

 L1841: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (const_int_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1842;
    }
  goto ret0;

 L1842: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)
   && (GET_MODE (operands[0]) == SImode
       || GET_MODE (operands[0]) == HImode
       || GET_MODE (operands[0]) == QImode)))
    {
      return 189;
    }
  goto ret0;

 L2103: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2104;
    }
  goto ret0;

 L2104: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L2105;
    }
  goto ret0;

 L2105: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 204;
    }
  goto ret0;

 L2268: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2269;
    }
  goto ret0;

 L2269: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L2270;
    }
  goto ret0;

 L2270: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 215;
    }
  goto ret0;

 L4: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const0_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L5;
    }
 L17: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L18;
    }
  x2 = XEXP (x1, 0);
  goto L7014;

 L5: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)))
    {
      return 0;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L17;

 L18: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
    && ix86_match_ccmode (insn, CCmode)))
    {
      return 2;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L7014;

 L997: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L998;
    }
  goto ret0;

 L998: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGCmode)
   && (INTVAL (operands[2]) & 0xffffffff) != 0x80000000)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 138;
    }
  goto ret0;

 L7009: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MINUS:
      goto L29;
    case NEG:
      goto L1072;
    case PLUS:
      goto L1105;
    case AND:
      goto L1791;
    case IOR:
      goto L2148;
    case XOR:
      goto L2313;
    case SUBREG:
    case REG:
    case MEM:
      goto L7008;
    default:
      goto L7017;
   }
 L7008: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L23;
    }
 L7017: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L1088;
    }
  goto ret0;

 L29: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[0] = x3;
      goto L30;
    }
  goto ret0;

 L30: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L31;
    }
  goto ret0;

 L31: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCGOCmode)))
    {
      return 4;
    }
  goto ret0;

 L1072: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1073;
    }
  goto ret0;

 L1073: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L1074;
    }
  goto ret0;

 L1074: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCZmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 143;
    }
  goto ret0;

 L1105: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1106;
    }
  goto ret0;

 L1106: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1107;
    }
  goto ret0;

 L1107: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 145;
    }
  goto ret0;

 L1791: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[0] = x3;
      goto L1792;
    }
  goto ret0;

 L1792: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1793;
    }
  goto ret0;

 L1793: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return 184;
    }
  goto ret0;

 L2148: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L2149;
    }
  goto ret0;

 L2149: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L2150;
    }
  goto ret0;

 L2150: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 207;
    }
  goto ret0;

 L2313: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L2314;
    }
  goto ret0;

 L2314: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L2315;
    }
  goto ret0;

 L2315: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 218;
    }
  goto ret0;

 L23: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const0_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L24;
    }
 L36: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L37;
    }
  x2 = XEXP (x1, 0);
  goto L7017;

 L24: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)))
    {
      return 3;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L36;

 L37: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && ix86_match_ccmode (insn, CCmode)))
    {
      return 5;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L7017;

 L1088: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L1089;
    }
  goto ret0;

 L1089: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGCmode)
   && (INTVAL (operands[2]) & 0xffff) != 0x8000)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 144;
    }
  goto ret0;

 L7011: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MINUS:
      goto L54;
    case NEG:
      goto L1163;
    case PLUS:
      goto L1196;
    case AND:
      goto L1798;
    case IOR:
      goto L2223;
    case XOR:
      goto L2389;
    case SUBREG:
    case REG:
    case MEM:
      goto L7010;
    default:
      goto L7012;
   }
 L7010: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L42;
    }
 L7012: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 0)
    goto L70;
  goto L60;

 L54: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[0] = x3;
      goto L55;
    }
  goto L60;

 L55: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L56;
    }
  goto L60;

 L56: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCGOCmode)))
    {
      return 8;
    }
  x2 = XEXP (x1, 0);
  goto L60;

 L1163: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1164;
    }
  goto L60;

 L1164: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L1165;
    }
  x2 = XEXP (x1, 0);
  goto L60;

 L1165: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCZmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 149;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L60;

 L1196: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1197;
    }
  goto L60;

 L1197: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1198;
    }
  goto L60;

 L1198: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 151;
    }
  x2 = XEXP (x1, 0);
  goto L60;

 L1798: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[0] = x3;
      goto L1799;
    }
  goto L60;

 L1799: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1800;
    }
  goto L60;

 L1800: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return 185;
    }
  x2 = XEXP (x1, 0);
  goto L60;

 L2223: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L2224;
    }
  goto L60;

 L2224: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2225;
    }
  goto L60;

 L2225: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 212;
    }
  x2 = XEXP (x1, 0);
  goto L60;

 L2389: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L2390;
    }
  goto L60;

 L2390: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2391;
    }
  goto L60;

 L2391: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 222;
    }
  x2 = XEXP (x1, 0);
  goto L60;

 L42: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const0_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L43;
    }
 L48: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L49;
    }
  x2 = XEXP (x1, 0);
  goto L7012;

 L43: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)))
    {
      return 6;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L48;

 L49: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
    && ix86_match_ccmode (insn, CCmode)))
    {
      return 7;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L7012;

 L70: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L71;
  goto L60;

 L71: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[0] = x4;
      goto L72;
    }
  goto L60;

 L72: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L73;
  goto L60;

 L73: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L74;
  goto L60;

 L74: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const0_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L75;
    }
  x2 = XEXP (x1, 0);
  goto L60;

 L75: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)))
    {
      return 10;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L60;

 L61: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 0)
    goto L62;
  x2 = XEXP (x1, 0);
  goto L79;

 L62: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L63;
  x2 = XEXP (x1, 0);
  goto L79;

 L63: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L64;
    }
  x2 = XEXP (x1, 0);
  goto L79;

 L64: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L65;
  x2 = XEXP (x1, 0);
  goto L79;

 L65: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8
      && (ix86_match_ccmode (insn, CCmode)))
    {
      return 9;
    }
  x2 = XEXP (x1, 0);
  goto L79;

 L7031: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 0)
    goto L80;
 L7032: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L1179;
    }
  goto ret0;

 L80: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L81;
  goto L7032;

 L81: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[0] = x4;
      goto L82;
    }
  goto L7032;

 L82: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L83;
  goto L7032;

 L83: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L84;
  goto L7032;

 L84: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L85;
    }
 L94: ATTRIBUTE_UNUSED_LABEL
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 0)
    goto L95;
  x2 = XEXP (x1, 0);
  goto L7032;

 L85: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCmode)))
    {
      return 11;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L94;

 L95: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L96;
  x2 = XEXP (x1, 0);
  goto L7032;

 L96: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L97;
    }
  x2 = XEXP (x1, 0);
  goto L7032;

 L97: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L98;
  x2 = XEXP (x1, 0);
  goto L7032;

 L98: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8
      && (ix86_match_ccmode (insn, CCmode)))
    {
      return 12;
    }
  x2 = XEXP (x1, 0);
  goto L7032;

 L1179: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L1180;
    }
  goto ret0;

 L1180: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGCmode)
   && (INTVAL (operands[2]) & 0xff) != 0x80)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 150;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_7 PARAMS ((rtx, rtx, int *));
static int
recog_7 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  switch (GET_CODE (x2))
    {
    case PLUS:
      goto L4669;
    case MINUS:
      goto L4683;
    case MULT:
      goto L4697;
    case DIV:
      goto L4711;
    case UNSPEC:
      goto L7083;
    case SQRT:
      goto L4748;
    case VEC_SELECT:
      goto L4837;
    case SMAX:
      goto L4879;
    case SMIN:
      goto L4893;
    case SUBREG:
    case REG:
      goto L7071;
    default:
      goto L7072;
   }
 L7071: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4600;
    }
 L7072: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4636;
    }
  goto ret0;

 L4669: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4670;
    }
  goto ret0;

 L4670: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4671;
    }
  goto ret0;

 L4671: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[1]))
    goto L4672;
  goto ret0;

 L4672: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 447;
    }
  goto ret0;

 L4683: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4684;
    }
  goto ret0;

 L4684: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4685;
    }
  goto ret0;

 L4685: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[1]))
    goto L4686;
  goto ret0;

 L4686: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 449;
    }
  goto ret0;

 L4697: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4698;
    }
  goto ret0;

 L4698: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4699;
    }
  goto ret0;

 L4699: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[1]))
    goto L4700;
  goto ret0;

 L4700: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 451;
    }
  goto ret0;

 L4711: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4712;
    }
  goto ret0;

 L4712: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4713;
    }
  goto ret0;

 L4713: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[1]))
    goto L4714;
  goto ret0;

 L4714: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 453;
    }
  goto ret0;

 L7083: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x2, 0) == 1)
    goto L7085;
  goto ret0;

 L7085: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x2, 1))
    {
    case 42:
      goto L4724;
    case 43:
      goto L4736;
    default:
      break;
    }
  goto ret0;

 L4724: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4725;
    }
  goto ret0;

 L4725: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4726;
    }
  goto ret0;

 L4726: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 455;
    }
  goto ret0;

 L4736: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4737;
    }
  goto ret0;

 L4737: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4738;
    }
  goto ret0;

 L4738: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 457;
    }
  goto ret0;

 L4748: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4749;
    }
  goto ret0;

 L4749: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4750;
    }
  goto ret0;

 L4750: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 459;
    }
  goto ret0;

 L4837: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4838;
    }
  goto ret0;

 L4838: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 4)
    goto L4839;
  goto ret0;

 L4839: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT)
    goto L7087;
  goto ret0;

 L7087: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x4, 0))
    {
    case 2:
      goto L4840;
    case 0:
      goto L4858;
    default:
      break;
    }
  goto ret0;

 L4840: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4841;
  goto ret0;

 L4841: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L4842;
  goto ret0;

 L4842: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L4843;
  goto ret0;

 L4843: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V8QImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L4844;
  goto ret0;

 L4844: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V8QImode))
    {
      operands[2] = x3;
      goto L4845;
    }
  goto ret0;

 L4845: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 4)
    goto L4846;
  goto ret0;

 L4846: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4847;
  goto ret0;

 L4847: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L4848;
  goto ret0;

 L4848: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L4849;
  goto ret0;

 L4849: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L4850;
  goto ret0;

 L4850: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 5
      && (TARGET_SSE))
    {
      return 471;
    }
  goto ret0;

 L4858: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L4859;
  goto ret0;

 L4859: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L4860;
  goto ret0;

 L4860: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L4861;
  goto ret0;

 L4861: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V8QImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L4862;
  goto ret0;

 L4862: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V8QImode))
    {
      operands[2] = x3;
      goto L4863;
    }
  goto ret0;

 L4863: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 4)
    goto L4864;
  goto ret0;

 L4864: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L4865;
  goto ret0;

 L4865: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4866;
  goto ret0;

 L4866: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L4867;
  goto ret0;

 L4867: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L4868;
  goto ret0;

 L4868: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 5
      && (TARGET_SSE))
    {
      return 472;
    }
  goto ret0;

 L4879: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4880;
    }
  goto ret0;

 L4880: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4881;
    }
  goto ret0;

 L4881: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[1]))
    goto L4882;
  goto ret0;

 L4882: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 474;
    }
  goto ret0;

 L4893: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4894;
    }
  goto ret0;

 L4894: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4895;
    }
  goto ret0;

 L4895: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[1]))
    goto L4896;
  goto ret0;

 L4896: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 476;
    }
  goto ret0;

 L4600: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V4SFmode)
    goto L7089;
  x2 = XEXP (x1, 0);
  goto L7072;

 L7089: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case VEC_SELECT:
      goto L4601;
    case VEC_DUPLICATE:
      goto L4902;
    case SUBREG:
    case REG:
      goto L7090;
    default:
      x2 = XEXP (x1, 0);
      goto L7072;
   }
 L7090: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4645;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L4601: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4602;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L4602: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 4)
    goto L4603;
  x2 = XEXP (x1, 0);
  goto L7072;

 L4603: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L4604;
  x2 = XEXP (x1, 0);
  goto L7072;

 L4604: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L4605;
  x2 = XEXP (x1, 0);
  goto L7072;

 L4605: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4606;
  x2 = XEXP (x1, 0);
  goto L7072;

 L4606: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L4607;
  x2 = XEXP (x1, 0);
  goto L7072;

 L4607: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT)
    goto L7092;
  x2 = XEXP (x1, 0);
  goto L7072;

 L7092: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x2, 0))
    {
    case 3:
      goto L7094;
    case 12:
      goto L7095;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L7094: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 438;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L7095: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 439;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L4902: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case V2SFmode:
      goto L7096;
    case SFmode:
      goto L7097;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L7096: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == FLOAT)
    goto L4903;
  x2 = XEXP (x1, 0);
  goto L7072;

 L4903: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, V2SImode))
    {
      operands[2] = x4;
      goto L4904;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L4904: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 12
      && (TARGET_SSE))
    {
      return 477;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L7097: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == FLOAT)
    goto L4927;
  x2 = XEXP (x1, 0);
  goto L7072;

 L4927: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L4928;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L4928: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 15
      && (TARGET_SSE))
    {
      return 480;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L4645: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 443;
    }
  x2 = XEXP (x1, 0);
  goto L7072;

 L4636: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V4SFmode
      && GET_CODE (x2) == VEC_DUPLICATE)
    goto L4637;
  goto ret0;

 L4637: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SFmode
      && GET_CODE (x3) == FLOAT)
    goto L4638;
  goto ret0;

 L4638: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4639;
  goto ret0;

 L4639: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 442;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_8 PARAMS ((rtx, rtx, int *));
static int
recog_8 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 1);
  switch (GET_CODE (x1))
    {
    case PLUS:
      goto L4946;
    case SS_PLUS:
      goto L4964;
    case US_PLUS:
      goto L4976;
    case MINUS:
      goto L4988;
    case SS_MINUS:
      goto L5006;
    case US_MINUS:
      goto L5018;
    case ASHIFTRT:
      goto L5118;
    case ABS:
      goto L5150;
    case EQ:
      goto L5181;
    case GT:
      goto L5199;
    case UMAX:
      goto L5217;
    case UMIN:
      goto L5229;
    case VEC_CONCAT:
      goto L5291;
    case VEC_MERGE:
      goto L5315;
    default:
     break;
   }
  goto ret0;

 L4946: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L4947;
    }
  goto ret0;

 L4947: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L4948;
    }
  goto ret0;

 L4948: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 483;
    }
  goto ret0;

 L4964: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L4965;
    }
  goto ret0;

 L4965: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L4966;
    }
  goto ret0;

 L4966: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 486;
    }
  goto ret0;

 L4976: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L4977;
    }
  goto ret0;

 L4977: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L4978;
    }
  goto ret0;

 L4978: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 488;
    }
  goto ret0;

 L4988: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L4989;
    }
  goto ret0;

 L4989: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L4990;
    }
  goto ret0;

 L4990: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 490;
    }
  goto ret0;

 L5006: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L5007;
    }
  goto ret0;

 L5007: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L5008;
    }
  goto ret0;

 L5008: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 493;
    }
  goto ret0;

 L5018: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L5019;
    }
  goto ret0;

 L5019: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L5020;
    }
  goto ret0;

 L5020: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 495;
    }
  goto ret0;

 L5118: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V8QImode
      && GET_CODE (x2) == PLUS)
    goto L5119;
  goto ret0;

 L5119: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == V8QImode
      && GET_CODE (x3) == PLUS)
    goto L5120;
  goto ret0;

 L5120: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, V8QImode))
    {
      operands[1] = x4;
      goto L5121;
    }
  goto ret0;

 L5121: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonimmediate_operand (x4, V8QImode))
    {
      operands[2] = x4;
      goto L5122;
    }
  goto ret0;

 L5122: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == V8QImode
      && GET_CODE (x3) == VEC_CONST)
    goto L5123;
  goto ret0;

 L5123: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == PARALLEL
      && XVECLEN (x4, 0) == 8)
    goto L5124;
  goto ret0;

 L5124: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 0);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5125;
  goto ret0;

 L5125: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 1);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5126;
  goto ret0;

 L5126: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 2);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5127;
  goto ret0;

 L5127: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 3);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5128;
  goto ret0;

 L5128: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 4);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5129;
  goto ret0;

 L5129: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 5);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5130;
  goto ret0;

 L5130: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 6);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5131;
  goto ret0;

 L5131: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 7);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5132;
  goto ret0;

 L5132: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 506;
    }
  goto ret0;

 L5150: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V8QImode
      && GET_CODE (x2) == MINUS)
    goto L5151;
  goto ret0;

 L5151: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V8QImode))
    {
      operands[1] = x3;
      goto L5152;
    }
  goto ret0;

 L5152: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V8QImode))
    {
      operands[2] = x3;
      goto L5153;
    }
  goto ret0;

 L5153: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 508;
    }
  goto ret0;

 L5181: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L5182;
    }
  goto ret0;

 L5182: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L5183;
    }
  goto ret0;

 L5183: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 512;
    }
  goto ret0;

 L5199: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L5200;
    }
  goto ret0;

 L5200: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L5201;
    }
  goto ret0;

 L5201: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 515;
    }
  goto ret0;

 L5217: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L5218;
    }
  goto ret0;

 L5218: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L5219;
    }
  goto ret0;

 L5219: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 518;
    }
  goto ret0;

 L5229: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L5230;
    }
  goto ret0;

 L5230: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L5231;
    }
  goto ret0;

 L5231: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 520;
    }
  goto ret0;

 L5291: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V4QImode)
    goto L7120;
  goto ret0;

 L7120: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case SS_TRUNCATE:
      goto L5292;
    case US_TRUNCATE:
      goto L5308;
    default:
     break;
   }
  goto ret0;

 L5292: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4HImode))
    {
      operands[1] = x3;
      goto L5293;
    }
  goto ret0;

 L5293: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V4QImode
      && GET_CODE (x2) == SS_TRUNCATE)
    goto L5294;
  goto ret0;

 L5294: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4HImode))
    {
      operands[2] = x3;
      goto L5295;
    }
  goto ret0;

 L5295: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 530;
    }
  goto ret0;

 L5308: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4HImode))
    {
      operands[1] = x3;
      goto L5309;
    }
  goto ret0;

 L5309: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V4QImode
      && GET_CODE (x2) == US_TRUNCATE)
    goto L5310;
  goto ret0;

 L5310: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4HImode))
    {
      operands[2] = x3;
      goto L5311;
    }
  goto ret0;

 L5311: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 532;
    }
  goto ret0;

 L5315: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V8QImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5316;
  goto ret0;

 L5316: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V8QImode))
    {
      operands[1] = x3;
      goto L5317;
    }
  goto ret0;

 L5317: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 8)
    goto L5318;
  goto ret0;

 L5318: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT)
    goto L7122;
  goto ret0;

 L7122: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x4, 0))
    {
    case 4:
      goto L5319;
    case 0:
      goto L5377;
    default:
      break;
    }
  goto ret0;

 L5319: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5320;
  goto ret0;

 L5320: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 5)
    goto L5321;
  goto ret0;

 L5321: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5322;
  goto ret0;

 L5322: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 4);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 6)
    goto L5323;
  goto ret0;

 L5323: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 5);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L5324;
  goto ret0;

 L5324: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 6);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 7)
    goto L5325;
  goto ret0;

 L5325: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 7);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L5326;
  goto ret0;

 L5326: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V8QImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5327;
  goto ret0;

 L5327: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V8QImode))
    {
      operands[2] = x3;
      goto L5328;
    }
  goto ret0;

 L5328: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 8)
    goto L5329;
  goto ret0;

 L5329: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5330;
  goto ret0;

 L5330: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 4)
    goto L5331;
  goto ret0;

 L5331: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5332;
  goto ret0;

 L5332: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 5)
    goto L5333;
  goto ret0;

 L5333: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 4);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L5334;
  goto ret0;

 L5334: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 5);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 6)
    goto L5335;
  goto ret0;

 L5335: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 6);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L5336;
  goto ret0;

 L5336: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 7);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 7)
    goto L5337;
  goto ret0;

 L5337: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 85
      && (TARGET_MMX))
    {
      return 533;
    }
  goto ret0;

 L5377: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 4)
    goto L5378;
  goto ret0;

 L5378: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5379;
  goto ret0;

 L5379: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 5)
    goto L5380;
  goto ret0;

 L5380: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 4);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L5381;
  goto ret0;

 L5381: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 5);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 6)
    goto L5382;
  goto ret0;

 L5382: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 6);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L5383;
  goto ret0;

 L5383: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 7);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 7)
    goto L5384;
  goto ret0;

 L5384: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V8QImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5385;
  goto ret0;

 L5385: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V8QImode))
    {
      operands[2] = x3;
      goto L5386;
    }
  goto ret0;

 L5386: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 8)
    goto L5387;
  goto ret0;

 L5387: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 4)
    goto L5388;
  goto ret0;

 L5388: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5389;
  goto ret0;

 L5389: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 5)
    goto L5390;
  goto ret0;

 L5390: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5391;
  goto ret0;

 L5391: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 4);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 6)
    goto L5392;
  goto ret0;

 L5392: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 5);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L5393;
  goto ret0;

 L5393: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 6);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 7)
    goto L5394;
  goto ret0;

 L5394: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 7);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L5395;
  goto ret0;

 L5395: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 85
      && (TARGET_MMX))
    {
      return 536;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_9 PARAMS ((rtx, rtx, int *));
static int
recog_9 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 1);
  switch (GET_CODE (x1))
    {
    case PLUS:
      goto L4952;
    case SS_PLUS:
      goto L4970;
    case US_PLUS:
      goto L4982;
    case MINUS:
      goto L4994;
    case SS_MINUS:
      goto L5012;
    case US_MINUS:
      goto L5024;
    case MULT:
      goto L5030;
    case TRUNCATE:
      goto L5036;
    case ASHIFTRT:
      goto L5136;
    case VEC_MERGE:
      goto L5157;
    case UNSPEC:
      goto L7142;
    case EQ:
      goto L5187;
    case GT:
      goto L5205;
    case SMAX:
      goto L5223;
    case SMIN:
      goto L5235;
    case LSHIFTRT:
      goto L5253;
    case ASHIFT:
      goto L5272;
    case VEC_CONCAT:
      goto L5299;
    default:
     break;
   }
  goto ret0;

 L4952: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L4953;
    }
  goto ret0;

 L4953: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L4954;
    }
  goto ret0;

 L4954: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 484;
    }
  goto ret0;

 L4970: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L4971;
    }
  goto ret0;

 L4971: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L4972;
    }
  goto ret0;

 L4972: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 487;
    }
  goto ret0;

 L4982: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L4983;
    }
  goto ret0;

 L4983: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L4984;
    }
  goto ret0;

 L4984: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 489;
    }
  goto ret0;

 L4994: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L4995;
    }
  goto ret0;

 L4995: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L4996;
    }
  goto ret0;

 L4996: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 491;
    }
  goto ret0;

 L5012: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5013;
    }
  goto ret0;

 L5013: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L5014;
    }
  goto ret0;

 L5014: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 494;
    }
  goto ret0;

 L5024: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5025;
    }
  goto ret0;

 L5025: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L5026;
    }
  goto ret0;

 L5026: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 496;
    }
  goto ret0;

 L5030: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5031;
    }
  goto ret0;

 L5031: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L5032;
    }
  goto ret0;

 L5032: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 497;
    }
  goto ret0;

 L5036: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V4SImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L5037;
  goto ret0;

 L5037: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == V4SImode
      && GET_CODE (x3) == MULT)
    goto L5038;
  goto ret0;

 L5038: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == V4SImode)
    goto L7143;
  goto ret0;

 L7143: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x4))
    {
    case SIGN_EXTEND:
      goto L5039;
    case ZERO_EXTEND:
      goto L5049;
    default:
     break;
   }
  goto ret0;

 L5039: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, V4HImode))
    {
      operands[1] = x5;
      goto L5040;
    }
  goto ret0;

 L5040: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == V4SImode
      && GET_CODE (x4) == SIGN_EXTEND)
    goto L5041;
  goto ret0;

 L5041: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (nonimmediate_operand (x5, V4HImode))
    {
      operands[2] = x5;
      goto L5042;
    }
  goto ret0;

 L5042: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 16
      && (TARGET_MMX))
    {
      return 498;
    }
  goto ret0;

 L5049: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, V4HImode))
    {
      operands[1] = x5;
      goto L5050;
    }
  goto ret0;

 L5050: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == V4SImode
      && GET_CODE (x4) == ZERO_EXTEND)
    goto L5051;
  goto ret0;

 L5051: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (nonimmediate_operand (x5, V4HImode))
    {
      operands[2] = x5;
      goto L5052;
    }
  goto ret0;

 L5052: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 16
      && (TARGET_MMX))
    {
      return 499;
    }
  goto ret0;

 L5136: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V4HImode)
    goto L7145;
  goto ret0;

 L7145: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == PLUS)
    goto L5137;
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5242;
    }
  goto ret0;

 L5137: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == V4HImode
      && GET_CODE (x3) == PLUS)
    goto L5138;
  goto ret0;

 L5138: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, V4HImode))
    {
      operands[1] = x4;
      goto L5139;
    }
  goto ret0;

 L5139: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonimmediate_operand (x4, V4HImode))
    {
      operands[2] = x4;
      goto L5140;
    }
  goto ret0;

 L5140: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == V4HImode
      && GET_CODE (x3) == VEC_CONST)
    goto L5141;
  goto ret0;

 L5141: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_CODE (x4) == PARALLEL
      && XVECLEN (x4, 0) == 4)
    goto L5142;
  goto ret0;

 L5142: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 0);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5143;
  goto ret0;

 L5143: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 1);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5144;
  goto ret0;

 L5144: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 2);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5145;
  goto ret0;

 L5145: ATTRIBUTE_UNUSED_LABEL
  x5 = XVECEXP (x4, 0, 3);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 1)
    goto L5146;
  goto ret0;

 L5146: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 507;
    }
  goto ret0;

 L5242: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, DImode))
    {
      operands[2] = x2;
      goto L5243;
    }
  goto ret0;

 L5243: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 522;
    }
  goto ret0;

 L5157: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V4HImode)
    goto L7148;
  goto ret0;

 L7148: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == VEC_SELECT)
    goto L5342;
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5158;
    }
  goto ret0;

 L5342: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4HImode))
    {
      operands[1] = x3;
      goto L5343;
    }
  goto ret0;

 L5343: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 4)
    goto L5344;
  goto ret0;

 L5344: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT)
    goto L7149;
  goto ret0;

 L7149: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x4, 0))
    {
    case 0:
      goto L5345;
    case 2:
      goto L5403;
    default:
      break;
    }
  goto ret0;

 L5345: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L5346;
  goto ret0;

 L5346: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5347;
  goto ret0;

 L5347: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L5348;
  goto ret0;

 L5348: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V4HImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5349;
  goto ret0;

 L5349: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4HImode))
    {
      operands[2] = x3;
      goto L5350;
    }
  goto ret0;

 L5350: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 4)
    goto L5351;
  goto ret0;

 L5351: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L5352;
  goto ret0;

 L5352: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5353;
  goto ret0;

 L5353: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L5354;
  goto ret0;

 L5354: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5355;
  goto ret0;

 L5355: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 5
      && (TARGET_MMX))
    {
      return 534;
    }
  goto ret0;

 L5403: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5404;
  goto ret0;

 L5404: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L5405;
  goto ret0;

 L5405: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5406;
  goto ret0;

 L5406: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V4HImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5407;
  goto ret0;

 L5407: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4HImode))
    {
      operands[2] = x3;
      goto L5408;
    }
  goto ret0;

 L5408: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 4)
    goto L5409;
  goto ret0;

 L5409: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5410;
  goto ret0;

 L5410: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L5411;
  goto ret0;

 L5411: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5412;
  goto ret0;

 L5412: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 3);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 3)
    goto L5413;
  goto ret0;

 L5413: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 5
      && (TARGET_MMX))
    {
      return 537;
    }
  goto ret0;

 L5158: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V4HImode
      && GET_CODE (x2) == VEC_DUPLICATE)
    goto L5159;
  goto ret0;

 L5159: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == HImode
      && GET_CODE (x3) == TRUNCATE)
    goto L5160;
  goto ret0;

 L5160: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L5161;
    }
  goto ret0;

 L5161: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (immediate_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L5162;
    }
  goto ret0;

 L5162: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 509;
    }
  goto ret0;

 L7142: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 3
      && XINT (x1, 1) == 41)
    goto L5174;
  goto ret0;

 L5174: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5175;
    }
  goto ret0;

 L5175: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L5176;
    }
  goto ret0;

 L5176: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 2);
  if (immediate_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L5177;
    }
  goto ret0;

 L5177: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 511;
    }
  goto ret0;

 L5187: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5188;
    }
  goto ret0;

 L5188: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L5189;
    }
  goto ret0;

 L5189: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 513;
    }
  goto ret0;

 L5205: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5206;
    }
  goto ret0;

 L5206: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L5207;
    }
  goto ret0;

 L5207: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 516;
    }
  goto ret0;

 L5223: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5224;
    }
  goto ret0;

 L5224: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L5225;
    }
  goto ret0;

 L5225: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 519;
    }
  goto ret0;

 L5235: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5236;
    }
  goto ret0;

 L5236: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4HImode))
    {
      operands[2] = x2;
      goto L5237;
    }
  goto ret0;

 L5237: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 521;
    }
  goto ret0;

 L5253: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5254;
    }
  goto ret0;

 L5254: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, DImode))
    {
      operands[2] = x2;
      goto L5255;
    }
  goto ret0;

 L5255: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 524;
    }
  goto ret0;

 L5272: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4HImode))
    {
      operands[1] = x2;
      goto L5273;
    }
  goto ret0;

 L5273: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, DImode))
    {
      operands[2] = x2;
      goto L5274;
    }
  goto ret0;

 L5274: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 527;
    }
  goto ret0;

 L5299: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V2HImode
      && GET_CODE (x2) == SS_TRUNCATE)
    goto L5300;
  goto ret0;

 L5300: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V2SImode))
    {
      operands[1] = x3;
      goto L5301;
    }
  goto ret0;

 L5301: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V2HImode
      && GET_CODE (x2) == SS_TRUNCATE)
    goto L5302;
  goto ret0;

 L5302: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V2SImode))
    {
      operands[2] = x3;
      goto L5303;
    }
  goto ret0;

 L5303: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 531;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_10 PARAMS ((rtx, rtx, int *));
static int
recog_10 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  switch (GET_MODE (x1))
    {
    case HImode:
      goto L6692;
    case CCFPmode:
      goto L6686;
    case CCFPUmode:
      goto L6687;
    case CCmode:
      goto L6688;
    case SImode:
      goto L6689;
    case QImode:
      goto L6694;
    case DImode:
      goto L6697;
    case SFmode:
      goto L6699;
    case DFmode:
      goto L6701;
    case XFmode:
      goto L6703;
    case TFmode:
      goto L6704;
    default:
      break;
    }
 L1: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L2;
 L187: ATTRIBUTE_UNUSED_LABEL
  switch (GET_MODE (x1))
    {
    case CCFPmode:
      goto L6720;
    case CCFPUmode:
      goto L6721;
    default:
      break;
    }
 L294: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case STRICT_LOW_PART:
      goto L295;
    case PC:
      goto L3682;
    case SUBREG:
    case REG:
      goto L915;
    default:
      goto L4492;
   }
 L915: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, VOIDmode))
    {
      operands[0] = x1;
      goto L916;
    }
 L4492: ATTRIBUTE_UNUSED_LABEL
  operands[0] = x1;
  goto L4493;
 L4512: ATTRIBUTE_UNUSED_LABEL
  switch (GET_MODE (x1))
    {
    case V4SFmode:
      goto L6722;
    case V4SImode:
      goto L6723;
    case V8QImode:
      goto L6735;
    case V4HImode:
      goto L6725;
    case V2SImode:
      goto L6726;
    case TImode:
      goto L6727;
    case SImode:
      goto L6734;
    case DImode:
      goto L6737;
    case SFmode:
      goto L6739;
    case CCFPmode:
      goto L6742;
    case CCFPUmode:
      goto L6743;
    default:
      break;
    }
 L5473: ATTRIBUTE_UNUSED_LABEL
  operands[0] = x1;
  goto L5474;

 L6692: ATTRIBUTE_UNUSED_LABEL
  tem = recog_1 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L1;

 L6686: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 18)
    goto L108;
  goto L1;

 L108: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == CCFPmode
      && GET_CODE (x1) == COMPARE)
    goto L109;
  x1 = XEXP (x0, 0);
  goto L1;

 L109: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SFmode:
      goto L6779;
    case DFmode:
      goto L6780;
    case XFmode:
      goto L6781;
    case TFmode:
      goto L6782;
    default:
      break;
    }
 L174: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L175;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6779: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SFmode))
    {
      operands[0] = x2;
      goto L110;
    }
  goto L174;

 L110: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L111;
    }
  x2 = XEXP (x1, 0);
  goto L174;

 L111: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 14;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L174;

 L6780: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DFmode))
    {
      operands[0] = x2;
      goto L123;
    }
  goto L174;

 L123: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L124;
    }
  x2 = XEXP (x1, 0);
  goto L174;

 L124: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 16;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L174;

 L6781: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, XFmode))
    {
      operands[0] = x2;
      goto L136;
    }
  goto L174;

 L136: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L137;
    }
  x2 = XEXP (x1, 0);
  goto L174;

 L137: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 18;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L174;

 L6782: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, TFmode))
    {
      operands[0] = x2;
      goto L142;
    }
  goto L174;

 L142: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L143;
    }
  x2 = XEXP (x1, 0);
  goto L174;

 L143: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 19;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L174;

 L175: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == FLOAT)
    goto L176;
  x1 = XEXP (x0, 0);
  goto L1;

 L176: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L177;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L177: ATTRIBUTE_UNUSED_LABEL
  if ((0 && TARGET_80387 && FLOAT_MODE_P (GET_MODE (operands[0]))
   && GET_MODE (XEXP (SET_SRC (PATTERN (insn)), 1)) == GET_MODE (operands[0])))
    {
      return 24;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6687: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 18)
    goto L160;
  goto L1;

 L160: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == CCFPUmode
      && GET_CODE (x1) == COMPARE)
    goto L161;
  x1 = XEXP (x0, 0);
  goto L1;

 L161: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L162;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L162: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L163;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L163: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[0]))
   && GET_MODE (operands[0]) == GET_MODE (operands[1])))
    {
      return 22;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6688: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L184;
  goto L1;

 L184: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == CCmode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 10)
    goto L185;
  x1 = XEXP (x0, 0);
  goto L1;

 L185: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      return 26;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6689: ATTRIBUTE_UNUSED_LABEL
  tem = recog_2 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L1;

 L6694: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L312;
    }
 L6695: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L365;
    }
 L6717: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L1444;
    }
  goto L1;

 L312: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_no_elim_operand (x1, QImode))
    {
      operands[1] = x1;
      return 44;
    }
  x1 = XEXP (x0, 0);
  goto L6695;

 L365: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode)
    goto L6828;
 L325: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, QImode))
    {
      operands[1] = x1;
      goto L326;
    }
 L377: ATTRIBUTE_UNUSED_LABEL
  if (GET_MODE (x1) == QImode
      && GET_CODE (x1) == SUBREG
      && XINT (x1, 1) == 0)
    goto L378;
  x1 = XEXP (x0, 0);
  goto L6717;

 L6828: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case SIGN_EXTRACT:
      goto L366;
    case PLUS:
      goto L1119;
    case MINUS:
      goto L1379;
    case AND:
      goto L1908;
    case IOR:
      goto L2162;
    case XOR:
      goto L2327;
    case NEG:
      goto L2482;
    case NOT:
      goto L2726;
    case ASHIFT:
      goto L2873;
    case ASHIFTRT:
      goto L3091;
    case LSHIFTRT:
      goto L3283;
    case ROTATE:
      goto L3393;
    case ROTATERT:
      goto L3477;
    case EQ:
    case NE:
    case LE:
    case LT:
    case GE:
    case GT:
    case LEU:
    case LTU:
    case GEU:
    case GTU:
    case UNORDERED:
    case ORDERED:
    case UNLE:
    case UNLT:
    case UNGE:
    case UNGT:
    case LTGT:
    case UNEQ:
      goto L6841;
    default:
      goto L325;
   }
 L6841: ATTRIBUTE_UNUSED_LABEL
  if (ix86_comparison_operator (x1, QImode))
    {
      operands[1] = x1;
      goto L3497;
    }
  goto L325;

 L366: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L367;
    }
  goto L325;

 L367: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    goto L368;
  goto L325;

 L368: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 8)
    {
      return 52;
    }
  goto L325;

 L1119: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L1120;
    }
  goto L325;

 L1120: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L1121;
    }
  goto L325;

 L1121: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (PLUS, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 146;
    }
 L1135: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (PLUS, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 147;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L1379: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L1380;
    }
  goto L325;

 L1380: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L1381;
    }
  goto L325;

 L1381: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (MINUS, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 162;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L1908: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L1909;
    }
  goto L325;

 L1909: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L1910;
    }
  goto L325;

 L1910: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (AND, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 194;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L2162: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L2163;
    }
  goto L325;

 L2163: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2164;
    }
  goto L325;

 L2164: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (IOR, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 208;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L2327: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L2328;
    }
  goto L325;

 L2328: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2329;
    }
  goto L325;

 L2329: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (XOR, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 219;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L2482: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L2483;
    }
  goto L325;

 L2483: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_unary_operator_ok (NEG, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 229;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L2726: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L2727;
    }
  goto L325;

 L2727: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_unary_operator_ok (NOT, QImode, operands)))
    {
      return 261;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L2873: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L2874;
    }
  goto L325;

 L2874: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2875;
    }
  goto L325;

 L2875: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (ASHIFT, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 271;
    }
 L2889: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (ASHIFT, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 272;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L3091: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L3092;
    }
  goto L325;

 L3092: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3093;
    }
 L3106: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3107;
    }
  goto L325;

 L3093: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ASHIFTRT, QImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 286;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3106;

 L3107: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ASHIFTRT, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 287;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L3283: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L3284;
    }
  goto L325;

 L3284: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3285;
    }
 L3298: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3299;
    }
  goto L325;

 L3285: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (LSHIFTRT, QImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 300;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3298;

 L3299: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (LSHIFTRT, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 301;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L3393: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L3394;
    }
  goto L325;

 L3394: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3395;
    }
 L3408: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3409;
    }
  goto L325;

 L3395: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATE, QImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 308;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3408;

 L3409: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATE, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 309;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L3477: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L3478;
    }
  goto L325;

 L3478: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const_int_1_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3479;
    }
 L3492: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3493;
    }
  goto L325;

 L3479: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATERT, QImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 314;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L3492;

 L3493: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_binary_operator_ok (ROTATERT, QImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 315;
    }
  x1 = XEXP (x0, 1);
  goto L325;

 L3497: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L3498;
  goto L325;

 L3498: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0)
    {
      return 316;
    }
  goto L325;

 L326: ATTRIBUTE_UNUSED_LABEL
  if ((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM))
    {
      return 46;
    }
  x1 = XEXP (x0, 1);
  goto L377;

 L378: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTRACT)
    goto L379;
  x1 = XEXP (x0, 0);
  goto L6717;

 L379: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L380;
    }
  x1 = XEXP (x0, 0);
  goto L6717;

 L380: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L381;
  x1 = XEXP (x0, 0);
  goto L6717;

 L381: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    {
      return 54;
    }
  x1 = XEXP (x0, 0);
  goto L6717;

 L1444: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode)
    goto L6842;
  x1 = XEXP (x0, 0);
  goto L1;

 L6842: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case MULT:
      goto L1445;
    case DIV:
      goto L1581;
    case UDIV:
      goto L1595;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L1;

 L1445: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L1446;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1446: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L1447;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1447: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_QIMODE_MATH)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 167;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1581: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L1582;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1582: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L1583;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1583: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_QIMODE_MATH)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 174;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1595: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L1596;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1596: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L1597;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1597: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_QIMODE_MATH)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 175;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6697: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, DImode))
    {
      operands[0] = x1;
      goto L400;
    }
 L6698: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, DImode))
    {
      operands[0] = x1;
      goto L572;
    }
 L6718: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, DImode))
    {
      operands[0] = x1;
      goto L1496;
    }
  goto L1;

 L400: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_no_elim_operand (x1, DImode))
    {
      operands[1] = x1;
      return 57;
    }
  x1 = XEXP (x0, 0);
  goto L6698;

 L572: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DImode)
    goto L6845;
 L403: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, DImode))
    {
      operands[1] = x1;
      goto L404;
    }
  x1 = XEXP (x0, 0);
  goto L6718;

 L6845: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case ZERO_EXTEND:
      goto L573;
    case SIGN_EXTEND:
      goto L587;
    case PLUS:
      goto L864;
    case MINUS:
      goto L1267;
    case NEG:
      goto L2424;
    default:
     break;
   }
  goto L403;

 L573: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (general_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L574;
    }
  goto L403;

 L574: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 85;
    }
  x1 = XEXP (x0, 1);
  goto L403;

 L587: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L588;
    }
  goto L403;

 L588: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 86;
    }
  x1 = XEXP (x0, 1);
  goto L403;

 L864: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L865;
    }
  goto L403;

 L865: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, DImode))
    {
      operands[2] = x2;
      goto L866;
    }
  goto L403;

 L866: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 127;
    }
  x1 = XEXP (x0, 1);
  goto L403;

 L1267: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L1268;
    }
  goto L403;

 L1268: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, DImode))
    {
      operands[2] = x2;
      goto L1269;
    }
  goto L403;

 L1269: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 154;
    }
  x1 = XEXP (x0, 1);
  goto L403;

 L2424: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (general_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L2425;
    }
  goto L403;

 L2425: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_unary_operator_ok (NEG, DImode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 224;
    }
  x1 = XEXP (x0, 1);
  goto L403;

 L404: ATTRIBUTE_UNUSED_LABEL
  if ((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM))
    {
      return 58;
    }
  x1 = XEXP (x0, 0);
  goto L6718;

 L1496: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DImode)
    goto L6850;
  x1 = XEXP (x0, 0);
  goto L1;

 L6850: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case MULT:
      goto L1497;
    case ASHIFT:
      goto L2752;
    case ASHIFTRT:
      goto L2916;
    case LSHIFTRT:
      goto L3147;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L1;

 L1497: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode)
    goto L6854;
  x1 = XEXP (x0, 0);
  goto L1;

 L6854: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L1498;
    case SIGN_EXTEND:
      goto L1516;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L1;

 L1498: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1499;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1499: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == ZERO_EXTEND)
    goto L1500;
  x1 = XEXP (x0, 0);
  goto L1;

 L1500: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1501;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1501: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 170;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1516: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1517;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1517: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == SIGN_EXTEND)
    goto L1518;
  x1 = XEXP (x0, 0);
  goto L1;

 L1518: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1519;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L1519: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 171;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2752: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L2753;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2753: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2754;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2754: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 263;
    }
 L2768: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 264;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2916: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L2917;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2917: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L2918;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2918: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 274;
    }
 L2932: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 275;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3147: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L3148;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3148: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L3149;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3149: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 290;
    }
 L3163: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 291;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6699: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, SFmode))
    {
      operands[0] = x1;
      goto L407;
    }
 L6700: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, SFmode))
    {
      operands[0] = x1;
      goto L2504;
    }
 L6707: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, SFmode))
    {
      operands[0] = x1;
      goto L661;
    }
 L6711: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, SFmode))
    {
      operands[0] = x1;
      goto L795;
    }
  goto L1;

 L407: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_no_elim_operand (x1, SFmode))
    {
      operands[1] = x1;
      return 59;
    }
  x1 = XEXP (x0, 0);
  goto L6700;

 L2504: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SFmode)
    goto L6856;
 L410: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, SFmode))
    {
      operands[1] = x1;
      goto L411;
    }
  x1 = XEXP (x0, 0);
  goto L6707;

 L6856: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case NEG:
      goto L2505;
    case ABS:
      goto L2603;
    default:
     break;
   }
  goto L410;

 L2505: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L2506;
    }
  goto L410;

 L2506: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && ix86_unary_operator_ok (NEG, SFmode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 231;
    }
  x1 = XEXP (x0, 1);
  goto L410;

 L2603: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L2604;
    }
  goto L410;

 L2604: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && ix86_unary_operator_ok (ABS, SFmode, operands))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 244;
    }
  x1 = XEXP (x0, 1);
  goto L410;

 L411: ATTRIBUTE_UNUSED_LABEL
  if (((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && (reload_in_progress || reload_completed
       || GET_CODE (operands[1]) != CONST_DOUBLE
       || memory_operand (operands[0], SFmode))))
    {
      return 60;
    }
  x1 = XEXP (x0, 0);
  goto L6707;

 L661: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SFmode
      && GET_CODE (x1) == FLOAT_TRUNCATE)
    goto L662;
  x1 = XEXP (x0, 0);
  goto L6711;

 L662: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case DFmode:
      goto L6858;
    case XFmode:
      goto L6859;
    case TFmode:
      goto L6860;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L6711;

 L6858: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L663;
    }
  x1 = XEXP (x0, 0);
  goto L6711;

 L663: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 101;
    }
  x1 = XEXP (x0, 0);
  goto L6711;

 L6859: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L676;
    }
  x1 = XEXP (x0, 0);
  goto L6711;

 L676: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 103;
    }
  x1 = XEXP (x0, 0);
  goto L6711;

 L6860: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L689;
    }
  x1 = XEXP (x0, 0);
  goto L6711;

 L689: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 105;
    }
  x1 = XEXP (x0, 0);
  goto L6711;

 L795: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SFmode)
    goto L6861;
  x1 = XEXP (x0, 0);
  goto L1;

 L6861: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case FLOAT:
      goto L796;
    case NEG:
      goto L2546;
    case ABS:
      goto L2644;
    case SQRT:
      goto L4005;
    case UNSPEC:
      goto L6869;
    case IF_THEN_ELSE:
      goto L4401;
    case PLUS:
    case MINUS:
    case MULT:
    case DIV:
      goto L6864;
    default:
      x1 = XEXP (x0, 0);
      goto L1;
   }
 L6864: ATTRIBUTE_UNUSED_LABEL
  if (binary_fp_operator (x1, SFmode))
    {
      operands[3] = x1;
      goto L3831;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L796: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L6871;
    case SImode:
      goto L6872;
    case DImode:
      goto L6873;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6871: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L797;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L797: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 115;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6872: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L802;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L802: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 116;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6873: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L807;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L807: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 117;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2546: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L2547;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2547: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return 235;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2644: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L2645;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L2645: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return 248;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4005: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L4006;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4006: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387))
    {
      return 371;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6869: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1)
    goto L6874;
  x1 = XEXP (x0, 0);
  goto L1;

 L6874: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x1, 1))
    {
    case 1:
      goto L4060;
    case 2:
      goto L4086;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4060: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L4061;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4061: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 381;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4086: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L4087;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4087: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_NO_FANCY_MATH_387 && TARGET_80387 && flag_fast_math))
    {
      return 386;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4401: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (fcmov_comparison_operator (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L4402;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4402: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L4403;
  x1 = XEXP (x0, 0);
  goto L1;

 L4403: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4404;
  x1 = XEXP (x0, 0);
  goto L1;

 L4404: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L4405;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4405: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (register_operand (x2, SFmode))
    {
      operands[3] = x2;
      goto L4406;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L4406: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE))
    {
      return 407;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3831: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SFmode)
    goto L6878;
  x1 = XEXP (x0, 0);
  goto L1;

 L6878: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT)
    goto L3862;
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L3832;
    }
 L6877: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L3856;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3862: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L3863;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3863: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L3864;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3864: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_USE_FIOP))
    {
      return 350;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3832: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SFmode)
    goto L6880;
  x2 = XEXP (x1, 0);
  goto L6877;

 L6880: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == FLOAT)
    goto L3870;
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L3833;
    }
  x2 = XEXP (x1, 0);
  goto L6877;

 L3870: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L3871;
    }
  x2 = XEXP (x1, 0);
  goto L6877;

 L3871: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_USE_FIOP))
    {
      return 351;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L6877;

 L3833: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && GET_RTX_CLASS (GET_CODE (operands[3])) == 'c'))
    {
      return 345;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  goto L6877;

 L3856: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L3857;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L3857: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && GET_RTX_CLASS (GET_CODE (operands[3])) != 'c'
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 349;
    }
  x1 = XEXP (x0, 0);
  goto L1;

 L6701: ATTRIBUTE_UNUSED_LABEL
  tem = recog_3 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L1;

 L6703: ATTRIBUTE_UNUSED_LABEL
  tem = recog_4 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L1;

 L6704: ATTRIBUTE_UNUSED_LABEL
  tem = recog_5 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L1;

 L2: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == COMPARE)
    goto L3;
  x1 = XEXP (x0, 0);
  goto L187;

 L3: ATTRIBUTE_UNUSED_LABEL
  tem = recog_6 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  x1 = XEXP (x0, 0);
  goto L187;

 L6720: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L188;
  goto L294;

 L188: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == CCFPmode
      && GET_CODE (x1) == COMPARE)
    goto L189;
  x1 = XEXP (x0, 0);
  goto L294;

 L189: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L190;
    }
  x1 = XEXP (x0, 0);
  goto L294;

 L190: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L191;
    }
  x1 = XEXP (x0, 0);
  goto L294;

 L191: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_CMOVE
   && FLOAT_MODE_P (GET_MODE (operands[0]))
   && GET_MODE (operands[0]) == GET_MODE (operands[0])))
    {
      return 27;
    }
  x1 = XEXP (x0, 0);
  goto L294;

 L6721: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L194;
  goto L294;

 L194: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == CCFPUmode
      && GET_CODE (x1) == COMPARE)
    goto L195;
  x1 = XEXP (x0, 0);
  goto L294;

 L195: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L196;
    }
  x1 = XEXP (x0, 0);
  goto L294;

 L196: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L197;
    }
  x1 = XEXP (x0, 0);
  goto L294;

 L197: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && TARGET_CMOVE
   && FLOAT_MODE_P (GET_MODE (operands[0]))
   && GET_MODE (operands[0]) == GET_MODE (operands[1])))
    {
      return 28;
    }
  x1 = XEXP (x0, 0);
  goto L294;

 L295: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case HImode:
      goto L7037;
    case QImode:
      goto L7039;
    default:
      break;
    }
  goto L4492;

 L7037: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L296;
    }
 L7038: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L308;
    }
  goto L4492;

 L296: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, HImode))
    {
      operands[1] = x1;
      goto L297;
    }
  x1 = XEXP (x0, 0);
  x2 = XEXP (x1, 0);
  goto L7038;

 L297: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_PARTIAL_REG_STALL
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)))
    {
      return 42;
    }
  x1 = XEXP (x0, 0);
  x2 = XEXP (x1, 0);
  goto L7038;

 L308: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (const0_operand (x1, HImode))
    {
      operands[1] = x1;
      goto L309;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L309: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && (!TARGET_USE_MOV0 || optimize_size))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 43;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L7039: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L1923;
    }
 L7040: ATTRIBUTE_UNUSED_LABEL
  if (q_regs_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L349;
    }
  goto L4492;

 L1923: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode)
    goto L7041;
 L337: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, QImode))
    {
      operands[1] = x1;
      goto L338;
    }
  x1 = XEXP (x0, 0);
  x2 = XEXP (x1, 0);
  goto L7040;

 L7041: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case AND:
      goto L1924;
    case IOR:
      goto L2178;
    case EQ:
    case NE:
    case LE:
    case LT:
    case GE:
    case GT:
    case LEU:
    case LTU:
    case GEU:
    case GTU:
    case UNORDERED:
    case ORDERED:
    case UNLE:
    case UNLT:
    case UNGE:
    case UNGT:
    case LTGT:
    case UNEQ:
      goto L7043;
    default:
      goto L337;
   }
 L7043: ATTRIBUTE_UNUSED_LABEL
  if (ix86_comparison_operator (x1, QImode))
    {
      operands[1] = x1;
      goto L3503;
    }
  goto L337;

 L1924: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L1925;
  goto L337;

 L1925: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L1926;
    }
  goto L337;

 L1926: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 195;
    }
  x1 = XEXP (x0, 1);
  goto L337;

 L2178: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L2179;
  goto L337;

 L2179: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L2180;
    }
  goto L337;

 L2180: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 209;
    }
  x1 = XEXP (x0, 1);
  goto L337;

 L3503: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L3504;
  goto L337;

 L3504: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0)
    {
      return 317;
    }
  goto L337;

 L338: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_PARTIAL_REG_STALL
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)))
    {
      return 48;
    }
  x1 = XEXP (x0, 0);
  x2 = XEXP (x1, 0);
  goto L7040;

 L349: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (const0_operand (x1, QImode))
    {
      operands[1] = x1;
      goto L350;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L350: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && (!TARGET_USE_MOV0 || optimize_size))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 49;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L3682: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonimmediate_operand (x1, SImode))
    {
      operands[0] = x1;
      return 327;
    }
  switch (GET_CODE (x1))
    {
    case IF_THEN_ELSE:
      goto L3508;
    case LABEL_REF:
      goto L3679;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L4492;

 L3508: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (ix86_comparison_operator (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L3509;
    }
 L3540: ATTRIBUTE_UNUSED_LABEL
  if (comparison_operator (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L3541;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L3509: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L3510;
  goto L3540;

 L3510: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3511;
  goto L3540;

 L3511: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L3512;
    case PC:
      goto L3521;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L3540;

 L3512: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  goto L3513;

 L3513: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC)
    {
      return 318;
    }
  x2 = XEXP (x1, 0);
  goto L3540;

 L3521: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L3522;
  x2 = XEXP (x1, 0);
  goto L3540;

 L3522: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[0] = x3;
  return 319;

 L3541: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L3542;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L3542: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L3543;
    }
 L3592: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L3593;
    }
 L3645: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L3646;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L3543: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L3544;
    case PC:
      goto L3567;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L3592;

 L3544: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[3] = x3;
  goto L3545;

 L3545: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC
      && (TARGET_CMOVE && TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2]))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 320;
    }
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L3592;

 L3567: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L3568;
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L3592;

 L3568: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[3] = x3;
  goto L3569;

 L3569: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_CMOVE && TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2]))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 321;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L3592;

 L3593: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L3594;
    case PC:
      goto L3620;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L3645;

 L3594: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[3] = x3;
  goto L3595;

 L3595: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC
      && (TARGET_80387
   && (GET_MODE (operands[1]) == SFmode || GET_MODE (operands[1]) == DFmode)
   && GET_MODE (operands[1]) == GET_MODE (operands[2])
   && !ix86_use_fcomi_compare (GET_CODE (operands[0]))
   && SELECT_CC_MODE (GET_CODE (operands[0]),
		      operands[1], operands[2]) == CCFPmode)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 3;
      return 322;
    }
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L3645;

 L3620: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L3621;
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L3645;

 L3621: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[3] = x3;
  goto L3622;

 L3622: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_MODE (operands[1]) == SFmode || GET_MODE (operands[1]) == DFmode)
   && GET_MODE (operands[1]) == GET_MODE (operands[2])
   && !ix86_use_fcomi_compare (GET_CODE (operands[0]))
   && SELECT_CC_MODE (GET_CODE (operands[0]),
		      operands[1], operands[2]) == CCFPmode)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 3;
      return 323;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 1);
  goto L3645;

 L3646: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case LABEL_REF:
      goto L3647;
    case PC:
      goto L3673;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L4492;

 L3647: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[3] = x3;
  goto L3648;

 L3648: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == PC
      && (TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2]))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 3;
      return 324;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L3673: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == LABEL_REF)
    goto L3674;
  x1 = XEXP (x0, 0);
  goto L4492;

 L3674: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[3] = x3;
  goto L3675;

 L3675: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2]))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 3;
      return 325;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L3679: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  operands[0] = x2;
  return 326;

 L916: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == PLUS)
    goto L917;
  x1 = XEXP (x0, 0);
  goto L4492;

 L917: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_CODE (x2))
    {
    case PLUS:
      goto L934;
    case MULT:
      goto L926;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L4492;

 L934: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == MULT)
    goto L935;
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L919;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L935: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L936;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L936: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const248_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L937;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L937: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, VOIDmode))
    {
      operands[3] = x3;
      goto L938;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L938: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (immediate_operand (x2, VOIDmode))
    {
      operands[4] = x2;
      goto L939;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L939: ATTRIBUTE_UNUSED_LABEL
  if (((GET_MODE (operands[0]) == QImode || GET_MODE (operands[0]) == HImode)
   && (!TARGET_PARTIAL_REG_STALL || optimize_size)
   && GET_MODE (operands[0]) == GET_MODE (operands[1])
   && GET_MODE (operands[0]) == GET_MODE (operands[3])))
    {
      return 134;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L919: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L920;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L920: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (immediate_operand (x2, VOIDmode))
    {
      operands[3] = x2;
      goto L921;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L921: ATTRIBUTE_UNUSED_LABEL
  if (((GET_MODE (operands[0]) == QImode || GET_MODE (operands[0]) == HImode)
   && (!TARGET_PARTIAL_REG_STALL || optimize_size)
   && GET_MODE (operands[0]) == GET_MODE (operands[1])
   && GET_MODE (operands[0]) == GET_MODE (operands[2])
   && (GET_MODE (operands[0]) == GET_MODE (operands[3])
       || GET_MODE (operands[3]) == VOIDmode)))
    {
      return 132;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L926: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L927;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L927: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const248_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L928;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L928: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, VOIDmode))
    {
      operands[3] = x2;
      goto L929;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L929: ATTRIBUTE_UNUSED_LABEL
  if (((GET_MODE (operands[0]) == QImode || GET_MODE (operands[0]) == HImode)
   && (!TARGET_PARTIAL_REG_STALL || optimize_size)
   && GET_MODE (operands[0]) == GET_MODE (operands[1])
   && (GET_MODE (operands[0]) == GET_MODE (operands[3])
       || GET_MODE (operands[3]) == VOIDmode)))
    {
      return 133;
    }
  x1 = XEXP (x0, 0);
  goto L4492;

 L4493: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CALL)
    goto L4494;
  x1 = XEXP (x0, 0);
  goto L4512;

 L4494: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == MEM)
    goto L4495;
  x1 = XEXP (x0, 0);
  goto L4512;

 L4495: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7044;
  x1 = XEXP (x0, 0);
  goto L4512;

 L7044: ATTRIBUTE_UNUSED_LABEL
  if (constant_call_address_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L4496;
    }
 L7045: ATTRIBUTE_UNUSED_LABEL
  if (call_insn_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L4502;
    }
  x1 = XEXP (x0, 0);
  goto L4512;

 L4496: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  operands[2] = x2;
  return 415;

 L4502: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  operands[2] = x2;
  return 416;

 L6722: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, V4SFmode))
    {
      operands[0] = x1;
      goto L4561;
    }
 L6728: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V4SFmode))
    {
      operands[0] = x1;
      goto L4537;
    }
 L6736: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, V4SFmode))
    {
      operands[0] = x1;
      goto L4588;
    }
 L6738: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, V4SFmode))
    {
      operands[0] = x1;
      goto L4598;
    }
  goto L5473;

 L4561: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == V4SFmode)
    goto L7046;
 L4513: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, V4SFmode))
    {
      operands[1] = x1;
      goto L4514;
    }
  x1 = XEXP (x0, 0);
  goto L6728;

 L7046: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case UNSPEC:
      goto L7049;
    case VEC_MERGE:
      goto L4623;
    default:
     break;
   }
  goto L4513;

 L7049: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1)
    goto L7051;
  goto L4513;

 L7051: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x1, 1))
    {
    case 38:
      goto L4562;
    case 39:
      goto L4567;
    default:
      break;
    }
  goto L4513;

 L4562: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (general_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4563;
    }
  goto L4513;

 L4563: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 431;
    }
  x1 = XEXP (x0, 1);
  goto L4513;

 L4567: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (general_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4568;
    }
  goto L4513;

 L4568: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 432;
    }
  x1 = XEXP (x0, 1);
  goto L4513;

 L4623: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4624;
    }
  goto L4513;

 L4624: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4625;
    }
  goto L4513;

 L4625: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT)
    goto L7053;
  goto L4513;

 L7053: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x2, 0))
    {
    case 12:
      goto L7055;
    case 3:
      goto L7056;
    default:
      break;
    }
  goto L4513;

 L7055: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE && (GET_CODE (operands[1]) == MEM || GET_CODE (operands[2]) == MEM)))
    {
      return 440;
    }
  goto L4513;

 L7056: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE && (GET_CODE (operands[1]) == MEM || GET_CODE (operands[2]) == MEM)))
    {
      return 441;
    }
  goto L4513;

 L4514: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 419;
    }
  x1 = XEXP (x0, 0);
  goto L6728;

 L4537: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V4SFmode))
    {
      operands[1] = x1;
      goto L4538;
    }
  x1 = XEXP (x0, 0);
  goto L6736;

 L4538: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 425;
    }
  x1 = XEXP (x0, 0);
  goto L6736;

 L4588: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == V4SFmode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 34)
    goto L4589;
  x1 = XEXP (x0, 0);
  goto L6738;

 L4589: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4590;
    }
  x1 = XEXP (x0, 0);
  goto L6738;

 L4590: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 436;
    }
  x1 = XEXP (x0, 0);
  goto L6738;

 L4598: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == V4SFmode)
    goto L7057;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7057: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case VEC_MERGE:
      goto L4599;
    case UNSPEC:
      goto L7068;
    case PLUS:
      goto L4662;
    case MINUS:
      goto L4676;
    case MULT:
      goto L4690;
    case DIV:
      goto L4704;
    case SQRT:
      goto L4742;
    case SMAX:
      goto L4872;
    case SMIN:
      goto L4886;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4599: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V4SFmode)
    goto L7073;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7073: ATTRIBUTE_UNUSED_LABEL
  tem = recog_7 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7068: ATTRIBUTE_UNUSED_LABEL
  switch (XVECLEN (x1, 0))
    {
    case 3:
      goto L7098;
    case 1:
      goto L7099;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L7098: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x1, 1) == 41)
    goto L4655;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4655: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4656;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4656: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4657;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4657: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 2);
  if (immediate_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L4658;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4658: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 445;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L7099: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x1, 1))
    {
    case 42:
      goto L4718;
    case 43:
      goto L4730;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4718: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4719;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4719: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 454;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4730: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4731;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4731: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 456;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4662: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4663;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4663: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4664;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4664: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 446;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4676: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4677;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4677: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4678;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4678: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 448;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4690: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4691;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4691: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4692;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4692: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 450;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4704: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4705;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4705: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4706;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4706: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 452;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4742: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4743;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4743: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 458;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4872: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4873;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4873: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4874;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4874: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 473;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4886: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4887;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4887: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4888;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4888: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 475;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L6723: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, V4SImode))
    {
      operands[0] = x1;
      goto L4517;
    }
 L6729: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V4SImode))
    {
      operands[0] = x1;
      goto L4541;
    }
  if (register_operand (x1, V4SImode))
    {
      operands[0] = x1;
      goto L4782;
    }
  goto L5473;

 L4517: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, V4SImode))
    {
      operands[1] = x1;
      goto L4518;
    }
  x1 = XEXP (x0, 0);
  goto L6729;

 L4518: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 420;
    }
  x1 = XEXP (x0, 0);
  goto L6729;

 L4541: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V4SImode))
    {
      operands[1] = x1;
      goto L4542;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4542: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 426;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4782: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == V4SImode)
    goto L7102;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7102: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case NOT:
      goto L4789;
    case VEC_MERGE:
      goto L4796;
    case EQ:
    case LT:
    case LE:
    case UNORDERED:
      goto L7101;
    default:
      x1 = XEXP (x0, 0);
      goto L5473;
   }
 L7101: ATTRIBUTE_UNUSED_LABEL
  if (sse_comparison_operator (x1, V4SImode))
    {
      operands[3] = x1;
      goto L4783;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4789: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (sse_comparison_operator (x2, V4SImode))
    {
      operands[3] = x2;
      goto L4790;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4790: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4791;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4791: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4792;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4792: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 466;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4796: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V4SImode)
    goto L7105;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7105: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == NOT)
    goto L4805;
  if (sse_comparison_operator (x2, V4SImode))
    {
      operands[3] = x2;
      goto L4797;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4805: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (sse_comparison_operator (x3, V4SImode))
    {
      operands[3] = x3;
      goto L4806;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4806: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, V4SFmode))
    {
      operands[1] = x4;
      goto L4807;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4807: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonimmediate_operand (x4, V4SFmode))
    {
      operands[2] = x4;
      goto L4808;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4808: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V4SImode
      && GET_CODE (x2) == SUBREG
      && XINT (x2, 1) == 0)
    goto L4809;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4809: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L4810;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4810: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 468;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4797: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4798;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4798: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, V4SFmode))
    {
      operands[2] = x3;
      goto L4799;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4799: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[1]))
    goto L4800;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4800: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_SSE))
    {
      return 467;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4783: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4784;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4784: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V4SFmode))
    {
      operands[2] = x2;
      goto L4785;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4785: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 465;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L6735: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == MEM)
    goto L4581;
 L6724: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, V8QImode))
    {
      operands[0] = x1;
      goto L4521;
    }
 L6732: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V8QImode))
    {
      operands[0] = x1;
      goto L4553;
    }
  if (register_operand (x1, V8QImode))
    {
      operands[0] = x1;
      goto L4945;
    }
  goto L5473;

 L4581: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4582;
    }
  goto L6724;

 L4582: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == V8QImode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 2
      && XINT (x1, 1) == 32)
    goto L4583;
  x1 = XEXP (x0, 0);
  goto L6724;

 L4583: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L4584;
    }
  x1 = XEXP (x0, 0);
  goto L6724;

 L4584: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 1);
  if (register_operand (x2, V8QImode))
    {
      operands[2] = x2;
      goto L4585;
    }
  x1 = XEXP (x0, 0);
  goto L6724;

 L4585: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 435;
    }
  x1 = XEXP (x0, 0);
  goto L6724;

 L4521: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, V8QImode))
    {
      operands[1] = x1;
      goto L4522;
    }
  x1 = XEXP (x0, 0);
  goto L6732;

 L4522: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 421;
    }
  x1 = XEXP (x0, 0);
  goto L6732;

 L4553: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V8QImode))
    {
      operands[1] = x1;
      goto L4554;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4554: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 429;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4945: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == V8QImode)
    goto L7106;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7106: ATTRIBUTE_UNUSED_LABEL
  tem = recog_8 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  x1 = XEXP (x0, 0);
  goto L5473;

 L6725: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, V4HImode))
    {
      operands[0] = x1;
      goto L4525;
    }
 L6731: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V4HImode))
    {
      operands[0] = x1;
      goto L4549;
    }
  if (register_operand (x1, V4HImode))
    {
      operands[0] = x1;
      goto L4951;
    }
  goto L5473;

 L4525: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, V4HImode))
    {
      operands[1] = x1;
      goto L4526;
    }
  x1 = XEXP (x0, 0);
  goto L6731;

 L4526: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 422;
    }
  x1 = XEXP (x0, 0);
  goto L6731;

 L4549: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V4HImode))
    {
      operands[1] = x1;
      goto L4550;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4550: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 428;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4951: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == V4HImode)
    goto L7124;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7124: ATTRIBUTE_UNUSED_LABEL
  tem = recog_9 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  x1 = XEXP (x0, 0);
  goto L5473;

 L6726: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, V2SImode))
    {
      operands[0] = x1;
      goto L4529;
    }
 L6730: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V2SImode))
    {
      operands[0] = x1;
      goto L4545;
    }
  if (register_operand (x1, V2SImode))
    {
      operands[0] = x1;
      goto L4907;
    }
  goto L5473;

 L4529: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, V2SImode))
    {
      operands[1] = x1;
      goto L4530;
    }
  x1 = XEXP (x0, 0);
  goto L6730;

 L4530: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 423;
    }
  x1 = XEXP (x0, 0);
  goto L6730;

 L4545: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V2SImode))
    {
      operands[1] = x1;
      goto L4546;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4546: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 427;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4907: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == V2SImode)
    goto L7151;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7151: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case VEC_SELECT:
      goto L4908;
    case PLUS:
      goto L4958;
    case MINUS:
      goto L5000;
    case EQ:
      goto L5193;
    case GT:
      goto L5211;
    case ASHIFTRT:
      goto L5247;
    case LSHIFTRT:
      goto L5259;
    case ASHIFT:
      goto L5278;
    case VEC_MERGE:
      goto L5359;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4908: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V4SImode)
    goto L7160;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7160: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FIX:
      goto L4909;
    case UNSPEC:
      goto L7162;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4909: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4910;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4910: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == PARALLEL
      && XVECLEN (x2, 0) == 2)
    goto L4911;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4911: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4912;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4912: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 1
      && (TARGET_SSE))
    {
      return 478;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L7162: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x2, 0) == 1
      && XINT (x2, 1) == 30)
    goto L4917;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4917: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4918;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4918: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == PARALLEL
      && XVECLEN (x2, 0) == 2)
    goto L4919;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4919: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4920;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4920: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 1
      && (TARGET_SSE))
    {
      return 479;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4958: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V2SImode)
    goto L7164;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7164: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == MULT)
    goto L5057;
  if (register_operand (x2, V2SImode))
    {
      operands[1] = x2;
      goto L4959;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5057: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == V2SImode
      && GET_CODE (x3) == SIGN_EXTEND)
    goto L5058;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5058: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == V2HImode
      && GET_CODE (x4) == VEC_SELECT)
    goto L5059;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5059: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, V4HImode))
    {
      operands[1] = x5;
      goto L5060;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5060: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_CODE (x5) == PARALLEL
      && XVECLEN (x5, 0) == 2)
    goto L5061;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5061: ATTRIBUTE_UNUSED_LABEL
  x6 = XVECEXP (x5, 0, 0);
  if (GET_CODE (x6) == CONST_INT
      && XWINT (x6, 0) == 0)
    goto L5062;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5062: ATTRIBUTE_UNUSED_LABEL
  x6 = XVECEXP (x5, 0, 1);
  if (GET_CODE (x6) == CONST_INT
      && XWINT (x6, 0) == 2)
    goto L5063;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5063: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == V2SImode
      && GET_CODE (x3) == SIGN_EXTEND)
    goto L5064;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5064: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == V2HImode
      && GET_CODE (x4) == VEC_SELECT)
    goto L5065;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5065: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (nonimmediate_operand (x5, V4HImode))
    {
      operands[2] = x5;
      goto L5066;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5066: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_CODE (x5) == PARALLEL
      && XVECLEN (x5, 0) == 2)
    goto L5067;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5067: ATTRIBUTE_UNUSED_LABEL
  x6 = XVECEXP (x5, 0, 0);
  if (GET_CODE (x6) == CONST_INT
      && XWINT (x6, 0) == 0)
    goto L5068;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5068: ATTRIBUTE_UNUSED_LABEL
  x6 = XVECEXP (x5, 0, 1);
  if (GET_CODE (x6) == CONST_INT
      && XWINT (x6, 0) == 2)
    goto L5069;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5069: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V2SImode
      && GET_CODE (x2) == MULT)
    goto L5070;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5070: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == V2SImode
      && GET_CODE (x3) == SIGN_EXTEND)
    goto L5071;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5071: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == V2HImode
      && GET_CODE (x4) == VEC_SELECT)
    goto L5072;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5072: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (rtx_equal_p (x5, operands[1]))
    goto L5073;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5073: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_CODE (x5) == PARALLEL
      && XVECLEN (x5, 0) == 2)
    goto L5074;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5074: ATTRIBUTE_UNUSED_LABEL
  x6 = XVECEXP (x5, 0, 0);
  if (GET_CODE (x6) == CONST_INT
      && XWINT (x6, 0) == 1)
    goto L5075;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5075: ATTRIBUTE_UNUSED_LABEL
  x6 = XVECEXP (x5, 0, 1);
  if (GET_CODE (x6) == CONST_INT
      && XWINT (x6, 0) == 3)
    goto L5076;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5076: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == V2SImode
      && GET_CODE (x3) == SIGN_EXTEND)
    goto L5077;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5077: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == V2HImode
      && GET_CODE (x4) == VEC_SELECT)
    goto L5078;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5078: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (rtx_equal_p (x5, operands[2]))
    goto L5079;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5079: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_CODE (x5) == PARALLEL
      && XVECLEN (x5, 0) == 2)
    goto L5080;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5080: ATTRIBUTE_UNUSED_LABEL
  x6 = XVECEXP (x5, 0, 0);
  if (GET_CODE (x6) == CONST_INT
      && XWINT (x6, 0) == 1)
    goto L5081;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5081: ATTRIBUTE_UNUSED_LABEL
  x6 = XVECEXP (x5, 0, 1);
  if (GET_CODE (x6) == CONST_INT
      && XWINT (x6, 0) == 3
      && (TARGET_MMX))
    {
      return 500;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4959: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V2SImode))
    {
      operands[2] = x2;
      goto L4960;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4960: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 485;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5000: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V2SImode))
    {
      operands[1] = x2;
      goto L5001;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5001: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V2SImode))
    {
      operands[2] = x2;
      goto L5002;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5002: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 492;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5193: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V2SImode))
    {
      operands[1] = x2;
      goto L5194;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5194: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V2SImode))
    {
      operands[2] = x2;
      goto L5195;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5195: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 514;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5211: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V2SImode))
    {
      operands[1] = x2;
      goto L5212;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5212: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, V2SImode))
    {
      operands[2] = x2;
      goto L5213;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5213: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 517;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5247: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V2SImode))
    {
      operands[1] = x2;
      goto L5248;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5248: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, DImode))
    {
      operands[2] = x2;
      goto L5249;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5249: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 523;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5259: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V2SImode))
    {
      operands[1] = x2;
      goto L5260;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5260: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, DImode))
    {
      operands[2] = x2;
      goto L5261;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5261: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 525;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5278: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V2SImode))
    {
      operands[1] = x2;
      goto L5279;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5279: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, DImode))
    {
      operands[2] = x2;
      goto L5280;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5280: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 528;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5359: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V2SImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5360;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5360: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V2SImode))
    {
      operands[1] = x3;
      goto L5361;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5361: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 2)
    goto L5362;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5362: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT)
    goto L7165;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7165: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x4, 0))
    {
    case 0:
      goto L5363;
    case 1:
      goto L5421;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5363: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5364;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5364: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V2SImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5365;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5365: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V2SImode))
    {
      operands[2] = x3;
      goto L5366;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5366: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 2)
    goto L5367;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5367: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5368;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5368: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5369;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5369: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_MMX))
    {
      return 535;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5421: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5422;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5422: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == V2SImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5423;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5423: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V2SImode))
    {
      operands[2] = x3;
      goto L5424;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5424: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 2)
    goto L5425;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5425: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L5426;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5426: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L5427;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5427: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 1
      && (TARGET_MMX))
    {
      return 538;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L6727: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, TImode))
    {
      operands[0] = x1;
      goto L4533;
    }
 L6733: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, TImode))
    {
      operands[0] = x1;
      goto L4557;
    }
 L6740: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, TImode))
    {
      operands[0] = x1;
      goto L4753;
    }
  goto L5473;

 L4533: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, TImode))
    {
      operands[1] = x1;
      goto L4534;
    }
  x1 = XEXP (x0, 0);
  goto L6733;

 L4534: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 424;
    }
  x1 = XEXP (x0, 0);
  goto L6733;

 L4557: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, TImode))
    {
      operands[1] = x1;
      goto L4558;
    }
  x1 = XEXP (x0, 0);
  goto L6740;

 L4558: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 430;
    }
  x1 = XEXP (x0, 0);
  goto L6740;

 L4753: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == TImode)
    goto L7167;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7167: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case AND:
      goto L4754;
    case IOR:
      goto L4767;
    case XOR:
      goto L4773;
    case UNSPEC:
      goto L7171;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4754: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == TImode)
    goto L7173;
  x1 = XEXP (x0, 0);
  goto L5473;

 L7173: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == NOT)
    goto L4761;
  if (register_operand (x2, TImode))
    {
      operands[1] = x2;
      goto L4755;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4761: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, TImode))
    {
      operands[1] = x3;
      goto L4762;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4762: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, TImode))
    {
      operands[2] = x2;
      goto L4763;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4763: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 461;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4755: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, TImode))
    {
      operands[2] = x2;
      goto L4756;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4756: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 460;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4767: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, TImode))
    {
      operands[1] = x2;
      goto L4768;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4768: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, TImode))
    {
      operands[2] = x2;
      goto L4769;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4769: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 462;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4773: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, TImode))
    {
      operands[1] = x2;
      goto L4774;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4774: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, TImode))
    {
      operands[2] = x2;
      goto L4775;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4775: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 463;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L7171: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 45)
    goto L4779;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4779: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (TARGET_SSE))
    {
      return 464;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L6734: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L4571;
    }
 L6748: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L5470;
    }
  goto L5473;

 L4571: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode)
    goto L7174;
  x1 = XEXP (x0, 0);
  goto L6748;

 L7174: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case UNSPEC:
      goto L7177;
    case VEC_SELECT:
      goto L4932;
    case ZERO_EXTEND:
      goto L5166;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L6748;

 L7177: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 33)
    goto L4572;
  x1 = XEXP (x0, 0);
  goto L6748;

 L4572: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  switch (GET_MODE (x2))
    {
    case V4SFmode:
      goto L7178;
    case V8QImode:
      goto L7179;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L7178: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4573;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L4573: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 433;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L7179: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, V8QImode))
    {
      operands[1] = x2;
      goto L4578;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L4578: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 434;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L4932: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == V4SImode)
    goto L7180;
  x1 = XEXP (x0, 0);
  goto L6748;

 L7180: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FIX:
      goto L4933;
    case UNSPEC:
      goto L7182;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L6748;

 L4933: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4934;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L4934: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == PARALLEL
      && XVECLEN (x2, 0) == 1)
    goto L4935;
  x1 = XEXP (x0, 0);
  goto L6748;

 L4935: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0
      && (TARGET_SSE))
    {
      return 481;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L7182: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x2, 0) == 1
      && XINT (x2, 1) == 30)
    goto L4940;
  x1 = XEXP (x0, 0);
  goto L6748;

 L4940: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4941;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L4941: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == PARALLEL
      && XVECLEN (x2, 0) == 1)
    goto L4942;
  x1 = XEXP (x0, 0);
  goto L6748;

 L4942: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0
      && (TARGET_SSE))
    {
      return 482;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L5166: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == VEC_SELECT)
    goto L5167;
  x1 = XEXP (x0, 0);
  goto L6748;

 L5167: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4HImode))
    {
      operands[1] = x3;
      goto L5168;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L5168: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 1)
    goto L5169;
  x1 = XEXP (x0, 0);
  goto L6748;

 L5169: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (immediate_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L5170;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L5170: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 510;
    }
  x1 = XEXP (x0, 0);
  goto L6748;

 L5470: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode
      && GET_CODE (x1) == UNSPEC_VOLATILE
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 40)
    goto L5471;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5471: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (TARGET_MMX))
    {
      return 541;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L6737: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, DImode))
    {
      operands[0] = x1;
      goto L4593;
    }
 L6747: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, DImode))
    {
      operands[0] = x1;
      goto L5084;
    }
  goto L5473;

 L4593: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DImode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 34)
    goto L4594;
  x1 = XEXP (x0, 0);
  goto L6747;

 L4594: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, DImode))
    {
      operands[1] = x2;
      goto L4595;
    }
  x1 = XEXP (x0, 0);
  goto L6747;

 L4595: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 437;
    }
  x1 = XEXP (x0, 0);
  goto L6747;

 L5084: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DImode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 45)
    goto L5085;
  x1 = XEXP (x0, 0);
  goto L5473;

 L5085: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_MODE (x2) == DImode)
    goto L7183;
 L5099: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (TARGET_MMX))
    {
      return 503;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L7183: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case IOR:
      goto L5086;
    case XOR:
      goto L5093;
    case AND:
      goto L5104;
    case LSHIFTRT:
      goto L5266;
    case ASHIFT:
      goto L5285;
    default:
     break;
   }
  goto L5099;

 L5086: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L5087;
    }
  goto L5099;

 L5087: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L5088;
    }
  goto L5099;

 L5088: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 501;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  goto L5099;

 L5093: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L5094;
    }
  goto L5099;

 L5094: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L5095;
    }
  goto L5099;

 L5095: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 502;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  goto L5099;

 L5104: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == DImode)
    goto L7189;
  goto L5099;

 L7189: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == NOT)
    goto L5112;
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L5105;
    }
  goto L5099;

 L5112: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, DImode))
    {
      operands[1] = x4;
      goto L5113;
    }
  goto L5099;

 L5113: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L5114;
    }
  goto L5099;

 L5114: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 505;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  goto L5099;

 L5105: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L5106;
    }
  goto L5099;

 L5106: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 504;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  goto L5099;

 L5266: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L5267;
    }
  goto L5099;

 L5267: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L5268;
    }
  goto L5099;

 L5268: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 526;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  goto L5099;

 L5285: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L5286;
    }
  goto L5099;

 L5286: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L5287;
    }
  goto L5099;

 L5287: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 529;
    }
  x1 = XEXP (x0, 1);
  x2 = XVECEXP (x1, 0, 0);
  goto L5099;

 L6739: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, SFmode))
    {
      operands[0] = x1;
      goto L4648;
    }
  goto L5473;

 L4648: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SFmode
      && GET_CODE (x1) == VEC_SELECT)
    goto L4649;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4649: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, V4SFmode))
    {
      operands[1] = x2;
      goto L4650;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4650: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == PARALLEL
      && XVECLEN (x2, 0) == 1)
    goto L4651;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4651: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0
      && (TARGET_SSE))
    {
      return 444;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L6742: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L4813;
  goto L5473;

 L4813: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (sse_comparison_operator (x1, CCFPmode))
    {
      operands[2] = x1;
      goto L4814;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4814: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SFmode
      && GET_CODE (x2) == VEC_SELECT)
    goto L4815;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4815: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[0] = x3;
      goto L4816;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4816: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 1)
    goto L4817;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4817: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4818;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4818: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SFmode
      && GET_CODE (x2) == VEC_SELECT)
    goto L4819;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4819: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4820;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4820: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 1)
    goto L4821;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4821: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0
      && (TARGET_SSE))
    {
      return 469;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L6743: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L4824;
  goto L5473;

 L4824: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (sse_comparison_operator (x1, CCFPUmode))
    {
      operands[2] = x1;
      goto L4825;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4825: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SFmode
      && GET_CODE (x2) == VEC_SELECT)
    goto L4826;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4826: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[0] = x3;
      goto L4827;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4827: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 1)
    goto L4828;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4828: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4829;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4829: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SFmode
      && GET_CODE (x2) == VEC_SELECT)
    goto L4830;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4830: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, V4SFmode))
    {
      operands[1] = x3;
      goto L4831;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L4831: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == PARALLEL
      && XVECLEN (x3, 0) == 1)
    goto L4832;
  x1 = XEXP (x0, 0);
  goto L5473;

 L4832: ATTRIBUTE_UNUSED_LABEL
  x4 = XVECEXP (x3, 0, 0);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0
      && (TARGET_SSE))
    {
      return 470;
    }
  x1 = XEXP (x0, 0);
  goto L5473;

 L5474: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == BLKmode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 44)
    goto L5475;
  goto ret0;

 L5475: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (rtx_equal_p (x2, operands[0])
      && (TARGET_SSE))
    {
      return 542;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_11 PARAMS ((rtx, rtx, int *));
static int
recog_11 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case MEM:
      goto L225;
    case PLUS:
      goto L871;
    case MINUS:
      goto L1274;
    case AND:
      goto L1847;
    case IOR:
      goto L2065;
    case XOR:
      goto L2230;
    case NEG:
      goto L2430;
    case ASHIFT:
      goto L2798;
    case ASHIFTRT:
      goto L2962;
    case LSHIFTRT:
      goto L3168;
    case ROTATE:
      goto L3330;
    case ROTATERT:
      goto L3414;
    default:
     break;
   }
  goto ret0;

 L225: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L226;
  goto ret0;

 L226: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L227;
  goto ret0;

 L227: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L228;
  goto ret0;

 L228: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L229;
  goto ret0;

 L229: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L230;
  goto ret0;

 L230: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 4)
    {
      return 32;
    }
  goto ret0;

 L871: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7229;
  goto ret0;

 L7229: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == PLUS)
    goto L872;
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L945;
    }
  goto ret0;

 L872: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == SImode
      && GET_CODE (x4) == LTU)
    goto L873;
  goto ret0;

 L873: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (GET_MODE (x5) == CCmode
      && GET_CODE (x5) == REG
      && XINT (x5, 0) == 17)
    goto L874;
  goto ret0;

 L874: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 0)
    goto L875;
  goto ret0;

 L875: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L876;
    }
  goto ret0;

 L876: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L877;
    }
  goto ret0;

 L877: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L878;
  goto ret0;

 L878: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (PLUS, SImode, operands)))
    {
      return 128;
    }
  goto ret0;

 L945: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L946;
    }
  goto ret0;

 L946: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L947;
  goto ret0;

 L947: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (PLUS, SImode, operands)))
    {
      return 135;
    }
  goto ret0;

 L1274: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1275;
    }
  goto ret0;

 L1275: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == PLUS)
    goto L1276;
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1298;
    }
  goto ret0;

 L1276: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == SImode
      && GET_CODE (x4) == LTU)
    goto L1277;
  goto ret0;

 L1277: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (GET_MODE (x5) == CCmode
      && GET_CODE (x5) == REG
      && XINT (x5, 0) == 17)
    goto L1278;
  goto ret0;

 L1278: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 0)
    goto L1279;
  goto ret0;

 L1279: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L1280;
    }
  goto ret0;

 L1280: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1281;
  goto ret0;

 L1281: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (MINUS, SImode, operands)))
    {
      return 155;
    }
  goto ret0;

 L1298: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1299;
  goto ret0;

 L1299: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (MINUS, SImode, operands)))
    {
      return 156;
    }
  goto ret0;

 L1847: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1848;
    }
  goto ret0;

 L1848: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1849;
    }
  goto ret0;

 L1849: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1850;
  goto ret0;

 L1850: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (AND, SImode, operands)))
    {
      return 190;
    }
  goto ret0;

 L2065: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7232;
  goto ret0;

 L7232: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x3))
    {
    case ASHIFT:
      goto L2774;
    case ASHIFTRT:
      goto L2938;
    case SUBREG:
    case REG:
    case MEM:
      goto L7231;
    default:
      goto ret0;
   }
 L7231: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2066;
    }
  goto ret0;

 L2774: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[0]))
    goto L2775;
  goto ret0;

 L2775: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonmemory_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2776;
    }
  goto ret0;

 L2776: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == LSHIFTRT)
    goto L2777;
  goto ret0;

 L2777: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L2778;
    }
  goto ret0;

 L2778: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == QImode
      && GET_CODE (x4) == MINUS)
    goto L2779;
  goto ret0;

 L2779: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 32)
    goto L2780;
  goto ret0;

 L2780: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (rtx_equal_p (x5, operands[2]))
    goto L2781;
  goto ret0;

 L2781: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2782;
  goto ret0;

 L2782: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 265;
    }
  goto ret0;

 L2938: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[0]))
    goto L2939;
  goto ret0;

 L2939: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonmemory_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2940;
    }
  goto ret0;

 L2940: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ASHIFT)
    goto L2941;
  goto ret0;

 L2941: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L2942;
    }
  goto ret0;

 L2942: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == QImode
      && GET_CODE (x4) == MINUS)
    goto L2943;
  goto ret0;

 L2943: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 32)
    goto L2944;
  goto ret0;

 L2944: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (rtx_equal_p (x5, operands[2]))
    goto L2945;
  goto ret0;

 L2945: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2946;
  goto ret0;

 L2946: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 276;
    }
  goto ret0;

 L2066: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L2067;
    }
  goto ret0;

 L2067: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2068;
  goto ret0;

 L2068: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (IOR, SImode, operands)))
    {
      return 202;
    }
  goto ret0;

 L2230: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2231;
    }
  goto ret0;

 L2231: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L2232;
    }
  goto ret0;

 L2232: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2233;
  goto ret0;

 L2233: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (XOR, SImode, operands)))
    {
      return 213;
    }
  goto ret0;

 L2430: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2431;
    }
  goto ret0;

 L2431: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2432;
  goto ret0;

 L2432: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_unary_operator_ok (NEG, SImode, operands)))
    {
      return 225;
    }
  goto ret0;

 L2798: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2799;
    }
  goto ret0;

 L2799: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2800;
    }
  goto ret0;

 L2800: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2801;
  goto ret0;

 L2801: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ASHIFT, SImode, operands)))
    {
      return 266;
    }
  goto ret0;

 L2962: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L2963;
    }
  goto ret0;

 L2963: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT)
    goto L7234;
 L2991: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2992;
    }
  goto ret0;

 L7234: ATTRIBUTE_UNUSED_LABEL
  if (const_int_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L2964;
    }
 L7235: ATTRIBUTE_UNUSED_LABEL
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2978;
    }
  goto L2991;

 L2964: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2965;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L7235;

 L2965: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (INTVAL (operands[2]) == 31 && (TARGET_USE_CLTD || optimize_size)
   && ix86_binary_operator_ok (ASHIFTRT, SImode, operands)))
    {
      return 277;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L7235;

 L2978: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2979;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L2991;

 L2979: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ASHIFTRT, SImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 278;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L2991;

 L2992: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2993;
  goto ret0;

 L2993: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ASHIFTRT, SImode, operands)))
    {
      return 279;
    }
  goto ret0;

 L3168: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L3169;
    }
  goto ret0;

 L3169: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3170;
    }
 L3183: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3184;
    }
  goto ret0;

 L3170: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3171;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3183;

 L3171: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (LSHIFTRT, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 292;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3183;

 L3184: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3185;
  goto ret0;

 L3185: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (LSHIFTRT, HImode, operands)))
    {
      return 293;
    }
  goto ret0;

 L3330: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L3331;
    }
  goto ret0;

 L3331: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3332;
    }
 L3345: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3346;
    }
  goto ret0;

 L3332: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3333;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3345;

 L3333: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATE, SImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 304;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3345;

 L3346: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3347;
  goto ret0;

 L3347: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATE, SImode, operands)))
    {
      return 305;
    }
  goto ret0;

 L3414: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L3415;
    }
  goto ret0;

 L3415: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3416;
    }
 L3429: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3430;
    }
  goto ret0;

 L3416: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3417;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3429;

 L3417: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATERT, SImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 310;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3429;

 L3430: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3431;
  goto ret0;

 L3431: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATERT, SImode, operands)))
    {
      return 311;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_12 PARAMS ((rtx, rtx, int *));
static int
recog_12 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  switch (GET_CODE (x2))
    {
    case MEM:
      goto L7211;
    case ZERO_EXTRACT:
      goto L1202;
    default:
     break;
   }
 L7191: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L224;
    }
 L7192: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L258;
    }
  goto ret0;

 L7211: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L204;
    }
  goto L7191;

 L204: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (general_no_elim_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L205;
    }
  x2 = XEXP (x1, 0);
  goto L7191;

 L205: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L206;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7191;

 L206: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L207;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7191;

 L207: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == SCRATCH)
    {
      return 30;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7191;

 L1202: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L1203;
    }
  goto ret0;

 L1203: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L1204;
  goto ret0;

 L1204: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L1205;
  goto ret0;

 L1205: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L7212;
  goto ret0;

 L7212: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case PLUS:
      goto L1206;
    case AND:
      goto L1961;
    case XOR:
      goto L2337;
    default:
     break;
   }
  goto ret0;

 L1206: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L1207;
  goto ret0;

 L1207: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L1208;
    }
  goto ret0;

 L1208: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1209;
  goto ret0;

 L1209: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1236;
  goto ret0;

 L1236: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L1237;
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1211;
    }
  goto ret0;

 L1237: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L1238;
    }
  goto ret0;

 L1238: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1239;
  goto ret0;

 L1239: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1240;
  goto ret0;

 L1240: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1241;
  goto ret0;

 L1241: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 153;
    }
  goto ret0;

 L1211: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1212;
  goto ret0;

 L1212: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 152;
    }
  goto ret0;

 L1961: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L1962;
  goto ret0;

 L1962: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L1963;
    }
  goto ret0;

 L1963: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L1964;
  goto ret0;

 L1964: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2013;
  goto ret0;

 L2013: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode)
    goto L7215;
 L1965: ATTRIBUTE_UNUSED_LABEL
  if (const_int_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L1966;
    }
  goto ret0;

 L7215: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x3))
    {
    case ZERO_EXTEND:
      goto L2014;
    case ZERO_EXTRACT:
      goto L2042;
    default:
     break;
   }
  goto L1965;

 L2014: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (general_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2015;
    }
  goto L1965;

 L2015: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2016;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1965;

 L2016: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 200;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1965;

 L2042: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L2043;
    }
  goto L1965;

 L2043: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2044;
  goto L1965;

 L2044: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2045;
  goto L1965;

 L2045: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2046;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1965;

 L2046: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 201;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1965;

 L1966: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1967;
  goto ret0;

 L1967: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && ((unsigned HOST_WIDE_INT)INTVAL (operands[2]) <= 0xff))
    {
      return 198;
    }
  goto ret0;

 L2337: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L2338;
  goto ret0;

 L2338: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L2339;
    }
  goto ret0;

 L2339: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2340;
  goto ret0;

 L2340: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2341;
  goto ret0;

 L2341: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L2342;
  goto ret0;

 L2342: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L2343;
    }
  goto ret0;

 L2343: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2344;
  goto ret0;

 L2344: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2345;
  goto ret0;

 L2345: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2346;
  goto ret0;

 L2346: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 220;
    }
  goto ret0;

 L224: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L7217;
  x2 = XEXP (x1, 0);
  goto L7192;

 L7217: ATTRIBUTE_UNUSED_LABEL
  tem = recog_11 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  x2 = XEXP (x1, 0);
  goto L7192;

 L258: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L7237;
 L234: ATTRIBUTE_UNUSED_LABEL
  if (const0_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L235;
    }
 L244: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L245;
    }
  goto ret0;

 L7237: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L492;
    case MULT:
      goto L1410;
    case DIV:
      goto L1615;
    case UDIV:
      goto L1716;
    case UNSPEC_VOLATILE:
      goto L7243;
    case IF_THEN_ELSE:
      goto L4365;
    case SUBREG:
    case REG:
      goto L7236;
    default:
      goto L234;
   }
 L7236: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L259;
    }
  goto L234;

 L492: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case HImode:
      goto L7244;
    case QImode:
      goto L7245;
    default:
      break;
    }
  goto L234;

 L7244: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L493;
    }
  goto L234;

 L493: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L494;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L494: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_ZERO_EXTEND_WITH_AND && !optimize_size))
    {
      return 77;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L7245: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L539;
    }
  goto L234;

 L539: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L540;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L540: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7246;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L7246: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7248;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L7248: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7250;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L7250: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_ZERO_EXTEND_WITH_AND && !optimize_size))
    {
      return 82;
    }
 L7251: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_ZERO_EXTEND_WITH_AND || optimize_size))
    {
      return 83;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1410: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1411;
    }
  goto L234;

 L1411: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1412;
    }
  goto L234;

 L1412: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1413;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1413: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
    {
      return 165;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1615: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1616;
    }
  goto L234;

 L1616: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L1617;
    }
  goto L234;

 L1617: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1618;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1618: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L1619;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1619: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MOD)
    goto L1620;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1620: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[2]))
    goto L1621;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1621: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[3])
      && (!optimize_size && !TARGET_USE_CLTD)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 176;
    }
 L1645: ATTRIBUTE_UNUSED_LABEL
  if (rtx_equal_p (x3, operands[3])
      && (optimize_size || TARGET_USE_CLTD)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 177;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1716: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1717;
    }
  goto L234;

 L1717: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1718;
    }
  goto L234;

 L1718: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1719;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1719: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L1720;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1720: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == UMOD)
    goto L1721;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1721: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1722;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L1722: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 180;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L7243: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x2, 0) == 1
      && XINT (x2, 1) == 1)
    goto L3778;
  goto L234;

 L3778: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == PLUS)
    goto L3779;
  goto L234;

 L3779: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[0]))
    goto L3780;
  goto L234;

 L3780: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == SImode
      && GET_CODE (x4) == PLUS)
    goto L3781;
  goto L234;

 L3781: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (symbolic_operand (x5, SImode))
    {
      operands[1] = x5;
      goto L3782;
    }
  goto L234;

 L3782: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_MODE (x5) == SImode
      && GET_CODE (x5) == MINUS)
    goto L3783;
  goto L234;

 L3783: ATTRIBUTE_UNUSED_LABEL
  x6 = XEXP (x5, 0);
  if (GET_CODE (x6) == PC)
    goto L3784;
  goto L234;

 L3784: ATTRIBUTE_UNUSED_LABEL
  x6 = XEXP (x5, 1);
  operands[2] = x6;
  goto L3785;

 L3785: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3786;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L3786: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 340;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L4365: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == LTU)
    goto L4366;
  goto L234;

 L4366: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == CCmode
      && GET_CODE (x4) == REG
      && XINT (x4, 0) == 17)
    goto L4367;
  goto L234;

 L4367: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4368;
  goto L234;

 L4368: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == -1)
    goto L4369;
  goto L234;

 L4369: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4370;
  goto L234;

 L4370: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L4371;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L4371: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 404;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L259: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L260;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L260: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[1]))
    goto L261;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L261: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0]))
    {
      return 36;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L234;

 L235: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L236;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L244;

 L236: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed && (!TARGET_USE_MOV0 || optimize_size)))
    {
      return 33;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  goto L244;

 L245: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L246;
  goto ret0;

 L246: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed && GET_CODE (operands[1]) == CONST_INT
   && INTVAL (operands[1]) == -1
   && (TARGET_PENTIUM || optimize_size)))
    {
      return 34;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_13 PARAMS ((rtx, rtx, int *));
static int
recog_13 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L268;
    }
 L7194: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L282;
    }
  goto ret0;

 L268: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode)
    goto L7252;
  x2 = XEXP (x1, 0);
  goto L7194;

 L7252: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MEM:
      goto L269;
    case PLUS:
      goto L1021;
    case MINUS:
      goto L1334;
    case AND:
      goto L1874;
    case IOR:
      goto L2110;
    case XOR:
      goto L2275;
    case NEG:
      goto L2453;
    case ASHIFT:
      goto L2825;
    case ASHIFTRT:
      goto L3030;
    case LSHIFTRT:
      goto L3222;
    case ROTATE:
      goto L3358;
    case ROTATERT:
      goto L3442;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L7194;

 L269: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L270;
  x2 = XEXP (x1, 0);
  goto L7194;

 L270: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L271;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L271: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L272;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L272: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L273;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L273: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L274;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L274: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 2)
    {
      return 38;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L1021: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1022;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L1022: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1023;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L1023: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1024;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L1024: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7264;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L7264: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7266;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L7266: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7268;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L7268: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (PLUS, HImode, operands)))
    {
      return 140;
    }
 L7269: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (PLUS, HImode, operands)))
    {
      return 141;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L1334: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1335;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L1335: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1336;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L1336: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1337;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L1337: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (MINUS, HImode, operands)))
    {
      return 159;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L1874: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1875;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L1875: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1876;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L1876: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1877;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L1877: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (AND, HImode, operands)))
    {
      return 192;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L2110: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L2111;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L2111: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L2112;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L2112: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2113;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L2113: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (IOR, HImode, operands)))
    {
      return 205;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L2275: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L2276;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L2276: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L2277;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L2277: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2278;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L2278: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (XOR, HImode, operands)))
    {
      return 216;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L2453: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L2454;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L2454: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2455;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L2455: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_unary_operator_ok (NEG, HImode, operands)))
    {
      return 227;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L2825: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L2826;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L2826: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2827;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L2827: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2828;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L2828: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7270;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L7270: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7272;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L7272: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7274;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L7274: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (ASHIFT, HImode, operands)))
    {
      return 268;
    }
 L7275: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (ASHIFT, HImode, operands)))
    {
      return 269;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L3030: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L3031;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L3031: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3032;
    }
 L3045: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3046;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L3032: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3033;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3045;

 L3033: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ASHIFTRT, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 282;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3045;

 L3046: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3047;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L3047: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ASHIFTRT, HImode, operands)))
    {
      return 283;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L3222: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L3223;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L3223: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3224;
    }
 L3237: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3238;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L3224: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3225;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3237;

 L3225: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (LSHIFTRT, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 296;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3237;

 L3238: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3239;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L3239: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (LSHIFTRT, HImode, operands)))
    {
      return 297;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L3358: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L3359;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L3359: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3360;
    }
 L3373: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3374;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L3360: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3361;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3373;

 L3361: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATE, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 306;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3373;

 L3374: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3375;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L3375: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATE, HImode, operands)))
    {
      return 307;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L3442: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L3443;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L3443: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3444;
    }
 L3457: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3458;
    }
  x2 = XEXP (x1, 0);
  goto L7194;

 L3444: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3445;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3457;

 L3445: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATERT, HImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 312;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3457;

 L3458: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3459;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L3459: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATERT, HImode, operands)))
    {
      return 313;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7194;

 L282: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode)
    goto L7277;
  goto ret0;

 L7277: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L509;
    case MULT:
      goto L1424;
    case DIV:
      goto L1692;
    case SUBREG:
    case REG:
      goto L7276;
    default:
      goto ret0;
   }
 L7276: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L283;
    }
  goto ret0;

 L509: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L510;
    }
  goto ret0;

 L510: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L511;
  goto ret0;

 L511: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7280;
  goto ret0;

 L7280: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7282;
  goto ret0;

 L7282: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7284;
  goto ret0;

 L7284: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_ZERO_EXTEND_WITH_AND && !optimize_size))
    {
      return 79;
    }
 L7285: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_ZERO_EXTEND_WITH_AND || optimize_size))
    {
      return 80;
    }
  goto ret0;

 L1424: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == HImode)
    goto L7287;
  goto ret0;

 L7287: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x3))
    {
    case ZERO_EXTEND:
      goto L1453;
    case SIGN_EXTEND:
      goto L1471;
    case SUBREG:
    case REG:
    case MEM:
      goto L7286;
    default:
      goto ret0;
   }
 L7286: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1425;
    }
  goto ret0;

 L1453: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L1454;
    }
  goto ret0;

 L1454: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == HImode
      && GET_CODE (x3) == ZERO_EXTEND)
    goto L1455;
  goto ret0;

 L1455: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L1456;
    }
  goto ret0;

 L1456: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1457;
  goto ret0;

 L1457: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_QIMODE_MATH))
    {
      return 168;
    }
  goto ret0;

 L1471: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L1472;
    }
  goto ret0;

 L1472: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == HImode
      && GET_CODE (x3) == SIGN_EXTEND)
    goto L1473;
  goto ret0;

 L1473: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L1474;
    }
  goto ret0;

 L1474: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1475;
  goto ret0;

 L1475: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_QIMODE_MATH))
    {
      return 169;
    }
  goto ret0;

 L1425: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1426;
    }
  goto ret0;

 L1426: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1427;
  goto ret0;

 L1427: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM))
    {
      return 166;
    }
  goto ret0;

 L1692: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1693;
    }
  goto ret0;

 L1693: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1694;
    }
  goto ret0;

 L1694: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1695;
  goto ret0;

 L1695: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L1696;
    }
  goto ret0;

 L1696: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == MOD)
    goto L1697;
  goto ret0;

 L1697: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1698;
  goto ret0;

 L1698: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (TARGET_HIMODE_MATH)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 179;
    }
  goto ret0;

 L283: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L284;
  goto ret0;

 L284: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[1]))
    goto L285;
  goto ret0;

 L285: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0])
      && (TARGET_PARTIAL_REG_STALL))
    {
      return 40;
    }
 L292: ATTRIBUTE_UNUSED_LABEL
  if (rtx_equal_p (x2, operands[0])
      && (! TARGET_PARTIAL_REG_STALL))
    {
      return 41;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_14 PARAMS ((rtx, rtx, int *));
static int
recog_14 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L316;
    }
 L7196: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L330;
    }
  goto ret0;

 L316: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode)
    goto L7289;
  x2 = XEXP (x1, 0);
  goto L7196;

 L7289: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MEM:
      goto L317;
    case PLUS:
      goto L1112;
    case MINUS:
      goto L1372;
    case AND:
      goto L1901;
    case IOR:
      goto L2155;
    case XOR:
      goto L2320;
    case NEG:
      goto L2476;
    case ASHIFT:
      goto L2866;
    case ASHIFTRT:
      goto L3084;
    case LSHIFTRT:
      goto L3276;
    case ROTATE:
      goto L3386;
    case ROTATERT:
      goto L3470;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L7196;

 L317: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L318;
  x2 = XEXP (x1, 0);
  goto L7196;

 L318: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L319;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L319: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L320;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L320: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L321;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L321: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L322;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L322: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 2)
    {
      return 45;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L1112: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1113;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L1113: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1114;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L1114: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1115;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L1115: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7301;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L7301: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7303;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L7303: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7305;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L7305: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (PLUS, QImode, operands)))
    {
      return 146;
    }
 L7306: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (PLUS, QImode, operands)))
    {
      return 147;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L1372: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1373;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L1373: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1374;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L1374: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1375;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L1375: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (MINUS, QImode, operands)))
    {
      return 162;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L1901: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1902;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L1902: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1903;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L1903: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1904;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L1904: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (AND, QImode, operands)))
    {
      return 194;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L2155: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L2156;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L2156: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2157;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L2157: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2158;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L2158: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (IOR, QImode, operands)))
    {
      return 208;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L2320: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L2321;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L2321: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2322;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L2322: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2323;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L2323: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (XOR, QImode, operands)))
    {
      return 219;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L2476: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L2477;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L2477: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2478;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L2478: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_unary_operator_ok (NEG, QImode, operands)))
    {
      return 229;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L2866: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L2867;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L2867: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2868;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L2868: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2869;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L2869: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7307;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L7307: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7309;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L7309: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7311;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L7311: ATTRIBUTE_UNUSED_LABEL
  if ((!TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (ASHIFT, QImode, operands)))
    {
      return 271;
    }
 L7312: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_PARTIAL_REG_STALL
   && ix86_binary_operator_ok (ASHIFT, QImode, operands)))
    {
      return 272;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L3084: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L3085;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L3085: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3086;
    }
 L3099: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3100;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L3086: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3087;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3099;

 L3087: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ASHIFTRT, QImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 286;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3099;

 L3100: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3101;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L3101: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ASHIFTRT, QImode, operands)))
    {
      return 287;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L3276: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L3277;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L3277: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3278;
    }
 L3291: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3292;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L3278: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3279;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3291;

 L3279: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (LSHIFTRT, QImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 300;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3291;

 L3292: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3293;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L3293: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (LSHIFTRT, QImode, operands)))
    {
      return 301;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L3386: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L3387;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L3387: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3388;
    }
 L3401: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3402;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L3388: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3389;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3401;

 L3389: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATE, QImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 308;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3401;

 L3402: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3403;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L3403: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATE, QImode, operands)))
    {
      return 309;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L3470: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L3471;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L3471: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_1_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3472;
    }
 L3485: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3486;
    }
  x2 = XEXP (x1, 0);
  goto L7196;

 L3472: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3473;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3485;

 L3473: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATERT, QImode, operands)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)))
    {
      return 314;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L3485;

 L3486: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3487;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L3487: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_binary_operator_ok (ROTATERT, QImode, operands)))
    {
      return 315;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7196;

 L330: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode)
    goto L7314;
  goto ret0;

 L7314: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MULT:
      goto L1438;
    case DIV:
      goto L1574;
    case UDIV:
      goto L1588;
    case SUBREG:
    case REG:
      goto L7313;
    default:
      goto ret0;
   }
 L7313: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L331;
    }
  goto ret0;

 L1438: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1439;
    }
  goto ret0;

 L1439: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1440;
    }
  goto ret0;

 L1440: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1441;
  goto ret0;

 L1441: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_QIMODE_MATH))
    {
      return 167;
    }
  goto ret0;

 L1574: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1575;
    }
  goto ret0;

 L1575: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1576;
    }
  goto ret0;

 L1576: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1577;
  goto ret0;

 L1577: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_QIMODE_MATH))
    {
      return 174;
    }
  goto ret0;

 L1588: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1589;
    }
  goto ret0;

 L1589: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1590;
    }
  goto ret0;

 L1590: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1591;
  goto ret0;

 L1591: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_QIMODE_MATH))
    {
      return 175;
    }
  goto ret0;

 L331: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L332;
  goto ret0;

 L332: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[1]))
    goto L333;
  goto ret0;

 L333: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0]))
    {
      return 47;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_15 PARAMS ((rtx, rtx, int *));
static int
recog_15 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  switch (GET_CODE (x3))
    {
    case PLUS:
      goto L959;
    case NEG:
      goto L972;
    case MINUS:
      goto L1311;
    case AND:
      goto L1862;
    case IOR:
      goto L2080;
    case XOR:
      goto L2245;
    case NOT:
      goto L2701;
    case ASHIFT:
      goto L2813;
    case ASHIFTRT:
      goto L3005;
    case LSHIFTRT:
      goto L3197;
    case SUBREG:
    case REG:
    case MEM:
      goto L7355;
    default:
      goto ret0;
   }
 L7355: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L989;
    }
  goto ret0;

 L959: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L960;
    }
  goto ret0;

 L960: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L961;
    }
  goto ret0;

 L961: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L962;
  goto ret0;

 L962: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L963;
    case CLOBBER:
      goto L1008;
    default:
     break;
   }
  goto ret0;

 L963: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L964;
    }
  goto ret0;

 L964: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L965;
  goto ret0;

 L965: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L966;
  goto ret0;

 L966: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (PLUS, SImode, operands)
   /* Current assemblers are broken and do not allow @GOTOFF in
      ought but a memory context. */
   && ! pic_symbolic_operand (operands[2], VOIDmode)))
    {
      return 136;
    }
  goto ret0;

 L1008: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L1009;
    }
  goto ret0;

 L1009: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGOCmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)
   /* Current assemblers are broken and do not allow @GOTOFF in
      ought but a memory context. */
   && ! pic_symbolic_operand (operands[2], VOIDmode)))
    {
      return 139;
    }
  goto ret0;

 L972: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (general_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L973;
    }
  goto ret0;

 L973: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L974;
    }
  goto ret0;

 L974: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L975;
  goto ret0;

 L975: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L976;
    }
  goto ret0;

 L976: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCZmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)
   /* Current assemblers are broken and do not allow @GOTOFF in
      ought but a memory context. */
   && ! pic_symbolic_operand (operands[2], VOIDmode)))
    {
      return 137;
    }
  goto ret0;

 L1311: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L1312;
    }
  goto ret0;

 L1312: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L1313;
    }
  goto ret0;

 L1313: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1314;
  goto ret0;

 L1314: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1315;
  goto ret0;

 L1315: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L1316;
    }
  goto ret0;

 L1316: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MINUS)
    goto L1317;
  goto ret0;

 L1317: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1318;
  goto ret0;

 L1318: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (MINUS, SImode, operands)))
    {
      return 157;
    }
  goto ret0;

 L1862: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == SImode)
    goto L7387;
  goto ret0;

 L7387: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x4) == ZERO_EXTRACT)
    goto L1986;
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L1863;
    }
  goto ret0;

 L1986: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (ext_register_operand (x5, VOIDmode))
    {
      operands[1] = x5;
      goto L1987;
    }
  goto ret0;

 L1987: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 8)
    goto L1988;
  goto ret0;

 L1988: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 2);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 8)
    goto L1989;
  goto ret0;

 L1989: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L1990;
    }
  goto ret0;

 L1990: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1991;
  goto ret0;

 L1991: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1992;
  goto ret0;

 L1992: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTRACT)
    goto L1993;
  goto ret0;

 L1993: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L1994;
    }
  goto ret0;

 L1994: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L1995;
  goto ret0;

 L1995: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L1996;
  goto ret0;

 L1996: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == AND)
    goto L1997;
  goto ret0;

 L1997: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L1998;
  goto ret0;

 L1998: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[1]))
    goto L1999;
  goto ret0;

 L1999: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2000;
  goto ret0;

 L2000: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2001;
  goto ret0;

 L2001: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && (unsigned HOST_WIDE_INT)INTVAL (operands[2]) <= 0xff))
    {
      return 199;
    }
  goto ret0;

 L1863: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L1864;
    }
  goto ret0;

 L1864: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1865;
  goto ret0;

 L1865: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1866;
  goto ret0;

 L1866: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L1867;
    }
  goto ret0;

 L1867: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == AND)
    goto L1868;
  goto ret0;

 L1868: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1869;
  goto ret0;

 L1869: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (AND, SImode, operands)))
    {
      return 191;
    }
  goto ret0;

 L2080: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L2081;
    }
  goto ret0;

 L2081: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L2082;
    }
  goto ret0;

 L2082: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2083;
  goto ret0;

 L2083: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L2084;
    case CLOBBER:
      goto L2097;
    default:
     break;
   }
  goto ret0;

 L2084: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L2085;
    }
  goto ret0;

 L2085: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == IOR)
    goto L2086;
  goto ret0;

 L2086: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2087;
  goto ret0;

 L2087: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (IOR, SImode, operands)))
    {
      return 203;
    }
  goto ret0;

 L2097: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L2098;
    }
  goto ret0;

 L2098: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 204;
    }
  goto ret0;

 L2245: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == SImode)
    goto L7389;
  goto ret0;

 L7389: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x4) == ZERO_EXTRACT)
    goto L2398;
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L2246;
    }
  goto ret0;

 L2398: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (ext_register_operand (x5, VOIDmode))
    {
      operands[1] = x5;
      goto L2399;
    }
  goto ret0;

 L2399: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 8)
    goto L2400;
  goto ret0;

 L2400: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 2);
  if (GET_CODE (x5) == CONST_INT
      && XWINT (x5, 0) == 8)
    goto L2401;
  goto ret0;

 L2401: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2402;
    }
  goto ret0;

 L2402: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2403;
  goto ret0;

 L2403: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2404;
  goto ret0;

 L2404: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTRACT)
    goto L2405;
  goto ret0;

 L2405: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (ext_register_operand (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L2406;
    }
  goto ret0;

 L2406: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L2407;
  goto ret0;

 L2407: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 8)
    goto L2408;
  goto ret0;

 L2408: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == XOR)
    goto L2409;
  goto ret0;

 L2409: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ZERO_EXTRACT)
    goto L2410;
  goto ret0;

 L2410: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[1]))
    goto L2411;
  goto ret0;

 L2411: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2412;
  goto ret0;

 L2412: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L2413;
  goto ret0;

 L2413: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return 223;
    }
  goto ret0;

 L2246: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L2247;
    }
  goto ret0;

 L2247: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2248;
  goto ret0;

 L2248: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L2249;
    case CLOBBER:
      goto L2262;
    default:
     break;
   }
  goto ret0;

 L2249: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L2250;
    }
  goto ret0;

 L2250: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == XOR)
    goto L2251;
  goto ret0;

 L2251: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2252;
  goto ret0;

 L2252: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (XOR, SImode, operands)))
    {
      return 214;
    }
  goto ret0;

 L2262: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L2263;
    }
  goto ret0;

 L2263: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 215;
    }
  goto ret0;

 L2701: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L2702;
    }
  goto ret0;

 L2702: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2703;
  goto ret0;

 L2703: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2704;
  goto ret0;

 L2704: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L2705;
    }
  goto ret0;

 L2705: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == NOT)
    goto L2706;
  goto ret0;

 L2706: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_unary_operator_ok (NOT, SImode, operands)))
    {
      return 258;
    }
  goto ret0;

 L2813: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L2814;
    }
  goto ret0;

 L2814: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2815;
    }
  goto ret0;

 L2815: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2816;
  goto ret0;

 L2816: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2817;
  goto ret0;

 L2817: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L2818;
    }
  goto ret0;

 L2818: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ASHIFT)
    goto L2819;
  goto ret0;

 L2819: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2820;
  goto ret0;

 L2820: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (ASHIFT, SImode, operands)))
    {
      return 267;
    }
  goto ret0;

 L3005: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L3006;
    }
  goto ret0;

 L3006: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_1_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3007;
    }
 L3019: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3020;
    }
  goto ret0;

 L3007: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3008;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3019;

 L3008: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3009;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3019;

 L3009: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3010;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3019;

 L3010: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ASHIFTRT)
    goto L3011;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3019;

 L3011: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3012;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3019;

 L3012: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)
   && ix86_binary_operator_ok (ASHIFTRT, SImode, operands)))
    {
      return 280;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3019;

 L3020: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3021;
  goto ret0;

 L3021: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3022;
  goto ret0;

 L3022: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3023;
    }
  goto ret0;

 L3023: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ASHIFTRT)
    goto L3024;
  goto ret0;

 L3024: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3025;
  goto ret0;

 L3025: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (ASHIFTRT, SImode, operands)))
    {
      return 281;
    }
  goto ret0;

 L3197: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L3198;
    }
  goto ret0;

 L3198: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_1_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3199;
    }
 L3211: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3212;
    }
  goto ret0;

 L3199: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3200;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3211;

 L3200: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3201;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3211;

 L3201: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3202;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3211;

 L3202: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L3203;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3211;

 L3203: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3204;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3211;

 L3204: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)
   && ix86_binary_operator_ok (LSHIFTRT, HImode, operands)))
    {
      return 294;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3211;

 L3212: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3213;
  goto ret0;

 L3213: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3214;
  goto ret0;

 L3214: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3215;
    }
  goto ret0;

 L3215: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L3216;
  goto ret0;

 L3216: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3217;
  goto ret0;

 L3217: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (LSHIFTRT, HImode, operands)))
    {
      return 295;
    }
  goto ret0;

 L989: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L990;
    }
 L1324: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1325;
    }
  goto ret0;

 L990: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L991;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1324;

 L991: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L992;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1324;

 L992: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGCmode)
   && (INTVAL (operands[2]) & 0xffffffff) != 0x80000000))
    {
      return 138;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1324;

 L1325: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1326;
  goto ret0;

 L1326: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L1327;
    }
  goto ret0;

 L1327: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MINUS)
    goto L1328;
  goto ret0;

 L1328: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1329;
  goto ret0;

 L1329: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCmode)
   && ix86_binary_operator_ok (MINUS, SImode, operands)))
    {
      return 158;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_16 PARAMS ((rtx, rtx, int *));
static int
recog_16 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  switch (GET_CODE (x3))
    {
    case PLUS:
      goto L1050;
    case NEG:
      goto L1063;
    case MINUS:
      goto L1349;
    case AND:
      goto L1889;
    case IOR:
      goto L2125;
    case XOR:
      goto L2290;
    case NOT:
      goto L2717;
    case ASHIFT:
      goto L2854;
    case ASHIFTRT:
      goto L3059;
    case LSHIFTRT:
      goto L3251;
    case SUBREG:
    case REG:
    case MEM:
      goto L7358;
    default:
      goto ret0;
   }
 L7358: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1080;
    }
  goto ret0;

 L1050: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L1051;
    }
  goto ret0;

 L1051: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, HImode))
    {
      operands[2] = x4;
      goto L1052;
    }
  goto ret0;

 L1052: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1053;
  goto ret0;

 L1053: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L1054;
    case CLOBBER:
      goto L1099;
    default:
     break;
   }
  goto ret0;

 L1054: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1055;
    }
  goto ret0;

 L1055: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == PLUS)
    goto L1056;
  goto ret0;

 L1056: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1057;
  goto ret0;

 L1057: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (PLUS, HImode, operands)))
    {
      return 142;
    }
  goto ret0;

 L1099: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1100;
    }
  goto ret0;

 L1100: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGOCmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 145;
    }
  goto ret0;

 L1063: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (general_operand (x4, HImode))
    {
      operands[2] = x4;
      goto L1064;
    }
  goto ret0;

 L1064: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1065;
    }
  goto ret0;

 L1065: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1066;
  goto ret0;

 L1066: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1067;
    }
  goto ret0;

 L1067: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCZmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 143;
    }
  goto ret0;

 L1349: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L1350;
    }
  goto ret0;

 L1350: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, HImode))
    {
      operands[2] = x4;
      goto L1351;
    }
  goto ret0;

 L1351: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1352;
  goto ret0;

 L1352: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1353;
  goto ret0;

 L1353: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1354;
    }
  goto ret0;

 L1354: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == MINUS)
    goto L1355;
  goto ret0;

 L1355: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1356;
  goto ret0;

 L1356: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (MINUS, HImode, operands)))
    {
      return 160;
    }
  goto ret0;

 L1889: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L1890;
    }
  goto ret0;

 L1890: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, HImode))
    {
      operands[2] = x4;
      goto L1891;
    }
  goto ret0;

 L1891: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1892;
  goto ret0;

 L1892: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1893;
  goto ret0;

 L1893: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1894;
    }
  goto ret0;

 L1894: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == AND)
    goto L1895;
  goto ret0;

 L1895: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1896;
  goto ret0;

 L1896: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (AND, HImode, operands)))
    {
      return 193;
    }
  goto ret0;

 L2125: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L2126;
    }
  goto ret0;

 L2126: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, HImode))
    {
      operands[2] = x4;
      goto L2127;
    }
  goto ret0;

 L2127: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2128;
  goto ret0;

 L2128: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L2129;
    case CLOBBER:
      goto L2142;
    default:
     break;
   }
  goto ret0;

 L2129: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L2130;
    }
  goto ret0;

 L2130: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == IOR)
    goto L2131;
  goto ret0;

 L2131: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2132;
  goto ret0;

 L2132: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (IOR, HImode, operands)))
    {
      return 206;
    }
  goto ret0;

 L2142: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L2143;
    }
  goto ret0;

 L2143: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 207;
    }
  goto ret0;

 L2290: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L2291;
    }
  goto ret0;

 L2291: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, HImode))
    {
      operands[2] = x4;
      goto L2292;
    }
  goto ret0;

 L2292: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2293;
  goto ret0;

 L2293: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L2294;
    case CLOBBER:
      goto L2307;
    default:
     break;
   }
  goto ret0;

 L2294: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L2295;
    }
  goto ret0;

 L2295: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == XOR)
    goto L2296;
  goto ret0;

 L2296: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2297;
  goto ret0;

 L2297: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (XOR, HImode, operands)))
    {
      return 217;
    }
  goto ret0;

 L2307: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L2308;
    }
  goto ret0;

 L2308: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 218;
    }
  goto ret0;

 L2717: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L2718;
    }
  goto ret0;

 L2718: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2719;
  goto ret0;

 L2719: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2720;
  goto ret0;

 L2720: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L2721;
    }
  goto ret0;

 L2721: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == NOT)
    goto L2722;
  goto ret0;

 L2722: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_unary_operator_ok (NEG, HImode, operands)))
    {
      return 260;
    }
  goto ret0;

 L2854: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L2855;
    }
  goto ret0;

 L2855: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2856;
    }
  goto ret0;

 L2856: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2857;
  goto ret0;

 L2857: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2858;
  goto ret0;

 L2858: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L2859;
    }
  goto ret0;

 L2859: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFT)
    goto L2860;
  goto ret0;

 L2860: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2861;
  goto ret0;

 L2861: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (ASHIFT, HImode, operands)))
    {
      return 270;
    }
  goto ret0;

 L3059: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L3060;
    }
  goto ret0;

 L3060: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_1_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3061;
    }
 L3073: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3074;
    }
  goto ret0;

 L3061: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3062;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3073;

 L3062: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3063;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3073;

 L3063: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L3064;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3073;

 L3064: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFTRT)
    goto L3065;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3073;

 L3065: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3066;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3073;

 L3066: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)
   && ix86_binary_operator_ok (ASHIFTRT, HImode, operands)))
    {
      return 284;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3073;

 L3074: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3075;
  goto ret0;

 L3075: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3076;
  goto ret0;

 L3076: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L3077;
    }
  goto ret0;

 L3077: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ASHIFTRT)
    goto L3078;
  goto ret0;

 L3078: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3079;
  goto ret0;

 L3079: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (ASHIFTRT, HImode, operands)))
    {
      return 285;
    }
  goto ret0;

 L3251: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L3252;
    }
  goto ret0;

 L3252: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_1_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3253;
    }
 L3265: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3266;
    }
  goto ret0;

 L3253: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3254;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3265;

 L3254: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3255;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3265;

 L3255: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L3256;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3265;

 L3256: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L3257;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3265;

 L3257: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3258;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3265;

 L3258: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)
   && ix86_binary_operator_ok (LSHIFTRT, HImode, operands)))
    {
      return 298;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3265;

 L3266: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3267;
  goto ret0;

 L3267: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3268;
  goto ret0;

 L3268: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L3269;
    }
  goto ret0;

 L3269: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L3270;
  goto ret0;

 L3270: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3271;
  goto ret0;

 L3271: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (LSHIFTRT, HImode, operands)))
    {
      return 299;
    }
  goto ret0;

 L1080: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1081;
    }
 L1362: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1363;
    }
  goto ret0;

 L1081: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1082;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1362;

 L1082: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1083;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1362;

 L1083: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGCmode)
   && (INTVAL (operands[2]) & 0xffff) != 0x8000))
    {
      return 144;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1362;

 L1363: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1364;
  goto ret0;

 L1364: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1365;
    }
  goto ret0;

 L1365: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == MINUS)
    goto L1366;
  goto ret0;

 L1366: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1367;
  goto ret0;

 L1367: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCmode)
   && ix86_binary_operator_ok (MINUS, HImode, operands)))
    {
      return 161;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_17 PARAMS ((rtx, rtx, int *));
static int
recog_17 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  switch (GET_CODE (x3))
    {
    case PLUS:
      goto L1141;
    case NEG:
      goto L1154;
    case MINUS:
      goto L1387;
    case AND:
      goto L1932;
    case IOR:
      goto L2186;
    case XOR:
      goto L2366;
    case NOT:
      goto L2733;
    case ASHIFT:
      goto L2895;
    case ASHIFTRT:
      goto L3113;
    case LSHIFTRT:
      goto L3305;
    case SUBREG:
    case REG:
    case MEM:
      goto L7361;
    default:
      goto ret0;
   }
 L7361: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1171;
    }
  goto ret0;

 L1141: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L1142;
    }
  goto ret0;

 L1142: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L1143;
    }
  goto ret0;

 L1143: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1144;
  goto ret0;

 L1144: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L1145;
    case CLOBBER:
      goto L1190;
    default:
     break;
   }
  goto ret0;

 L1145: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L1146;
    }
  goto ret0;

 L1146: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == PLUS)
    goto L1147;
  goto ret0;

 L1147: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1148;
  goto ret0;

 L1148: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (PLUS, QImode, operands)))
    {
      return 148;
    }
  goto ret0;

 L1190: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L1191;
    }
  goto ret0;

 L1191: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGOCmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 151;
    }
  goto ret0;

 L1154: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (general_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L1155;
    }
  goto ret0;

 L1155: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1156;
    }
  goto ret0;

 L1156: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1157;
  goto ret0;

 L1157: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L1158;
    }
  goto ret0;

 L1158: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCZmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 149;
    }
  goto ret0;

 L1387: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L1388;
    }
  goto ret0;

 L1388: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L1389;
    }
  goto ret0;

 L1389: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1390;
  goto ret0;

 L1390: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1391;
  goto ret0;

 L1391: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1392;
    }
  goto ret0;

 L1392: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == MINUS)
    goto L1393;
  goto ret0;

 L1393: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1394;
  goto ret0;

 L1394: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (MINUS, QImode, operands)))
    {
      return 163;
    }
  goto ret0;

 L1932: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == QImode)
    goto L7390;
  goto ret0;

 L7390: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L1933;
    }
 L7391: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x4, QImode))
    {
      operands[0] = x4;
      goto L1946;
    }
  goto ret0;

 L1933: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L1934;
    }
  x4 = XEXP (x3, 0);
  goto L7391;

 L1934: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1935;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7391;

 L1935: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1936;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7391;

 L1936: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L1937;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7391;

 L1937: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == AND)
    goto L1938;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7391;

 L1938: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1939;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7391;

 L1939: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (AND, QImode, operands)))
    {
      return 196;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7391;

 L1946: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L1947;
    }
  goto ret0;

 L1947: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L1948;
  goto ret0;

 L1948: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1949;
  goto ret0;

 L1949: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == STRICT_LOW_PART)
    goto L1950;
  goto ret0;

 L1950: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L1951;
  goto ret0;

 L1951: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == AND)
    goto L1952;
  goto ret0;

 L1952: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L1953;
  goto ret0;

 L1953: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return 197;
    }
  goto ret0;

 L2186: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == QImode)
    goto L7392;
  goto ret0;

 L7392: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L2187;
    }
 L7393: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x4, QImode))
    {
      operands[0] = x4;
      goto L2200;
    }
  goto ret0;

 L2187: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2188;
    }
  x4 = XEXP (x3, 0);
  goto L7393;

 L2188: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2189;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7393;

 L2189: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L2190;
    case CLOBBER:
      goto L2217;
    default:
     break;
   }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7393;

 L2190: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L2191;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7393;

 L2191: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == IOR)
    goto L2192;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7393;

 L2192: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2193;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7393;

 L2193: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (IOR, QImode, operands)))
    {
      return 210;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7393;

 L2217: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L2218;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7393;

 L2218: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 212;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7393;

 L2200: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L2201;
    }
  goto ret0;

 L2201: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2202;
  goto ret0;

 L2202: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2203;
  goto ret0;

 L2203: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == STRICT_LOW_PART)
    goto L2204;
  goto ret0;

 L2204: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L2205;
  goto ret0;

 L2205: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == IOR)
    goto L2206;
  goto ret0;

 L2206: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L2207;
  goto ret0;

 L2207: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return 211;
    }
  goto ret0;

 L2366: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L2367;
    }
  goto ret0;

 L2367: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (general_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2368;
    }
  goto ret0;

 L2368: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2369;
  goto ret0;

 L2369: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L2370;
    case CLOBBER:
      goto L2383;
    default:
     break;
   }
  goto ret0;

 L2370: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L2371;
    }
  goto ret0;

 L2371: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == XOR)
    goto L2372;
  goto ret0;

 L2372: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2373;
  goto ret0;

 L2373: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_binary_operator_ok (XOR, QImode, operands)))
    {
      return 221;
    }
  goto ret0;

 L2383: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L2384;
    }
  goto ret0;

 L2384: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCNOmode)
   && (GET_CODE (operands[1]) != MEM || GET_CODE (operands[2]) != MEM)))
    {
      return 222;
    }
  goto ret0;

 L2733: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L2734;
    }
  goto ret0;

 L2734: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2735;
  goto ret0;

 L2735: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2736;
  goto ret0;

 L2736: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L2737;
    }
  goto ret0;

 L2737: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == NOT)
    goto L2738;
  goto ret0;

 L2738: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_match_ccmode (insn, CCNOmode)
   && ix86_unary_operator_ok (NOT, QImode, operands)))
    {
      return 262;
    }
  goto ret0;

 L2895: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L2896;
    }
  goto ret0;

 L2896: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L2897;
    }
  goto ret0;

 L2897: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2898;
  goto ret0;

 L2898: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2899;
  goto ret0;

 L2899: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L2900;
    }
  goto ret0;

 L2900: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == ASHIFT)
    goto L2901;
  goto ret0;

 L2901: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L2902;
  goto ret0;

 L2902: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (ASHIFT, QImode, operands)))
    {
      return 273;
    }
  goto ret0;

 L3113: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L3114;
    }
  goto ret0;

 L3114: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_1_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3115;
    }
 L3127: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3128;
    }
  goto ret0;

 L3115: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3116;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3127;

 L3116: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3117;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3127;

 L3117: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L3118;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3127;

 L3118: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == ASHIFTRT)
    goto L3119;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3127;

 L3119: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3120;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3127;

 L3120: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)
   && ix86_binary_operator_ok (ASHIFTRT, QImode, operands)))
    {
      return 288;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3127;

 L3128: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3129;
  goto ret0;

 L3129: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3130;
  goto ret0;

 L3130: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L3131;
    }
  goto ret0;

 L3131: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == ASHIFTRT)
    goto L3132;
  goto ret0;

 L3132: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3133;
  goto ret0;

 L3133: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (ASHIFTRT, QImode, operands)))
    {
      return 289;
    }
  goto ret0;

 L3305: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L3306;
    }
  goto ret0;

 L3306: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_1_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3307;
    }
 L3319: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x4, QImode))
    {
      operands[2] = x4;
      goto L3320;
    }
  goto ret0;

 L3307: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3308;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3319;

 L3308: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3309;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3319;

 L3309: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L3310;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3319;

 L3310: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L3311;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3319;

 L3311: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3312;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3319;

 L3312: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && (TARGET_PENTIUM || TARGET_PENTIUMPRO)
   && ix86_binary_operator_ok (LSHIFTRT, QImode, operands)))
    {
      return 302;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3319;

 L3320: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3321;
  goto ret0;

 L3321: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3322;
  goto ret0;

 L3322: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L3323;
    }
  goto ret0;

 L3323: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == LSHIFTRT)
    goto L3324;
  goto ret0;

 L3324: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3325;
  goto ret0;

 L3325: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCGOCmode)
   && ix86_binary_operator_ok (LSHIFTRT, QImode, operands)))
    {
      return 303;
    }
  goto ret0;

 L1171: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1172;
    }
 L1400: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L1401;
    }
  goto ret0;

 L1172: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1173;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1400;

 L1173: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L1174;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1400;

 L1174: ATTRIBUTE_UNUSED_LABEL
  if ((ix86_match_ccmode (insn, CCGCmode)
   && (INTVAL (operands[2]) & 0xff) != 0x80))
    {
      return 150;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 1);
  goto L1400;

 L1401: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1402;
  goto ret0;

 L1402: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1403;
    }
  goto ret0;

 L1403: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == MINUS)
    goto L1404;
  goto ret0;

 L1404: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1405;
  goto ret0;

 L1405: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_match_ccmode (insn, CCmode)
   && ix86_binary_operator_ok (MINUS, QImode, operands)))
    {
      return 164;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_18 PARAMS ((rtx, rtx, int *));
static int
recog_18 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L7190;
    case HImode:
      goto L7193;
    case QImode:
      goto L7195;
    case SFmode:
      goto L7197;
    case DFmode:
      goto L7198;
    case XFmode:
      goto L7199;
    case TFmode:
      goto L7200;
    case DImode:
      goto L7201;
    case CCmode:
      goto L7204;
    case CCZmode:
      goto L7207;
    default:
      break;
    }
 L300: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case STRICT_LOW_PART:
      goto L301;
    case REG:
      goto L7210;
    case PC:
      goto L3686;
    default:
     break;
   }
 L4469: ATTRIBUTE_UNUSED_LABEL
  operands[0] = x2;
  goto L4470;

 L7190: ATTRIBUTE_UNUSED_LABEL
  tem = recog_12 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L300;

 L7193: ATTRIBUTE_UNUSED_LABEL
  tem = recog_13 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L300;

 L7195: ATTRIBUTE_UNUSED_LABEL
  tem = recog_14 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L300;

 L7197: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SFmode))
    {
      operands[0] = x2;
      goto L415;
    }
 L7202: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SFmode))
    {
      operands[0] = x2;
      goto L654;
    }
  goto L300;

 L415: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L416;
    }
  x2 = XEXP (x1, 0);
  goto L7202;

 L416: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L417;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7202;

 L417: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[1]))
    goto L418;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7202;

 L418: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0]))
    {
      return 61;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7202;

 L654: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SFmode)
    goto L7317;
  x2 = XEXP (x1, 0);
  goto L300;

 L7317: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT_TRUNCATE:
      goto L655;
    case NEG:
      goto L2499;
    case ABS:
      goto L2597;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L300;

 L655: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L7320;
    case XFmode:
      goto L7321;
    case TFmode:
      goto L7322;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L7320: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L656;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L656: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L657;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L657: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L658;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L658: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 100;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7321: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L669;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L669: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L670;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L670: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L671;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L671: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 102;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7322: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L682;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L682: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L683;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L683: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L684;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L684: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 104;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2499: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L2500;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2500: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2501;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2501: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && ix86_unary_operator_ok (NEG, SFmode, operands)))
    {
      return 231;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2597: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L2598;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2598: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2599;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2599: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && ix86_unary_operator_ok (ABS, SFmode, operands)))
    {
      return 244;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7198: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DFmode))
    {
      operands[0] = x2;
      goto L438;
    }
 L7203: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DFmode))
    {
      operands[0] = x2;
      goto L693;
    }
  goto L300;

 L438: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L439;
    }
  x2 = XEXP (x1, 0);
  goto L7203;

 L439: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L440;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7203;

 L440: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[1]))
    goto L441;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7203;

 L441: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0]))
    {
      return 66;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7203;

 L693: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DFmode)
    goto L7323;
  x2 = XEXP (x1, 0);
  goto L300;

 L7323: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT_TRUNCATE:
      goto L694;
    case NEG:
      goto L2511;
    case ABS:
      goto L2609;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L300;

 L694: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case XFmode:
      goto L7326;
    case TFmode:
      goto L7327;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L7326: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L695;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L695: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L696;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L696: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L697;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L697: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 106;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7327: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L708;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L708: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L709;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L709: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L710;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L710: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return 108;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2511: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L2512;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2512: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2513;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2513: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && ix86_unary_operator_ok (NEG, DFmode, operands)))
    {
      return 232;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2609: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L2610;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2610: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2611;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2611: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && ix86_unary_operator_ok (ABS, DFmode, operands)))
    {
      return 245;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7199: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, XFmode))
    {
      operands[0] = x2;
      goto L477;
    }
 L7208: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, XFmode))
    {
      operands[0] = x2;
      goto L2522;
    }
  goto L300;

 L477: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, XFmode))
    {
      operands[1] = x2;
      goto L478;
    }
  x2 = XEXP (x1, 0);
  goto L7208;

 L478: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L479;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7208;

 L479: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[1]))
    goto L480;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7208;

 L480: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0]))
    {
      return 75;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7208;

 L2522: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == XFmode)
    goto L7328;
  x2 = XEXP (x1, 0);
  goto L300;

 L7328: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case NEG:
      goto L2523;
    case ABS:
      goto L2621;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L300;

 L2523: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L2524;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2524: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2525;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2525: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && ix86_unary_operator_ok (NEG, XFmode, operands)))
    {
      return 233;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2621: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L2622;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2622: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2623;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2623: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && ix86_unary_operator_ok (ABS, XFmode, operands)))
    {
      return 246;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7200: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, TFmode))
    {
      operands[0] = x2;
      goto L484;
    }
 L7209: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, TFmode))
    {
      operands[0] = x2;
      goto L2534;
    }
  goto L300;

 L484: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, TFmode))
    {
      operands[1] = x2;
      goto L485;
    }
  x2 = XEXP (x1, 0);
  goto L7209;

 L485: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L486;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7209;

 L486: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[1]))
    goto L487;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7209;

 L487: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (rtx_equal_p (x2, operands[0]))
    {
      return 76;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7209;

 L2534: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == TFmode)
    goto L7330;
  x2 = XEXP (x1, 0);
  goto L300;

 L7330: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case NEG:
      goto L2535;
    case ABS:
      goto L2633;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L300;

 L2535: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L2536;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2536: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2537;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2537: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && ix86_unary_operator_ok (NEG, TFmode, operands)))
    {
      return 234;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2633: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L2634;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2634: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2635;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2635: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && ix86_unary_operator_ok (ABS, TFmode, operands)))
    {
      return 247;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7201: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L566;
    }
 L7206: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L1487;
    }
  goto L300;

 L566: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode)
    goto L7332;
  x2 = XEXP (x1, 0);
  goto L7206;

 L7332: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L567;
    case PLUS:
      goto L857;
    case MINUS:
      goto L1260;
    case NEG:
      goto L2418;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L7206;

 L567: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (general_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L568;
    }
  x2 = XEXP (x1, 0);
  goto L7206;

 L568: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L569;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7206;

 L569: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 85;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7206;

 L857: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L858;
    }
  x2 = XEXP (x1, 0);
  goto L7206;

 L858: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L859;
    }
  x2 = XEXP (x1, 0);
  goto L7206;

 L859: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L860;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7206;

 L860: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 127;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7206;

 L1260: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L1261;
    }
  x2 = XEXP (x1, 0);
  goto L7206;

 L1261: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L1262;
    }
  x2 = XEXP (x1, 0);
  goto L7206;

 L1262: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1263;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7206;

 L1263: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 154;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7206;

 L2418: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (general_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L2419;
    }
  x2 = XEXP (x1, 0);
  goto L7206;

 L2419: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2420;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7206;

 L2420: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (ix86_unary_operator_ok (NEG, DImode, operands)))
    {
      return 224;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7206;

 L1487: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode)
    goto L7336;
  x2 = XEXP (x1, 0);
  goto L300;

 L7336: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MULT:
      goto L1488;
    case ASHIFT:
      goto L2759;
    case ASHIFTRT:
      goto L2923;
    case LSHIFTRT:
      goto L3154;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L300;

 L1488: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == DImode)
    goto L7340;
  x2 = XEXP (x1, 0);
  goto L300;

 L7340: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x3))
    {
    case ZERO_EXTEND:
      goto L1489;
    case SIGN_EXTEND:
      goto L1507;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L300;

 L1489: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L1490;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L1490: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == DImode
      && GET_CODE (x3) == ZERO_EXTEND)
    goto L1491;
  x2 = XEXP (x1, 0);
  goto L300;

 L1491: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L1492;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L1492: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1493;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L1493: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 170;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L1507: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L1508;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L1508: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == DImode
      && GET_CODE (x3) == SIGN_EXTEND)
    goto L1509;
  x2 = XEXP (x1, 0);
  goto L300;

 L1509: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[2] = x4;
      goto L1510;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L1510: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1511;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L1511: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 171;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2759: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L2760;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2760: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2761;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2761: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2762;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2762: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 264;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2923: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L2924;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2924: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2925;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2925: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2926;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2926: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 275;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L3154: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L3155;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L3155: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3156;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L3156: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3157;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L3157: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 291;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7204: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L892;
  goto L300;

 L892: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == UNSPEC
      && XVECLEN (x2, 0) == 2
      && XINT (x2, 1) == 12)
    goto L893;
  x2 = XEXP (x1, 0);
  goto L300;

 L893: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  switch (GET_MODE (x3))
    {
    case SImode:
      goto L7342;
    case QImode:
      goto L7343;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L7342: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L894;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L894: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 1);
  if (general_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L895;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L895: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L896;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L896: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L897;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L897: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L898;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L898: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L899;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L899: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_binary_operator_ok (PLUS, SImode, operands)))
    {
      return 129;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7343: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L905;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L905: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L906;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L906: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L907;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L907: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L908;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L908: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == PLUS)
    goto L909;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L909: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L910;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L910: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (ix86_binary_operator_ok (PLUS, QImode, operands)))
    {
      return 130;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7207: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L2441;
  goto L300;

 L2441: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == CCZmode
      && GET_CODE (x2) == COMPARE)
    goto L2442;
  x2 = XEXP (x1, 0);
  goto L300;

 L2442: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case SImode:
      goto L7344;
    case HImode:
      goto L7345;
    case QImode:
      goto L7346;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L7344: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == NEG)
    goto L2443;
  if (nonimmediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L3823;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2443: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L2444;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2444: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2445;
  x2 = XEXP (x1, 0);
  goto L300;

 L2445: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2446;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2446: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L2447;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2447: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == NEG)
    goto L2448;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2448: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_unary_operator_ok (NEG, SImode, operands)))
    {
      return 226;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L3823: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L3824;
  x2 = XEXP (x1, 0);
  goto L300;

 L3824: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3825;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L3825: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3826;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L3826: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == UNSPEC
      && XVECLEN (x2, 0) == 1
      && XINT (x2, 1) == 5)
    goto L3827;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L3827: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (rtx_equal_p (x3, operands[1]))
    {
      return 344;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7345: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == NEG)
    goto L2466;
  x2 = XEXP (x1, 0);
  goto L300;

 L2466: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L2467;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2467: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2468;
  x2 = XEXP (x1, 0);
  goto L300;

 L2468: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2469;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2469: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L2470;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2470: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == NEG)
    goto L2471;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2471: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_unary_operator_ok (NEG, HImode, operands)))
    {
      return 228;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L7346: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == NEG)
    goto L2489;
  x2 = XEXP (x1, 0);
  goto L300;

 L2489: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L2490;
    }
  x2 = XEXP (x1, 0);
  goto L300;

 L2490: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L2491;
  x2 = XEXP (x1, 0);
  goto L300;

 L2491: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L2492;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2492: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L2493;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2493: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == NEG)
    goto L2494;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L2494: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_unary_operator_ok (NEG, QImode, operands)))
    {
      return 230;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L300;

 L301: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case HImode:
      goto L7348;
    case QImode:
      goto L7349;
    default:
      break;
    }
  goto L4469;

 L7348: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, HImode))
    {
      operands[0] = x3;
      goto L302;
    }
  goto L4469;

 L302: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const0_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L303;
    }
  x2 = XEXP (x1, 0);
  goto L4469;

 L303: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L304;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L304: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed && (!TARGET_USE_MOV0 || optimize_size)))
    {
      return 43;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L7349: ATTRIBUTE_UNUSED_LABEL
  if (q_regs_operand (x3, QImode))
    {
      operands[0] = x3;
      goto L343;
    }
 L7350: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, QImode))
    {
      operands[0] = x3;
      goto L1915;
    }
  goto L4469;

 L343: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (const0_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L344;
    }
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L7350;

 L344: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L345;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L7350;

 L345: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed && (!TARGET_USE_MOV0 || optimize_size)))
    {
      return 49;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L7350;

 L1915: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode)
    goto L7351;
  x2 = XEXP (x1, 0);
  goto L4469;

 L7351: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case AND:
      goto L1916;
    case IOR:
      goto L2170;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L4469;

 L1916: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L1917;
  x2 = XEXP (x1, 0);
  goto L4469;

 L1917: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L1918;
    }
  x2 = XEXP (x1, 0);
  goto L4469;

 L1918: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1919;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L1919: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 195;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L2170: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L2171;
  x2 = XEXP (x1, 0);
  goto L4469;

 L2171: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L2172;
    }
  x2 = XEXP (x1, 0);
  goto L4469;

 L2172: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2173;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L2173: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 209;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L7210: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L957;
  goto L4469;

 L957: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == COMPARE)
    goto L958;
  x2 = XEXP (x1, 0);
  goto L4469;

 L958: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case SImode:
      goto L7353;
    case HImode:
      goto L7356;
    case QImode:
      goto L7359;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L4469;

 L7353: ATTRIBUTE_UNUSED_LABEL
  tem = recog_15 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  x2 = XEXP (x1, 0);
  goto L4469;

 L7356: ATTRIBUTE_UNUSED_LABEL
  tem = recog_16 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  x2 = XEXP (x1, 0);
  goto L4469;

 L7359: ATTRIBUTE_UNUSED_LABEL
  tem = recog_17 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  x2 = XEXP (x1, 0);
  goto L4469;

 L3686: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3687;
    }
  if (GET_CODE (x2) == IF_THEN_ELSE)
    goto L3721;
  x2 = XEXP (x1, 0);
  goto L4469;

 L3687: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == USE)
    goto L3688;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L3688: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == LABEL_REF)
    goto L3689;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L3689: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  operands[1] = x3;
  goto L3690;
 L3697: ATTRIBUTE_UNUSED_LABEL
  operands[1] = x3;
  return 329;

 L3690: ATTRIBUTE_UNUSED_LABEL
  if ((! flag_pic))
    {
      return 328;
    }
  x1 = XVECEXP (x0, 0, 1);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L3697;

 L3721: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == NE)
    goto L3722;
  x2 = XEXP (x1, 0);
  goto L4469;

 L3722: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L3723;
    }
  x2 = XEXP (x1, 0);
  goto L4469;

 L3723: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L3724;
  x2 = XEXP (x1, 0);
  goto L4469;

 L3724: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L3725;
  x2 = XEXP (x1, 0);
  goto L4469;

 L3725: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[0] = x4;
  goto L3726;

 L3726: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC)
    goto L3727;
  x2 = XEXP (x1, 0);
  goto L4469;

 L3727: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3728;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L3728: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L3729;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L3729: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L3730;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L3730: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3731;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L3731: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == -1
      && (TARGET_USE_LOOP)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 330;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L4469;

 L4470: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CALL)
    goto L4471;
  goto ret0;

 L4471: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == QImode
      && GET_CODE (x3) == MEM)
    goto L4472;
  goto ret0;

 L4472: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == SImode)
    goto L7394;
  goto ret0;

 L7394: ATTRIBUTE_UNUSED_LABEL
  if (constant_call_address_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L4473;
    }
 L7395: ATTRIBUTE_UNUSED_LABEL
  if (call_insn_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L4485;
    }
  goto ret0;

 L4473: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  operands[2] = x3;
  goto L4474;

 L4474: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4475;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7395;

 L4475: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L4476;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7395;

 L4476: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4477;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7395;

 L4477: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L4478;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7395;

 L4478: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (immediate_operand (x3, SImode))
    {
      operands[3] = x3;
      return 413;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 0);
  goto L7395;

 L4485: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  operands[2] = x3;
  goto L4486;

 L4486: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4487;
  goto ret0;

 L4487: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L4488;
  goto ret0;

 L4488: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4489;
  goto ret0;

 L4489: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L4490;
  goto ret0;

 L4490: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (immediate_operand (x3, SImode))
    {
      operands[3] = x3;
      return 414;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_19 PARAMS ((rtx, rtx, int *));
static int
recog_19 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  switch (GET_CODE (x2))
    {
    case REG:
      goto L7408;
    case MEM:
      goto L4214;
    default:
     break;
   }
 L7398: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L211;
    }
 L7401: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L1523;
    }
  goto ret0;

 L7408: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 7)
    goto L3809;
  goto L7398;

 L3809: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 6)
    goto L3810;
  x2 = XEXP (x1, 0);
  goto L7398;

 L3810: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3811;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L3811: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 6)
    goto L3812;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L3812: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MEM)
    goto L3813;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L3813: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == PRE_DEC)
    goto L3814;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L3814: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == SImode
      && GET_CODE (x4) == REG
      && XINT (x4, 0) == 7)
    goto L3815;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L3815: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3816;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L3816: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L3817;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L3817: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == SCRATCH)
    {
      return 343;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L4214: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L4215;
    }
  goto L7398;

 L4215: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L4216;
    }
  x2 = XEXP (x1, 0);
  goto L7398;

 L4216: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4217;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L4217: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4218;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L4218: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4219;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L4219: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L4220;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L4220: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 4)
    goto L4221;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L4221: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L4222;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L4222: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19
      && (TARGET_SINGLE_STRINGOP || optimize_size))
    {
      return 396;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7398;

 L211: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L7409;
  x2 = XEXP (x1, 0);
  goto L7401;

 L7409: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case MEM:
      goto L212;
    case FIX:
      goto L756;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L7401;

 L212: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L213;
  x2 = XEXP (x1, 0);
  goto L7401;

 L213: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L214;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L214: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L215;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L215: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L216;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L216: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L217;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L217: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 4)
    goto L218;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L218: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L219;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L219: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L220;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L220: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == SCRATCH)
    {
      return 31;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L756: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L757;
    }
  x2 = XEXP (x1, 0);
  goto L7401;

 L757: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L758;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L758: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L759;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L759: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L760;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L760: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L761;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L761: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FLOAT_MODE_P (GET_MODE (operands[1])))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 111;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7401;

 L1523: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L7411;
  goto ret0;

 L7411: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case TRUNCATE:
      goto L1524;
    case DIV:
      goto L1602;
    case UDIV:
      goto L1703;
    case UNSPEC:
      goto L7416;
    case PLUS:
      goto L4438;
    default:
     break;
   }
  goto ret0;

 L1524: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == DImode
      && GET_CODE (x3) == LSHIFTRT)
    goto L1525;
  goto ret0;

 L1525: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == DImode
      && GET_CODE (x4) == MULT)
    goto L1526;
  goto ret0;

 L1526: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (GET_MODE (x5) == DImode)
    goto L7417;
  goto ret0;

 L7417: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x5))
    {
    case ZERO_EXTEND:
      goto L1527;
    case SIGN_EXTEND:
      goto L1552;
    default:
     break;
   }
  goto ret0;

 L1527: ATTRIBUTE_UNUSED_LABEL
  x6 = XEXP (x5, 0);
  if (register_operand (x6, SImode))
    {
      operands[1] = x6;
      goto L1528;
    }
  goto ret0;

 L1528: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_MODE (x5) == DImode
      && GET_CODE (x5) == ZERO_EXTEND)
    goto L1529;
  goto ret0;

 L1529: ATTRIBUTE_UNUSED_LABEL
  x6 = XEXP (x5, 0);
  if (nonimmediate_operand (x6, SImode))
    {
      operands[2] = x6;
      goto L1530;
    }
  goto ret0;

 L1530: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 32)
    goto L1531;
  goto ret0;

 L1531: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1532;
  goto ret0;

 L1532: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L1533;
    }
  goto ret0;

 L1533: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L1534;
  goto ret0;

 L1534: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 172;
    }
  goto ret0;

 L1552: ATTRIBUTE_UNUSED_LABEL
  x6 = XEXP (x5, 0);
  if (register_operand (x6, SImode))
    {
      operands[1] = x6;
      goto L1553;
    }
  goto ret0;

 L1553: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 1);
  if (GET_MODE (x5) == DImode
      && GET_CODE (x5) == SIGN_EXTEND)
    goto L1554;
  goto ret0;

 L1554: ATTRIBUTE_UNUSED_LABEL
  x6 = XEXP (x5, 0);
  if (nonimmediate_operand (x6, SImode))
    {
      operands[2] = x6;
      goto L1555;
    }
  goto ret0;

 L1555: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 32)
    goto L1556;
  goto ret0;

 L1556: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L1557;
  goto ret0;

 L1557: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L1558;
    }
  goto ret0;

 L1558: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L1559;
  goto ret0;

 L1559: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 173;
    }
  goto ret0;

 L1602: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7419;
  goto ret0;

 L7419: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1603;
    }
 L7420: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1666;
    }
  goto ret0;

 L1603: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L1604;
    }
  x3 = XEXP (x2, 0);
  goto L7420;

 L1604: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1605;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L1605: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L1606;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L1606: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MOD)
    goto L1607;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L1607: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[2]))
    goto L1608;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L1608: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[3]))
    goto L1609;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L1609: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L1610;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L1610: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7421;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L7421: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7423;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L7423: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7425;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L7425: ATTRIBUTE_UNUSED_LABEL
  if ((!optimize_size && !TARGET_USE_CLTD))
    {
      return 176;
    }
 L7426: ATTRIBUTE_UNUSED_LABEL
  if ((optimize_size || TARGET_USE_CLTD))
    {
      return 177;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7420;

 L1666: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1667;
    }
  goto ret0;

 L1667: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1668;
  goto ret0;

 L1668: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L1669;
    }
  goto ret0;

 L1669: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MOD)
    goto L1670;
  goto ret0;

 L1670: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1671;
  goto ret0;

 L1671: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L1672;
  goto ret0;

 L1672: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L1673;
  goto ret0;

 L1673: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[4] = x2;
      goto L1674;
    }
  goto ret0;

 L1674: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 178;
    }
  goto ret0;

 L1703: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1704;
    }
  goto ret0;

 L1704: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1705;
    }
  goto ret0;

 L1705: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1706;
  goto ret0;

 L1706: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L1707;
    }
  goto ret0;

 L1707: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == UMOD)
    goto L1708;
  goto ret0;

 L1708: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1709;
  goto ret0;

 L1709: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L1710;
  goto ret0;

 L1710: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  switch (GET_CODE (x1))
    {
    case CLOBBER:
      goto L1711;
    case USE:
      goto L1750;
    default:
     break;
   }
  goto ret0;

 L1711: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 180;
    }
  goto ret0;

 L1750: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[3])
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 181;
    }
  goto ret0;

 L7416: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x2, 0) == 4
      && XINT (x2, 1) == 0)
    goto L4351;
  goto ret0;

 L4351: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (GET_MODE (x3) == BLKmode
      && GET_CODE (x3) == MEM)
    goto L4352;
  goto ret0;

 L4352: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[5] = x4;
      goto L4353;
    }
  goto ret0;

 L4353: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L4354;
    }
  goto ret0;

 L4354: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 2);
  if (immediate_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4355;
    }
  goto ret0;

 L4355: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 3);
  if (immediate_operand (x3, SImode))
    {
      operands[4] = x3;
      goto L4356;
    }
  goto ret0;

 L4356: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == USE)
    goto L4357;
  goto ret0;

 L4357: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    goto L4358;
  goto ret0;

 L4358: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L4359;
  goto ret0;

 L4359: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4360;
    }
  goto ret0;

 L4360: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 403;
    }
  goto ret0;

 L4438: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L4439;
    }
  goto ret0;

 L4439: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (immediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L4440;
    }
  goto ret0;

 L4440: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L4441;
  goto ret0;

 L4441: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L4442;
  goto ret0;

 L4442: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L4443;
  goto ret0;

 L4443: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L4444;
  goto ret0;

 L4444: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == SCRATCH)
    {
      return 411;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_20 PARAMS ((rtx, rtx, int *));
static int
recog_20 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L7404;
    case DImode:
      goto L7399;
    case HImode:
      goto L7406;
    case QImode:
      goto L7407;
    default:
      break;
    }
 L3525: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == PC)
    goto L3526;
  goto ret0;

 L7404: ATTRIBUTE_UNUSED_LABEL
  tem = recog_19 (x0, insn, pnum_clobbers);
  if (tem >= 0)
    return tem;
  goto L3525;

 L7399: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L578;
    }
 L7403: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L2742;
    }
  goto L3525;

 L578: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode)
    goto L7427;
  x2 = XEXP (x1, 0);
  goto L7403;

 L7427: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case SIGN_EXTEND:
      goto L579;
    case FIX:
      goto L734;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L7403;

 L579: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L580;
    }
  x2 = XEXP (x1, 0);
  goto L7403;

 L580: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L581;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L581: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L582;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L582: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L583;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L583: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[2] = x2;
      return 86;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L734: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L735;
    }
  x2 = XEXP (x1, 0);
  goto L7403;

 L735: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L736;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L736: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L737;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L737: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L738;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L738: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DImode))
    {
      operands[3] = x2;
      goto L739;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L739: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FLOAT_MODE_P (GET_MODE (operands[1])))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 2;
      return 110;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7403;

 L2742: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode)
    goto L7429;
  x2 = XEXP (x1, 0);
  goto L3525;

 L7429: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ASHIFT:
      goto L2743;
    case ASHIFTRT:
      goto L2907;
    case LSHIFTRT:
      goto L3138;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L3525;

 L2743: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L2744;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L2744: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2745;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L2745: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2746;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L2746: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L2747;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L2747: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L2748;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L2748: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_CMOVE))
    {
      return 263;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L2907: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L2908;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L2908: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L2909;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L2909: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L2910;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L2910: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L2911;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L2911: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L2912;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L2912: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_CMOVE))
    {
      return 274;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L3138: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L3139;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L3139: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L3140;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L3140: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3141;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L3141: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L3142;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L3142: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3143;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L3143: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_CMOVE))
    {
      return 290;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L7406: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == MEM)
    goto L4226;
 L7400: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L777;
    }
 L7402: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1678;
    }
  goto L3525;

 L4226: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L4227;
    }
  goto L7400;

 L4227: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, HImode))
    {
      operands[2] = x2;
      goto L4228;
    }
  x2 = XEXP (x1, 0);
  goto L7400;

 L4228: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4229;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7400;

 L4229: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4230;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7400;

 L4230: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4231;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7400;

 L4231: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L4232;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7400;

 L4232: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 2)
    goto L4233;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7400;

 L4233: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L4234;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7400;

 L4234: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19
      && (TARGET_SINGLE_STRINGOP || optimize_size))
    {
      return 397;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7400;

 L777: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == FIX)
    goto L778;
  x2 = XEXP (x1, 0);
  goto L7402;

 L778: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L779;
    }
  x2 = XEXP (x1, 0);
  goto L7402;

 L779: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L780;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7402;

 L780: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L781;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7402;

 L781: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L782;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7402;

 L782: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L783;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7402;

 L783: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FLOAT_MODE_P (GET_MODE (operands[1])))
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 112;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7402;

 L1678: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode)
    goto L7432;
  x2 = XEXP (x1, 0);
  goto L3525;

 L7432: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case DIV:
      goto L1679;
    case UDIV:
      goto L1770;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L3525;

 L1679: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1680;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L1680: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1681;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L1681: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1682;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1682: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L1683;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1683: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == MOD)
    goto L1684;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1684: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1685;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1685: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L1686;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1686: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L1687;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1687: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_HIMODE_MATH))
    {
      return 179;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1770: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1771;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L1771: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1772;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L1772: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1773;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1773: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L1774;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1774: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == UMOD)
    goto L1775;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1775: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1776;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1776: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L1777;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1777: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L1778;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1778: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[4] = x2;
      goto L1779;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L1779: ATTRIBUTE_UNUSED_LABEL
  if (pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 182;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L7407: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == MEM)
    goto L4238;
  goto L3525;

 L4238: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L4239;
    }
  goto L3525;

 L4239: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L4240;
    }
  x2 = XEXP (x1, 0);
  goto L3525;

 L4240: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4241;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L4241: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4242;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L4242: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4243;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L4243: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L4244;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L4244: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 1)
    goto L4245;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L4245: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L4246;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L4246: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19
      && (TARGET_SINGLE_STRINGOP || optimize_size))
    {
      return 398;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3525;

 L3526: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == IF_THEN_ELSE)
    goto L3527;
  goto ret0;

 L3527: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (comparison_operator (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L3528;
    }
  goto ret0;

 L3528: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L3529;
    }
  goto ret0;

 L3529: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (register_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L3530;
    }
  goto ret0;

 L3530: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  switch (GET_CODE (x3))
    {
    case LABEL_REF:
      goto L3531;
    case PC:
      goto L3554;
    default:
     break;
   }
  goto ret0;

 L3531: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L3532;

 L3532: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC)
    goto L3533;
  goto ret0;

 L3533: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3534;
  goto ret0;

 L3534: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18)
    goto L3535;
  goto ret0;

 L3535: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3536;
  goto ret0;

 L3536: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_CMOVE && TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2])))
    {
      return 320;
    }
  goto ret0;

 L3554: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == LABEL_REF)
    goto L3555;
  goto ret0;

 L3555: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L3556;

 L3556: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3557;
  goto ret0;

 L3557: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18)
    goto L3558;
  goto ret0;

 L3558: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3559;
  goto ret0;

 L3559: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_CMOVE && TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2])))
    {
      return 321;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_21 PARAMS ((rtx, rtx, int *));
static int
recog_21 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L7438;
    case HImode:
      goto L7439;
    case QImode:
      goto L7440;
    default:
      break;
    }
 L3572: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == PC)
    goto L3573;
  goto ret0;

 L7438: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == MEM)
    goto L4110;
 L7434: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L743;
    }
 L7436: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L1649;
    }
  goto L3572;

 L4110: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L4111;
    }
  goto L7434;

 L4111: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MEM)
    goto L4112;
  x2 = XEXP (x1, 0);
  goto L7434;

 L4112: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4113;
    }
  x2 = XEXP (x1, 0);
  goto L7434;

 L4113: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4114;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4114: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4115;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4115: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4116;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4116: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[2]))
    goto L4117;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4117: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 4)
    goto L4118;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4118: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == SET)
    goto L4119;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4119: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4120;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4120: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4121;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4121: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[3]))
    goto L4122;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4122: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 4)
    goto L4123;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4123: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L4124;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L4124: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19
      && (TARGET_SINGLE_STRINGOP || optimize_size))
    {
      return 391;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7434;

 L743: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == FIX)
    goto L744;
  x2 = XEXP (x1, 0);
  goto L7436;

 L744: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L745;
    }
  x2 = XEXP (x1, 0);
  goto L7436;

 L745: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L746;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7436;

 L746: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L747;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7436;

 L747: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L748;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7436;

 L748: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L749;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7436;

 L749: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L750;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7436;

 L750: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[4] = x2;
      goto L751;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7436;

 L751: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FLOAT_MODE_P (GET_MODE (operands[1]))))
    {
      return 111;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7436;

 L1649: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L7441;
  x2 = XEXP (x1, 0);
  goto L3572;

 L7441: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case DIV:
      goto L1650;
    case UDIV:
      goto L1727;
    case UNSPEC:
      goto L7444;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L3572;

 L1650: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1651;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L1651: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1652;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L1652: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1653;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1653: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L1654;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1654: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MOD)
    goto L1655;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1655: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1656;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1656: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L1657;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1657: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L1658;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1658: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[4] = x2;
      goto L1659;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1659: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L1660;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1660: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 178;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1727: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L1728;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L1728: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L1729;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L1729: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1730;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1730: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L1731;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1731: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == UMOD)
    goto L1732;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1732: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1733;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1733: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L1734;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1734: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L1735;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1735: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[3]))
    goto L1736;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1736: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L1737;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1737: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 181;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L7444: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x2, 0) == 4
      && XINT (x2, 1) == 0)
    goto L4336;
  x2 = XEXP (x1, 0);
  goto L3572;

 L4336: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 0);
  if (GET_MODE (x3) == BLKmode
      && GET_CODE (x3) == MEM)
    goto L4337;
  x2 = XEXP (x1, 0);
  goto L3572;

 L4337: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[5] = x4;
      goto L4338;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L4338: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 1);
  if (general_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L4339;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L4339: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 2);
  if (immediate_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4340;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L4340: ATTRIBUTE_UNUSED_LABEL
  x3 = XVECEXP (x2, 0, 3);
  if (immediate_operand (x3, SImode))
    {
      operands[4] = x3;
      goto L4341;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L4341: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == USE)
    goto L4342;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4342: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    goto L4343;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4343: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L4344;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4344: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4345;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4345: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L4346;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4346: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 403;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L7439: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == MEM)
    goto L4128;
 L7435: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L765;
    }
 L7437: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L1754;
    }
  goto L3572;

 L4128: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L4129;
    }
  goto L7435;

 L4129: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == MEM)
    goto L4130;
  x2 = XEXP (x1, 0);
  goto L7435;

 L4130: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4131;
    }
  x2 = XEXP (x1, 0);
  goto L7435;

 L4131: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4132;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4132: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4133;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4133: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4134;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4134: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[2]))
    goto L4135;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4135: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 2)
    goto L4136;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4136: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == SET)
    goto L4137;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4137: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4138;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4138: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4139;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4139: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[3]))
    goto L4140;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4140: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 2)
    goto L4141;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4141: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L4142;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L4142: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19
      && (TARGET_SINGLE_STRINGOP || optimize_size))
    {
      return 392;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7435;

 L765: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == FIX)
    goto L766;
  x2 = XEXP (x1, 0);
  goto L7437;

 L766: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L767;
    }
  x2 = XEXP (x1, 0);
  goto L7437;

 L767: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L768;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7437;

 L768: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L769;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7437;

 L769: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L770;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7437;

 L770: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L771;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7437;

 L771: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L772;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7437;

 L772: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[4] = x2;
      goto L773;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7437;

 L773: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FLOAT_MODE_P (GET_MODE (operands[1]))))
    {
      return 112;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7437;

 L1754: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == UDIV)
    goto L1755;
  x2 = XEXP (x1, 0);
  goto L3572;

 L1755: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L1756;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L1756: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, HImode))
    {
      operands[2] = x3;
      goto L1757;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L1757: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L1758;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1758: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L1759;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1759: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == UMOD)
    goto L1760;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1760: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L1761;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1761: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L1762;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1762: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L1763;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1763: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, HImode))
    {
      operands[4] = x2;
      goto L1764;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1764: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L1765;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L1765: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      return 182;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L7440: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == MEM)
    goto L4146;
  goto L3572;

 L4146: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L4147;
    }
  goto L3572;

 L4147: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == MEM)
    goto L4148;
  x2 = XEXP (x1, 0);
  goto L3572;

 L4148: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4149;
    }
  x2 = XEXP (x1, 0);
  goto L3572;

 L4149: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4150;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4150: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4151;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4151: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4152;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4152: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[2]))
    goto L4153;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4153: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 1)
    goto L4154;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4154: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == SET)
    goto L4155;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4155: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4156;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4156: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4157;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4157: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[3]))
    goto L4158;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4158: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 1)
    goto L4159;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4159: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L4160;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L4160: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19
      && (TARGET_SINGLE_STRINGOP || optimize_size))
    {
      return 393;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L3572;

 L3573: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == IF_THEN_ELSE)
    goto L3702;
  goto ret0;

 L3702: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == NE)
    goto L3703;
 L3574: ATTRIBUTE_UNUSED_LABEL
  if (comparison_operator (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L3575;
    }
  goto ret0;

 L3703: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L3704;
    }
  goto L3574;

 L3704: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L3705;
  goto L3574;

 L3705: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == LABEL_REF)
    goto L3706;
  x3 = XEXP (x2, 0);
  goto L3574;

 L3706: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[0] = x4;
  goto L3707;

 L3707: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC)
    goto L3708;
  x3 = XEXP (x2, 0);
  goto L3574;

 L3708: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3709;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3709: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L3710;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3710: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L3711;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3711: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L3712;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3712: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == -1)
    goto L3713;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3713: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3714;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3714: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L3715;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3715: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L3716;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3716: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_USE_LOOP))
    {
      return 330;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L3574;

 L3575: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L3576;
    }
  goto ret0;

 L3576: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonimmediate_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L3577;
    }
 L3629: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L3630;
    }
  goto ret0;

 L3577: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  switch (GET_CODE (x3))
    {
    case LABEL_REF:
      goto L3578;
    case PC:
      goto L3604;
    default:
     break;
   }
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3578: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L3579;

 L3579: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC)
    goto L3580;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3580: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3581;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3581: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18)
    goto L3582;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3582: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3583;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3583: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L3584;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3584: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L3585;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3585: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[4] = x2;
      goto L3586;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3586: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_MODE (operands[1]) == SFmode || GET_MODE (operands[1]) == DFmode)
   && GET_MODE (operands[1]) == GET_MODE (operands[2])
   && !ix86_use_fcomi_compare (GET_CODE (operands[0]))
   && SELECT_CC_MODE (GET_CODE (operands[0]),
		      operands[1], operands[2]) == CCFPmode))
    {
      return 322;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3604: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == LABEL_REF)
    goto L3605;
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3605: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L3606;

 L3606: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3607;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3607: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18)
    goto L3608;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3608: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3609;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3609: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L3610;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3610: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L3611;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3611: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[4] = x2;
      goto L3612;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3612: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && (GET_MODE (operands[1]) == SFmode || GET_MODE (operands[1]) == DFmode)
   && GET_MODE (operands[1]) == GET_MODE (operands[2])
   && !ix86_use_fcomi_compare (GET_CODE (operands[0]))
   && SELECT_CC_MODE (GET_CODE (operands[0]),
		      operands[1], operands[2]) == CCFPmode))
    {
      return 323;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  x4 = XEXP (x3, 1);
  goto L3629;

 L3630: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  switch (GET_CODE (x3))
    {
    case LABEL_REF:
      goto L3631;
    case PC:
      goto L3657;
    default:
     break;
   }
  goto ret0;

 L3631: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L3632;

 L3632: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC)
    goto L3633;
  goto ret0;

 L3633: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3634;
  goto ret0;

 L3634: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18)
    goto L3635;
  goto ret0;

 L3635: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3636;
  goto ret0;

 L3636: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L3637;
  goto ret0;

 L3637: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L3638;
  goto ret0;

 L3638: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[4] = x2;
      goto L3639;
    }
  goto ret0;

 L3639: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2])))
    {
      return 324;
    }
  goto ret0;

 L3657: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == LABEL_REF)
    goto L3658;
  goto ret0;

 L3658: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  operands[3] = x4;
  goto L3659;

 L3659: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L3660;
  goto ret0;

 L3660: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18)
    goto L3661;
  goto ret0;

 L3661: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L3662;
  goto ret0;

 L3662: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L3663;
  goto ret0;

 L3663: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L3664;
  goto ret0;

 L3664: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[4] = x2;
      goto L3665;
    }
  goto ret0;

 L3665: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387
   && FLOAT_MODE_P (GET_MODE (operands[1]))
   && GET_MODE (operands[1]) == GET_MODE (operands[2])))
    {
      return 325;
    }
  goto ret0;
 ret0:
  return -1;
}

static int recog_22 PARAMS ((rtx, rtx, int *));
static int
recog_22 (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;

  switch (XVECLEN (x0, 0))
    {
    case 2:
      goto L202;
    case 3:
      goto L4458;
    case 5:
      goto L717;
    case 4:
      goto L4446;
    case 6:
      goto L4162;
    case 7:
      goto L4288;
    case 17:
      goto L5429;
    default:
      break;
    }
  goto ret0;

 L202: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  switch (GET_CODE (x1))
    {
    case SET:
      goto L203;
    case CALL:
      goto L3734;
    case RETURN:
      goto L3765;
    default:
     break;
   }
  goto ret0;

 L203: ATTRIBUTE_UNUSED_LABEL
  return recog_18 (x0, insn, pnum_clobbers);

 L3734: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == MEM)
    goto L3735;
  goto ret0;

 L3735: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7396;
  goto ret0;

 L7396: ATTRIBUTE_UNUSED_LABEL
  if (constant_call_address_operand (x3, SImode))
    {
      operands[0] = x3;
      goto L3736;
    }
 L7397: ATTRIBUTE_UNUSED_LABEL
  if (call_insn_operand (x3, SImode))
    {
      operands[0] = x3;
      goto L3746;
    }
  goto ret0;

 L3736: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  operands[1] = x2;
  goto L3737;

 L3737: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3738;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L7397;

 L3738: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L3739;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L7397;

 L3739: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L3740;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L7397;

 L3740: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L3741;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L7397;

 L3741: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (immediate_operand (x3, SImode))
    {
      operands[2] = x3;
      return 331;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  x3 = XEXP (x2, 0);
  goto L7397;

 L3746: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  operands[1] = x2;
  goto L3747;

 L3747: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L3748;
  goto ret0;

 L3748: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L3749;
  goto ret0;

 L3749: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L3750;
  goto ret0;

 L3750: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L3751;
  goto ret0;

 L3751: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (immediate_operand (x3, SImode))
    {
      operands[2] = x3;
      return 332;
    }
  goto ret0;

 L3765: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == USE)
    goto L3771;
  goto ret0;

 L3771: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3772;
    }
  if (const_int_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3767;
    }
  goto ret0;

 L3772: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return 338;
    }
  goto ret0;

 L3767: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return 337;
    }
  goto ret0;

 L4458: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_MODE (x1) == SImode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 3)
    goto L4459;
  if (GET_CODE (x1) == SET)
    goto L210;
  goto ret0;

 L4459: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4460;
    }
  goto ret0;

 L4460: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4461;
  goto ret0;

 L4461: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L4462;
  goto ret0;

 L4462: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MINUS)
    goto L4463;
  goto ret0;

 L4463: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L4464;
  goto ret0;

 L4464: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[0]))
    goto L4465;
  goto ret0;

 L4465: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L4466;
  goto ret0;

 L4466: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0])
      && (TARGET_STACK_PROBE)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 1;
      return 412;
    }
  goto ret0;

 L210: ATTRIBUTE_UNUSED_LABEL
  return recog_20 (x0, insn, pnum_clobbers);

 L717: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L718;
  goto ret0;

 L718: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L719;
    }
  goto ret0;

 L719: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == FIX)
    goto L720;
  goto ret0;

 L720: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L721;
    }
  goto ret0;

 L721: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L722;
  goto ret0;

 L722: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L723;
    }
  goto ret0;

 L723: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L724;
  goto ret0;

 L724: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DImode))
    {
      operands[3] = x2;
      goto L725;
    }
  goto ret0;

 L725: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L726;
  goto ret0;

 L726: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[4] = x2;
      goto L727;
    }
  goto ret0;

 L727: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == CLOBBER)
    goto L728;
  goto ret0;

 L728: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, VOIDmode))
    {
      operands[5] = x2;
      goto L729;
    }
  goto ret0;

 L729: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FLOAT_MODE_P (GET_MODE (operands[1]))))
    {
      return 110;
    }
  goto ret0;

 L4446: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_MODE (x1) == SImode
      && GET_CODE (x1) == UNSPEC
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 3)
    goto L4447;
  if (GET_CODE (x1) == SET)
    goto L742;
  goto ret0;

 L4447: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4448;
    }
  goto ret0;

 L4448: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4449;
  goto ret0;

 L4449: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L4450;
  goto ret0;

 L4450: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MINUS)
    goto L4451;
  goto ret0;

 L4451: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L4452;
  goto ret0;

 L4452: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[0]))
    goto L4453;
  goto ret0;

 L4453: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L4454;
  goto ret0;

 L4454: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L4455;
  goto ret0;

 L4455: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L4456;
  goto ret0;

 L4456: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_STACK_PROBE))
    {
      return 412;
    }
  goto ret0;

 L742: ATTRIBUTE_UNUSED_LABEL
  return recog_21 (x0, insn, pnum_clobbers);

 L4162: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L4163;
  goto ret0;

 L4163: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode)
    goto L7445;
  goto ret0;

 L7445: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L4164;
    }
 L7446: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4250;
    }
  goto ret0;

 L4164: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0)
    goto L4165;
  x2 = XEXP (x1, 0);
  goto L7446;

 L4165: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4166;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4166: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4167;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4167: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4168;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4168: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7447;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L7447: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == ASHIFT)
    goto L4169;
  if (register_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4196;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4169: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[5] = x4;
      goto L4170;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4170: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L4171;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4171: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4172;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4172: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == SET)
    goto L4173;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4173: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4174;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4174: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4175;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4175: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == ASHIFT)
    goto L4176;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4176: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (rtx_equal_p (x4, operands[5]))
    goto L4177;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4177: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L4178;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4178: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, SImode))
    {
      operands[4] = x3;
      goto L4179;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4179: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == SET)
    goto L4180;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4180: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L4181;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4181: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[3]))
    goto L4182;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4182: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L4183;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4183: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[4]))
    goto L4184;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4184: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == USE)
    goto L4185;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4185: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[5]))
    goto L4186;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4186: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == USE)
    goto L4187;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4187: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    {
      return 394;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4196: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, SImode))
    {
      operands[5] = x3;
      goto L4197;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4197: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == SET)
    goto L4198;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4198: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4199;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4199: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4200;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4200: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[4] = x3;
      goto L4201;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4201: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[5]))
    goto L4202;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4202: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == SET)
    goto L4203;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4203: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L4204;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4204: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[3]))
    goto L4205;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4205: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L4206;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4206: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[4]))
    goto L4207;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4207: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == USE)
    goto L4208;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4208: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[5]))
    goto L4209;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4209: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == USE)
    goto L4210;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4210: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    {
      return 395;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7446;

 L4250: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0)
    goto L4251;
  goto ret0;

 L4251: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L4252;
  goto ret0;

 L4252: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4253;
    }
  goto ret0;

 L4253: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L4254;
  goto ret0;

 L4254: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7449;
  goto ret0;

 L7449: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == ASHIFT)
    goto L4255;
  if (register_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4276;
    }
  goto ret0;

 L4255: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[4] = x4;
      goto L4256;
    }
  goto ret0;

 L4256: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 2)
    goto L4257;
  goto ret0;

 L4257: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, SImode))
    {
      operands[3] = x3;
      goto L4258;
    }
  goto ret0;

 L4258: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == SET)
    goto L4259;
  goto ret0;

 L4259: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L4260;
  goto ret0;

 L4260: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[3]))
    goto L4261;
  goto ret0;

 L4261: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0)
    goto L4262;
  goto ret0;

 L4262: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L4263;
  goto ret0;

 L4263: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L4264;
    }
  goto ret0;

 L4264: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == USE)
    goto L4265;
  goto ret0;

 L4265: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[4]))
    goto L4266;
  goto ret0;

 L4266: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == USE)
    goto L4267;
  goto ret0;

 L4267: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    {
      return 399;
    }
  goto ret0;

 L4276: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, SImode))
    {
      operands[4] = x3;
      goto L4277;
    }
  goto ret0;

 L4277: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == SET)
    goto L4278;
  goto ret0;

 L4278: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L4279;
  goto ret0;

 L4279: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[3]))
    goto L4280;
  goto ret0;

 L4280: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0)
    goto L4281;
  goto ret0;

 L4281: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L4282;
  goto ret0;

 L4282: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[2] = x2;
      goto L4283;
    }
  goto ret0;

 L4283: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == USE)
    goto L4284;
  goto ret0;

 L4284: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[4]))
    goto L4285;
  goto ret0;

 L4285: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == USE)
    goto L4286;
  goto ret0;

 L4286: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    {
      return 400;
    }
  goto ret0;

 L4288: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L4289;
  goto ret0;

 L4289: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L4290;
  goto ret0;

 L4290: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == CCmode)
    goto L7451;
  goto ret0;

 L7451: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case COMPARE:
      goto L4291;
    case IF_THEN_ELSE:
      goto L4311;
    default:
     break;
   }
  goto ret0;

 L4291: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == BLKmode
      && GET_CODE (x3) == MEM)
    goto L4292;
  goto ret0;

 L4292: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[4] = x4;
      goto L4293;
    }
  goto ret0;

 L4293: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == BLKmode
      && GET_CODE (x3) == MEM)
    goto L4294;
  goto ret0;

 L4294: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[5] = x4;
      goto L4295;
    }
  goto ret0;

 L4295: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == USE)
    goto L4296;
  goto ret0;

 L4296: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[6] = x2;
      goto L4297;
    }
  goto ret0;

 L4297: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L4298;
  goto ret0;

 L4298: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (immediate_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L4299;
    }
  goto ret0;

 L4299: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L4300;
  goto ret0;

 L4300: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    goto L4301;
  goto ret0;

 L4301: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == CLOBBER)
    goto L4302;
  goto ret0;

 L4302: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4303;
    }
  goto ret0;

 L4303: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == CLOBBER)
    goto L4304;
  goto ret0;

 L4304: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4305;
    }
  goto ret0;

 L4305: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 6);
  if (GET_CODE (x1) == CLOBBER)
    goto L4306;
  goto ret0;

 L4306: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[2] = x2;
      return 401;
    }
  goto ret0;

 L4311: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == NE)
    goto L4312;
  goto ret0;

 L4312: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[6] = x4;
      goto L4313;
    }
  goto ret0;

 L4313: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L4314;
  goto ret0;

 L4314: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == CCmode
      && GET_CODE (x3) == COMPARE)
    goto L4315;
  goto ret0;

 L4315: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == BLKmode
      && GET_CODE (x4) == MEM)
    goto L4316;
  goto ret0;

 L4316: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, SImode))
    {
      operands[4] = x5;
      goto L4317;
    }
  goto ret0;

 L4317: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == BLKmode
      && GET_CODE (x4) == MEM)
    goto L4318;
  goto ret0;

 L4318: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, SImode))
    {
      operands[5] = x5;
      goto L4319;
    }
  goto ret0;

 L4319: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L4320;
  goto ret0;

 L4320: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == USE)
    goto L4321;
  goto ret0;

 L4321: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (immediate_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L4322;
    }
  goto ret0;

 L4322: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L4323;
  goto ret0;

 L4323: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L4324;
  goto ret0;

 L4324: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L4325;
  goto ret0;

 L4325: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    goto L4326;
  goto ret0;

 L4326: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == CLOBBER)
    goto L4327;
  goto ret0;

 L4327: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L4328;
    }
  goto ret0;

 L4328: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == CLOBBER)
    goto L4329;
  goto ret0;

 L4329: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L4330;
    }
  goto ret0;

 L4330: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 6);
  if (GET_CODE (x1) == CLOBBER)
    goto L4331;
  goto ret0;

 L4331: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[2] = x2;
      return 402;
    }
  goto ret0;

 L5429: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == UNSPEC_VOLATILE
      && XVECLEN (x1, 0) == 1
      && XINT (x1, 1) == 31)
    goto L5430;
  goto ret0;

 L5430: ATTRIBUTE_UNUSED_LABEL
  x2 = XVECEXP (x1, 0, 0);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0)
    goto L5431;
  goto ret0;

 L5431: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5432;
  goto ret0;

 L5432: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 8)
    goto L5433;
  goto ret0;

 L5433: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L5434;
  goto ret0;

 L5434: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 9)
    goto L5435;
  goto ret0;

 L5435: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L5436;
  goto ret0;

 L5436: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 10)
    goto L5437;
  goto ret0;

 L5437: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == CLOBBER)
    goto L5438;
  goto ret0;

 L5438: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 11)
    goto L5439;
  goto ret0;

 L5439: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == CLOBBER)
    goto L5440;
  goto ret0;

 L5440: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 12)
    goto L5441;
  goto ret0;

 L5441: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 6);
  if (GET_CODE (x1) == CLOBBER)
    goto L5442;
  goto ret0;

 L5442: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 13)
    goto L5443;
  goto ret0;

 L5443: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 7);
  if (GET_CODE (x1) == CLOBBER)
    goto L5444;
  goto ret0;

 L5444: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 14)
    goto L5445;
  goto ret0;

 L5445: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 8);
  if (GET_CODE (x1) == CLOBBER)
    goto L5446;
  goto ret0;

 L5446: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == XFmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 15)
    goto L5447;
  goto ret0;

 L5447: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 9);
  if (GET_CODE (x1) == CLOBBER)
    goto L5448;
  goto ret0;

 L5448: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 29)
    goto L5449;
  goto ret0;

 L5449: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 10);
  if (GET_CODE (x1) == CLOBBER)
    goto L5450;
  goto ret0;

 L5450: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 30)
    goto L5451;
  goto ret0;

 L5451: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 11);
  if (GET_CODE (x1) == CLOBBER)
    goto L5452;
  goto ret0;

 L5452: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 31)
    goto L5453;
  goto ret0;

 L5453: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 12);
  if (GET_CODE (x1) == CLOBBER)
    goto L5454;
  goto ret0;

 L5454: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 32)
    goto L5455;
  goto ret0;

 L5455: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 13);
  if (GET_CODE (x1) == CLOBBER)
    goto L5456;
  goto ret0;

 L5456: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 33)
    goto L5457;
  goto ret0;

 L5457: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 14);
  if (GET_CODE (x1) == CLOBBER)
    goto L5458;
  goto ret0;

 L5458: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 34)
    goto L5459;
  goto ret0;

 L5459: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 15);
  if (GET_CODE (x1) == CLOBBER)
    goto L5460;
  goto ret0;

 L5460: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 35)
    goto L5461;
  goto ret0;

 L5461: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 16);
  if (GET_CODE (x1) == CLOBBER)
    goto L5462;
  goto ret0;

 L5462: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 36
      && (TARGET_MMX))
    {
      return 539;
    }
  goto ret0;
 ret0:
  return -1;
}

int recog PARAMS ((rtx, rtx, int *));
int
recog (x0, insn, pnum_clobbers)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *pnum_clobbers ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  int tem ATTRIBUTE_UNUSED;
  recog_data.insn = NULL_RTX;

  switch (GET_CODE (x0))
    {
    case SET:
      goto L100;
    case PARALLEL:
      goto L6671;
    case CALL:
      goto L3753;
    case UNSPEC_VOLATILE:
      goto L6675;
    case RETURN:
      goto L6676;
    case CONST_INT:
      goto L6677;
    case TRAP_IF:
      goto L4504;
    case UNSPEC:
      goto L6684;
    default:
     break;
   }
  goto ret0;

 L100: ATTRIBUTE_UNUSED_LABEL
  return recog_10 (x0, insn, pnum_clobbers);

 L6671: ATTRIBUTE_UNUSED_LABEL
  return recog_22 (x0, insn, pnum_clobbers);

 L3753: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 0);
  if (GET_MODE (x1) == QImode
      && GET_CODE (x1) == MEM)
    goto L3754;
  goto ret0;

 L3754: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode)
    goto L7453;
  goto ret0;

 L7453: ATTRIBUTE_UNUSED_LABEL
  if (constant_call_address_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3755;
    }
 L7454: ATTRIBUTE_UNUSED_LABEL
  if (call_insn_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L3759;
    }
  goto ret0;

 L3755: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  operands[1] = x1;
  return 333;

 L3759: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  operands[1] = x1;
  return 334;

 L6675: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x0, 0) == 1)
    goto L7455;
  goto ret0;

 L7455: ATTRIBUTE_UNUSED_LABEL
  switch (XINT (x0, 1))
    {
    case 0:
      goto L3761;
    case 13:
      goto L3805;
    case 31:
      goto L5464;
    case 37:
      goto L5466;
    default:
      break;
    }
  goto ret0;

 L3761: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 0)
    {
      return 335;
    }
  goto ret0;

 L3805: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (register_operand (x1, VOIDmode))
    {
      operands[0] = x1;
      return 342;
    }
  goto ret0;

 L5464: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 0
      && (TARGET_MMX)
      && pnum_clobbers != NULL)
    {
      *pnum_clobbers = 16;
      return 539;
    }
  goto ret0;

 L5466: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (memory_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L5467;
    }
  goto ret0;

 L5467: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_MMX))
    {
      return 540;
    }
  goto ret0;

 L6676: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return 336;
    }
  goto ret0;

 L6677: ATTRIBUTE_UNUSED_LABEL
  if (XWINT (x0, 0) == 0)
    {
      return 339;
    }
  goto ret0;

 L4504: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 0);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 1)
    goto L4505;
  if (comparison_operator (x1, VOIDmode))
    {
      operands[0] = x1;
      goto L4508;
    }
  goto ret0;

 L4505: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 5)
    {
      return 417;
    }
  goto ret0;

 L4508: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L4509;
  goto ret0;

 L4509: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0)
    goto L4510;
  goto ret0;

 L4510: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (const_int_operand (x1, VOIDmode))
    {
      operands[1] = x1;
      return 418;
    }
  goto ret0;

 L6684: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x0, 0) == 2
      && XINT (x0, 1) == 35)
    goto L5477;
  goto ret0;

 L5477: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (address_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L5478;
    }
  goto ret0;

 L5478: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (immediate_operand (x1, SImode))
    {
      operands[1] = x1;
      goto L5479;
    }
  goto ret0;

 L5479: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_SSE))
    {
      return 543;
    }
  goto ret0;
 ret0:
  return -1;
}

static rtx split_1 PARAMS ((rtx, rtx));
static rtx
split_1 (x0, insn)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  switch (GET_MODE (x1))
    {
    case CCFPmode:
      goto L7464;
    case DImode:
      goto L7465;
    case SFmode:
      goto L7467;
    case DFmode:
      goto L7469;
    default:
      break;
    }
 L5524: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, VOIDmode))
    {
      operands[0] = x1;
      goto L5525;
    }
 L5528: ATTRIBUTE_UNUSED_LABEL
  switch (GET_MODE (x1))
    {
    case XFmode:
      goto L7472;
    case TFmode:
      goto L7473;
    default:
      break;
    }
 L5861: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L5862;
 L5536: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, VOIDmode))
    {
      operands[0] = x1;
      goto L5537;
    }
 L6654: ATTRIBUTE_UNUSED_LABEL
  switch (GET_MODE (x1))
    {
    case TImode:
      goto L7474;
    case V4SFmode:
      goto L7475;
    case V4SImode:
      goto L7476;
    case V2SImode:
      goto L7477;
    case V4HImode:
      goto L7478;
    case V8QImode:
      goto L7479;
    default:
      break;
    }
 L5540: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, VOIDmode))
    {
      operands[0] = x1;
      goto L5781;
    }
  goto ret0;

 L7464: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 18)
    goto L5482;
  goto L5524;

 L5482: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == CCFPmode
      && GET_CODE (x1) == COMPARE)
    goto L5483;
  x1 = XEXP (x0, 0);
  goto L5524;

 L5483: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SFmode))
    {
      operands[0] = x2;
      goto L5484;
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L5484: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == FLOAT)
    goto L5485;
  x1 = XEXP (x0, 0);
  goto L5524;

 L5485: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L5486;
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L5486: ATTRIBUTE_UNUSED_LABEL
  if ((0 && TARGET_80387 && reload_completed))
    {
      return gen_split_554 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L7465: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, DImode))
    {
      operands[0] = x1;
      goto L5489;
    }
 L7466: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, DImode))
    {
      operands[0] = x1;
      goto L5493;
    }
  goto L5524;

 L5489: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, DImode))
    {
      operands[1] = x1;
      goto L5490;
    }
  x1 = XEXP (x0, 0);
  goto L7466;

 L5490: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && ! MMX_REG_P (operands[1])))
    {
      return gen_split_562 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L7466;

 L5493: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, DImode))
    {
      operands[1] = x1;
      goto L5494;
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L5494: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && ! MMX_REG_P (operands[0]) && ! MMX_REG_P (operands[1])))
    {
      return gen_split_563 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L7467: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, SFmode))
    {
      operands[0] = x1;
      goto L5497;
    }
 L7468: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, SFmode))
    {
      operands[0] = x1;
      goto L5505;
    }
  goto L5524;

 L5497: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SFmode)
    goto L7480;
  x1 = XEXP (x0, 0);
  goto L7468;

 L7480: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, SFmode))
    {
      operands[1] = x1;
      goto L5498;
    }
 L7481: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, SFmode))
    {
      operands[1] = x1;
      goto L5502;
    }
  x1 = XEXP (x0, 0);
  goto L7468;

 L5498: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && GET_CODE (operands[1]) == MEM
   && GET_CODE (XEXP (operands[1], 0)) == SYMBOL_REF
   && CONSTANT_POOL_ADDRESS_P (XEXP (operands[1], 0))))
    {
      return gen_split_565 (operands);
    }
  x1 = XEXP (x0, 1);
  goto L7481;

 L5502: ATTRIBUTE_UNUSED_LABEL
  if ((FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_566 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L7468;

 L5505: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (memory_operand (x1, SFmode))
    {
      operands[1] = x1;
      goto L5506;
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L5506: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && GET_CODE (operands[1]) == MEM
   && GET_CODE (XEXP (operands[1], 0)) == SYMBOL_REF
   && CONSTANT_POOL_ADDRESS_P (XEXP (operands[1], 0))
   && (!(FP_REG_P (operands[0]) || 
	 (GET_CODE (operands[0]) == SUBREG
	  && FP_REG_P (SUBREG_REG (operands[0]))))
       || standard_80387_constant_p (get_pool_constant (XEXP (operands[1], 0))))))
    {
      return gen_split_567 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L7469: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, DFmode))
    {
      operands[0] = x1;
      goto L5509;
    }
 L7470: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, DFmode))
    {
      operands[0] = x1;
      goto L5517;
    }
 L7471: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, DFmode))
    {
      operands[0] = x1;
      goto L5521;
    }
  goto L5524;

 L5509: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == DFmode)
    goto L7483;
 L5513: ATTRIBUTE_UNUSED_LABEL
  if (general_operand (x1, DFmode))
    {
      operands[1] = x1;
      goto L5514;
    }
  x1 = XEXP (x0, 0);
  goto L7470;

 L7483: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == FLOAT_EXTEND)
    goto L5639;
  if (register_operand (x1, DFmode))
    {
      operands[1] = x1;
      goto L5510;
    }
  goto L5513;

 L5639: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L5640;
    }
  goto L5513;

 L5640: ATTRIBUTE_UNUSED_LABEL
  if ((FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_595 (operands);
    }
  x1 = XEXP (x0, 1);
  goto L5513;

 L5510: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_569 (operands);
    }
  x1 = XEXP (x0, 1);
  goto L5513;

 L5514: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return gen_split_570 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L7470;

 L5517: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, DFmode))
    {
      operands[1] = x1;
      goto L5518;
    }
  x1 = XEXP (x0, 0);
  goto L7471;

 L5518: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && ! (FP_REG_P (operands[0]) || 
	 (GET_CODE (operands[0]) == SUBREG
	  && FP_REG_P (SUBREG_REG (operands[0]))))
   && ! (FP_REG_P (operands[1]) || 
	 (GET_CODE (operands[1]) == SUBREG
	  && FP_REG_P (SUBREG_REG (operands[1]))))))
    {
      return gen_split_571 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L7471;

 L5521: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (memory_operand (x1, DFmode))
    {
      operands[1] = x1;
      goto L5522;
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L5522: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && GET_CODE (operands[1]) == MEM
   && GET_CODE (XEXP (operands[1], 0)) == SYMBOL_REF
   && CONSTANT_POOL_ADDRESS_P (XEXP (operands[1], 0))
   && standard_80387_constant_p (get_pool_constant (XEXP (operands[1], 0)))))
    {
      return gen_split_572 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5524;

 L5525: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, VOIDmode))
    {
      operands[1] = x1;
      goto L5526;
    }
  x1 = XEXP (x0, 0);
  goto L5528;

 L5526: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && (GET_MODE (operands[0]) == XFmode
       || GET_MODE (operands[0]) == TFmode
       || GET_MODE (operands[0]) == DFmode)
   && (!REG_P (operands[1]) || !FP_REGNO_P (REGNO (operands[1])))))
    {
      return gen_split_575 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5528;

 L7472: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, XFmode))
    {
      operands[0] = x1;
      goto L5529;
    }
  goto L5861;

 L5529: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == XFmode)
    goto L7485;
  x1 = XEXP (x0, 0);
  goto L5861;

 L7485: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == FLOAT_EXTEND)
    goto L5644;
  if (register_operand (x1, XFmode))
    {
      operands[1] = x1;
      goto L5530;
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5644: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SFmode:
      goto L7486;
    case DFmode:
      goto L7487;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L7486: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L5645;
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5645: ATTRIBUTE_UNUSED_LABEL
  if ((FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_596 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L7487: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L5655;
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5655: ATTRIBUTE_UNUSED_LABEL
  if ((FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_598 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5530: ATTRIBUTE_UNUSED_LABEL
  if ((FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_576 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L7473: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, TFmode))
    {
      operands[0] = x1;
      goto L5533;
    }
  goto L5861;

 L5533: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == TFmode)
    goto L7489;
  x1 = XEXP (x0, 0);
  goto L5861;

 L7489: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == FLOAT_EXTEND)
    goto L5649;
  if (register_operand (x1, TFmode))
    {
      operands[1] = x1;
      goto L5534;
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5649: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SFmode:
      goto L7490;
    case DFmode:
      goto L7491;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L7490: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SFmode))
    {
      operands[1] = x2;
      goto L5650;
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5650: ATTRIBUTE_UNUSED_LABEL
  if ((FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_597 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L7491: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DFmode))
    {
      operands[1] = x2;
      goto L5660;
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5660: ATTRIBUTE_UNUSED_LABEL
  if ((FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_599 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5534: ATTRIBUTE_UNUSED_LABEL
  if ((FP_REGNO_P (REGNO (operands[1]))))
    {
      return gen_split_577 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5861;

 L5862: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == COMPARE)
    goto L5863;
  x1 = XEXP (x0, 0);
  goto L5536;

 L5863: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == ZERO_EXTRACT)
    goto L5864;
  if (GET_CODE (x2) == AND)
    goto L6317;
  x1 = XEXP (x0, 0);
  goto L5536;

 L5864: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L5865;
    }
  x1 = XEXP (x0, 0);
  goto L5536;

 L5865: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L5866;
    }
  x1 = XEXP (x0, 0);
  goto L5536;

 L5866: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (const_int_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L5867;
    }
  x1 = XEXP (x0, 0);
  goto L5536;

 L5867: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return gen_split_673 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5536;

 L6317: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (aligned_operand (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L6318;
    }
  x1 = XEXP (x0, 0);
  goto L5536;

 L6318: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L6319;
    }
  x1 = XEXP (x0, 0);
  goto L5536;

 L6319: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (! TARGET_PARTIAL_REG_STALL && reload_completed
   && ix86_match_ccmode (insn, CCNOmode)
   && (GET_MODE (operands[0]) == HImode
       || (GET_MODE (operands[0]) == QImode 
	   && (TARGET_PROMOTE_QImode || optimize_size)))))
    {
      return gen_split_835 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5536;

 L5537: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (general_operand (x1, VOIDmode))
    {
      operands[1] = x1;
      goto L5538;
    }
  x1 = XEXP (x0, 0);
  goto L6654;

 L5538: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) != MEM)
   && (GET_MODE (operands[0]) == XFmode || GET_MODE (operands[0]) == TFmode)
   && ! (FP_REG_P (operands[0]) || 
	 (GET_CODE (operands[0]) == SUBREG
	  && FP_REG_P (SUBREG_REG (operands[0]))))
   && ! (FP_REG_P (operands[1]) || 
	 (GET_CODE (operands[1]) == SUBREG
	  && FP_REG_P (SUBREG_REG (operands[1]))))))
    {
      return gen_split_578 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L6654;

 L7474: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, TImode))
    {
      operands[0] = x1;
      goto L6655;
    }
  goto L5540;

 L6655: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, TImode))
    {
      operands[1] = x1;
      return gen_split_888 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5540;

 L7475: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V4SFmode))
    {
      operands[0] = x1;
      goto L6658;
    }
  goto L5540;

 L6658: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V4SFmode))
    {
      operands[1] = x1;
      return gen_split_889 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5540;

 L7476: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V4SImode))
    {
      operands[0] = x1;
      goto L6661;
    }
  goto L5540;

 L6661: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V4SImode))
    {
      operands[1] = x1;
      return gen_split_890 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5540;

 L7477: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V2SImode))
    {
      operands[0] = x1;
      goto L6664;
    }
  goto L5540;

 L6664: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V2SImode))
    {
      operands[1] = x1;
      return gen_split_891 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5540;

 L7478: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V4HImode))
    {
      operands[0] = x1;
      goto L6667;
    }
  goto L5540;

 L6667: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V4HImode))
    {
      operands[1] = x1;
      return gen_split_892 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5540;

 L7479: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, V8QImode))
    {
      operands[0] = x1;
      goto L6670;
    }
  goto L5540;

 L6670: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (nonmemory_operand (x1, V8QImode))
    {
      operands[1] = x1;
      return gen_split_893 (operands);
    }
  x1 = XEXP (x0, 0);
  goto L5540;

 L5781: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  switch (GET_CODE (x1))
    {
    case FLOAT:
      goto L5782;
    case PLUS:
      goto L5795;
    case NOT:
      goto L6330;
    case IF_THEN_ELSE:
      goto L6335;
    case SUBREG:
    case MEM:
      goto L5541;
    default:
      goto L6203;
   }
 L5541: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, VOIDmode))
    {
      operands[1] = x1;
      goto L5542;
    }
 L6203: ATTRIBUTE_UNUSED_LABEL
  if (binary_fp_operator (x1, VOIDmode))
    {
      operands[3] = x1;
      goto L6204;
    }
  goto ret0;

 L5782: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L5783;
    }
  goto ret0;

 L5783: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && FLOAT_MODE_P (GET_MODE (operands[0]))))
    {
      return gen_split_635 (operands);
    }
  goto ret0;

 L5795: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_CODE (x2))
    {
    case PLUS:
      goto L5812;
    case MULT:
      goto L5804;
    default:
     break;
   }
  goto L6203;

 L5812: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == MULT)
    goto L5813;
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L5797;
    }
  goto L6203;

 L5813: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L5814;
    }
  goto L6203;

 L5814: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const248_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L5815;
    }
  goto L6203;

 L5815: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, VOIDmode))
    {
      operands[3] = x3;
      goto L5816;
    }
  goto L6203;

 L5816: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (immediate_operand (x2, VOIDmode))
    {
      operands[4] = x2;
      goto L5817;
    }
  goto L6203;

 L5817: ATTRIBUTE_UNUSED_LABEL
  if (((GET_MODE (operands[0]) == QImode || GET_MODE (operands[0]) == HImode)
   && (!TARGET_PARTIAL_REG_STALL || optimize_size)
   && GET_MODE (operands[0]) == GET_MODE (operands[1])
   && GET_MODE (operands[0]) == GET_MODE (operands[3])&& reload_completed))
    {
      return gen_split_640 (operands);
    }
  x1 = XEXP (x0, 1);
  goto L6203;

 L5797: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (register_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L5798;
    }
  goto L6203;

 L5798: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (immediate_operand (x2, VOIDmode))
    {
      operands[3] = x2;
      goto L5799;
    }
  goto L6203;

 L5799: ATTRIBUTE_UNUSED_LABEL
  if (((GET_MODE (operands[0]) == QImode || GET_MODE (operands[0]) == HImode)
   && (!TARGET_PARTIAL_REG_STALL || optimize_size)
   && GET_MODE (operands[0]) == GET_MODE (operands[1])
   && GET_MODE (operands[0]) == GET_MODE (operands[2])
   && (GET_MODE (operands[0]) == GET_MODE (operands[3])
       || GET_MODE (operands[3]) == VOIDmode)&& reload_completed))
    {
      return gen_split_638 (operands);
    }
  x1 = XEXP (x0, 1);
  goto L6203;

 L5804: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L5805;
    }
  goto L6203;

 L5805: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const248_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L5806;
    }
  goto L6203;

 L5806: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, VOIDmode))
    {
      operands[3] = x2;
      goto L5807;
    }
  goto L6203;

 L5807: ATTRIBUTE_UNUSED_LABEL
  if (((GET_MODE (operands[0]) == QImode || GET_MODE (operands[0]) == HImode)
   && (!TARGET_PARTIAL_REG_STALL || optimize_size)
   && GET_MODE (operands[0]) == GET_MODE (operands[1])
   && (GET_MODE (operands[0]) == GET_MODE (operands[3])
       || GET_MODE (operands[3]) == VOIDmode)&& reload_completed))
    {
      return gen_split_639 (operands);
    }
  x1 = XEXP (x0, 1);
  goto L6203;

 L6330: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L6331;
    }
  goto ret0;

 L6331: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_PARTIAL_REG_STALL && reload_completed
   && (GET_MODE (operands[0]) == HImode
       || (GET_MODE (operands[0]) == QImode 
	   && (TARGET_PROMOTE_QImode || optimize_size)))))
    {
      return gen_split_837 (operands);
    }
  goto ret0;

 L6335: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (comparison_operator (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L6336;
    }
  goto ret0;

 L6336: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L6337;
  goto ret0;

 L6337: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6338;
  goto ret0;

 L6338: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, VOIDmode))
    {
      operands[2] = x2;
      goto L6339;
    }
  goto ret0;

 L6339: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 2);
  if (register_operand (x2, VOIDmode))
    {
      operands[3] = x2;
      goto L6340;
    }
  goto ret0;

 L6340: ATTRIBUTE_UNUSED_LABEL
  if ((! TARGET_PARTIAL_REG_STALL && TARGET_CMOVE
   && (GET_MODE (operands[0]) == HImode
       || (GET_MODE (operands[0]) == QImode 
	   && (TARGET_PROMOTE_QImode || optimize_size)))))
    {
      return gen_split_838 (operands);
    }
  goto ret0;

 L5542: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && GET_CODE (operands[1]) == MEM
   && (GET_MODE (operands[0]) == XFmode || GET_MODE (operands[0]) == TFmode)
   && GET_CODE (XEXP (operands[1], 0)) == SYMBOL_REF
   && CONSTANT_POOL_ADDRESS_P (XEXP (operands[1], 0))
   && standard_80387_constant_p (get_pool_constant (XEXP (operands[1], 0)))))
    {
      return gen_split_579 (operands);
    }
  goto ret0;

 L6204: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == FLOAT)
    goto L6205;
  if (register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L6212;
    }
  goto ret0;

 L6205: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L6206;
    }
  goto ret0;

 L6206: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (register_operand (x2, VOIDmode))
    {
      operands[2] = x2;
      goto L6207;
    }
  goto ret0;

 L6207: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed
   && FLOAT_MODE_P (GET_MODE (operands[0]))))
    {
      return gen_split_810 (operands);
    }
  goto ret0;

 L6212: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == FLOAT)
    goto L6213;
  goto ret0;

 L6213: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L6214;
    }
  goto ret0;

 L6214: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed
   && FLOAT_MODE_P (GET_MODE (operands[0]))))
    {
      return gen_split_811 (operands);
    }
  goto ret0;
 ret0:
  return 0;
}

static rtx split_2 PARAMS ((rtx, rtx));
static rtx
split_2 (x0, insn)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;

  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L7492;
    case HImode:
      goto L7493;
    case DImode:
      goto L7494;
    case SFmode:
      goto L7496;
    case DFmode:
      goto L7498;
    default:
      break;
    }
 L6027: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6028;
 L5820: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L5821;
    }
 L5878: ATTRIBUTE_UNUSED_LABEL
  if (q_regs_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L5879;
    }
 L5915: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L5916;
    }
 L5922: ATTRIBUTE_UNUSED_LABEL
  switch (GET_MODE (x2))
    {
    case DFmode:
      goto L7500;
    case XFmode:
      goto L7501;
    case TFmode:
      goto L7502;
    default:
      break;
    }
 L6294: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L6323;
    }
  goto ret0;

 L7492: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L5546;
    }
  goto L6027;

 L5546: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L7503;
  x2 = XEXP (x1, 0);
  goto L6027;

 L7503: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L5547;
    case AND:
      goto L5872;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5547: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case HImode:
      goto L7505;
    case QImode:
      goto L7506;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L7505: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, HImode))
    {
      operands[1] = x3;
      goto L5548;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5548: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5549;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5549: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed && TARGET_ZERO_EXTEND_WITH_AND && !optimize_size))
    {
      return gen_split_581 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7506: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L5576;
    }
 L7507: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L5590;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5576: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5577;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7507;

 L5577: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7508;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7507;

 L7508: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7510;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7507;

 L7510: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7512;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7507;

 L7512: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed 
   && (!TARGET_ZERO_EXTEND_WITH_AND || optimize_size)
   && (!REG_P (operands[1]) || QI_REG_P (operands[1]))))
    {
      return gen_split_587 (operands);
    }
 L7513: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && QI_REG_P (operands[0])
   && (QI_REG_P (operands[1]) || GET_CODE (operands[1]) == MEM)
   && (TARGET_ZERO_EXTEND_WITH_AND && !optimize_size)
   && !reg_overlap_mentioned_p (operands[0], operands[1])))
    {
      return gen_split_588 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7507;

 L5590: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5591;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5591: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed
   && true_regnum (operands[0]) == true_regnum (operands[1])))
    {
      return gen_split_589 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5872: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L5873;
  x2 = XEXP (x1, 0);
  goto L6027;

 L5873: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == -65536)
    goto L5874;
  x2 = XEXP (x1, 0);
  goto L6027;

 L5874: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5875;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5875: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (optimize_size))
    {
      return gen_split_675 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7493: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L5553;
    }
  goto L6027;

 L5553: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == ZERO_EXTEND)
    goto L5554;
  x2 = XEXP (x1, 0);
  goto L6027;

 L5554: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == QImode)
    goto L7514;
  x2 = XEXP (x1, 0);
  goto L6027;

 L7514: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L5555;
    }
 L7515: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L5569;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5555: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5556;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7515;

 L5556: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7516;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7515;

 L7516: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7518;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7515;

 L7518: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7520;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7515;

 L7520: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed 
   && (!TARGET_ZERO_EXTEND_WITH_AND || optimize_size)
   && (!REG_P (operands[1]) || QI_REG_P (operands[1]))))
    {
      return gen_split_583 (operands);
    }
 L7521: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed
   && QI_REG_P (operands[0])
   && (TARGET_ZERO_EXTEND_WITH_AND && !optimize_size)
   && !reg_overlap_mentioned_p (operands[0], operands[1])))
    {
      return gen_split_584 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L7515;

 L5569: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5570;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5570: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed
   && true_regnum (operands[0]) == true_regnum (operands[1])))
    {
      return gen_split_585 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7494: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L5595;
    }
 L7495: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L5602;
    }
  goto L6027;

 L5595: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode)
    goto L7522;
  x2 = XEXP (x1, 0);
  goto L7495;

 L7522: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L5596;
    case ASHIFT:
      goto L6072;
    case ASHIFTRT:
      goto L6098;
    case LSHIFTRT:
      goto L6116;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L7495;

 L5596: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L5597;
    }
  x2 = XEXP (x1, 0);
  goto L7495;

 L5597: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5598;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7495;

 L5598: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed && true_regnum (operands[0]) == true_regnum (operands[1])))
    {
      return gen_split_590 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7495;

 L6072: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L6073;
    }
  x2 = XEXP (x1, 0);
  goto L7495;

 L6073: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L6074;
    }
  x2 = XEXP (x1, 0);
  goto L7495;

 L6074: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6075;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7495;

 L6075: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_726 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7495;

 L6098: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L6099;
    }
  x2 = XEXP (x1, 0);
  goto L7495;

 L6099: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L6100;
    }
  x2 = XEXP (x1, 0);
  goto L7495;

 L6100: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6101;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7495;

 L6101: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_735 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7495;

 L6116: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L6117;
    }
  x2 = XEXP (x1, 0);
  goto L7495;

 L6117: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L6118;
    }
  x2 = XEXP (x1, 0);
  goto L7495;

 L6118: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6119;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7495;

 L6119: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_742 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7495;

 L5602: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode)
    goto L7526;
  x2 = XEXP (x1, 0);
  goto L6027;

 L7526: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case ZERO_EXTEND:
      goto L5603;
    case PLUS:
      goto L5788;
    case MINUS:
      goto L5830;
    case NEG:
      goto L5896;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5603: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (general_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L5604;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5604: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5605;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5605: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_591 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5788: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L5789;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5789: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L5790;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5790: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5791;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5791: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_636 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5830: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (nonimmediate_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L5831;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5831: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (general_operand (x3, DImode))
    {
      operands[2] = x3;
      goto L5832;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5832: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5833;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5833: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_648 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5896: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (general_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L5897;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5897: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5898;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5898: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_688 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7496: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x2, SFmode))
    {
      operands[0] = x2;
      goto L5664;
    }
 L7497: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SFmode))
    {
      operands[0] = x2;
      goto L5672;
    }
  goto L6027;

 L5664: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SFmode
      && GET_CODE (x2) == FLOAT_TRUNCATE)
    goto L5665;
  x2 = XEXP (x1, 0);
  goto L7497;

 L5665: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L7530;
    case XFmode:
      goto L7531;
    case TFmode:
      goto L7532;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L7497;

 L7530: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L5666;
    }
  x2 = XEXP (x1, 0);
  goto L7497;

 L5666: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5667;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L5667: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L5668;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L5668: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return gen_split_606 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L7531: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L5682;
    }
  x2 = XEXP (x1, 0);
  goto L7497;

 L5682: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5683;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L5683: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L5684;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L5684: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return gen_split_609 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L7532: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L5698;
    }
  x2 = XEXP (x1, 0);
  goto L7497;

 L5698: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5699;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L5699: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L5700;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L5700: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return gen_split_612 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7497;

 L5672: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SFmode)
    goto L7533;
  x2 = XEXP (x1, 0);
  goto L6027;

 L7533: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case FLOAT_TRUNCATE:
      goto L5673;
    case NEG:
      goto L5903;
    case ABS:
      goto L5966;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5673: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case DFmode:
      goto L7536;
    case XFmode:
      goto L7537;
    case TFmode:
      goto L7538;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L7536: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L5674;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5674: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5675;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5675: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L5676;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5676: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return gen_split_607 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7537: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L5690;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5690: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5691;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5691: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L5692;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5692: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return gen_split_610 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7538: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L5706;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5706: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5707;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5707: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SFmode))
    {
      operands[2] = x2;
      goto L5708;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5708: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return gen_split_613 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5903: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L5904;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5904: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5905;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5905: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7539;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7539: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7541;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7541: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7543;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7543: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FP_REGNO_P (REGNO (operands[0])) && reload_completed))
    {
      return gen_split_693 (operands);
    }
 L7544: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed && !FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_694 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5966: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SFmode))
    {
      operands[1] = x3;
      goto L5967;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5967: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5968;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5968: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7545;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7545: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7547;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7547: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7549;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7549: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_706 (operands);
    }
 L7550: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed && !FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_707 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7498: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x2, DFmode))
    {
      operands[0] = x2;
      goto L5712;
    }
 L7499: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DFmode))
    {
      operands[0] = x2;
      goto L5720;
    }
  goto L6027;

 L5712: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DFmode
      && GET_CODE (x2) == FLOAT_TRUNCATE)
    goto L5713;
  x2 = XEXP (x1, 0);
  goto L7499;

 L5713: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case XFmode:
      goto L7551;
    case TFmode:
      goto L7552;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L7499;

 L7551: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L5714;
    }
  x2 = XEXP (x1, 0);
  goto L7499;

 L5714: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5715;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7499;

 L5715: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L5716;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7499;

 L5716: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return gen_split_615 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7499;

 L7552: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L5730;
    }
  x2 = XEXP (x1, 0);
  goto L7499;

 L5730: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5731;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7499;

 L5731: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L5732;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7499;

 L5732: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387))
    {
      return gen_split_618 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7499;

 L5720: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DFmode
      && GET_CODE (x2) == FLOAT_TRUNCATE)
    goto L5721;
  x2 = XEXP (x1, 0);
  goto L6027;

 L5721: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case XFmode:
      goto L7553;
    case TFmode:
      goto L7554;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L7553: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L5722;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5722: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5723;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5723: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L5724;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5724: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return gen_split_616 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L7554: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L5738;
    }
  x2 = XEXP (x1, 0);
  goto L6027;

 L5738: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5739;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5739: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DFmode))
    {
      operands[2] = x2;
      goto L5740;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L5740: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed))
    {
      return gen_split_619 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6027;

 L6028: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == COMPARE)
    goto L6029;
  x2 = XEXP (x1, 0);
  goto L5820;

 L6029: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  switch (GET_MODE (x3))
    {
    case SImode:
      goto L7555;
    case HImode:
      goto L7556;
    case QImode:
      goto L7557;
    default:
      break;
    }
 L6304: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == AND)
    goto L6305;
  x2 = XEXP (x1, 0);
  goto L5820;

 L7555: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == NOT)
    goto L6030;
  goto L6304;

 L6030: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L6031;
    }
  goto L6304;

 L6031: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6032;
  x3 = XEXP (x2, 0);
  goto L6304;

 L6032: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L6033;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6033: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L6034;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6034: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == NOT)
    goto L6035;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6035: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return gen_split_719 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L7556: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == NOT)
    goto L6041;
  goto L6304;

 L6041: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, HImode))
    {
      operands[1] = x4;
      goto L6042;
    }
  goto L6304;

 L6042: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6043;
  x3 = XEXP (x2, 0);
  goto L6304;

 L6043: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L6044;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6044: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L6045;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6045: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == NOT)
    goto L6046;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6046: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return gen_split_721 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L7557: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == NOT)
    goto L6052;
  goto L6304;

 L6052: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (nonimmediate_operand (x4, QImode))
    {
      operands[1] = x4;
      goto L6053;
    }
  goto L6304;

 L6053: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6054;
  x3 = XEXP (x2, 0);
  goto L6304;

 L6054: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L6055;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6055: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L6056;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6056: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == NOT)
    goto L6057;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6057: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (ix86_match_ccmode (insn, CCNOmode)))
    {
      return gen_split_723 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6304;

 L6305: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (aligned_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L6306;
    }
  x2 = XEXP (x1, 0);
  goto L5820;

 L6306: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (const_int_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L6307;
    }
  x2 = XEXP (x1, 0);
  goto L5820;

 L6307: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6308;
  x2 = XEXP (x1, 0);
  goto L5820;

 L6308: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L6309;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5820;

 L6309: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L6310;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5820;

 L6310: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == AND)
    goto L6311;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5820;

 L6311: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L6312;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5820;

 L6312: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2])
      && (! TARGET_PARTIAL_REG_STALL && reload_completed
   && ix86_match_ccmode (insn, CCNOmode)
   && (GET_MODE (operands[0]) == HImode
       || (GET_MODE (operands[0]) == QImode 
	   && (TARGET_PROMOTE_QImode || optimize_size)))))
    {
      return gen_split_834 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5820;

 L5821: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case PLUS:
      goto L5822;
    case ASHIFT:
      goto L6080;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L5878;

 L5822: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L5823;
    }
  x2 = XEXP (x1, 0);
  goto L5878;

 L5823: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L5824;
    }
  x2 = XEXP (x1, 0);
  goto L5878;

 L5824: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5825;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5878;

 L5825: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed
   && true_regnum (operands[0]) != true_regnum (operands[1])))
    {
      return gen_split_641 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5878;

 L6080: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L6081;
    }
  x2 = XEXP (x1, 0);
  goto L5878;

 L6081: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L6082;
    }
  x2 = XEXP (x1, 0);
  goto L5878;

 L6082: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6083;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5878;

 L6083: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed
   && true_regnum (operands[0]) != true_regnum (operands[1])))
    {
      return gen_split_730 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5878;

 L5879: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == AND)
    goto L5880;
  x2 = XEXP (x1, 0);
  goto L5915;

 L5880: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L5881;
  x2 = XEXP (x1, 0);
  goto L5915;

 L5881: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT)
    goto L7558;
  x2 = XEXP (x1, 0);
  goto L5915;

 L7558: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x3, 0))
    {
    case -256:
      goto L5882;
    case -65281:
      goto L5890;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L5915;

 L5882: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5883;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5915;

 L5883: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && ((optimize_size || !TARGET_PARTIAL_REG_STALL)
   && (GET_MODE (operands[0]) == SImode || GET_MODE (operands[0]) == HImode)))
    {
      return gen_split_676 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5915;

 L5890: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5891;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5915;

 L5891: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && ((optimize_size || !TARGET_PARTIAL_REG_STALL)
   && (GET_MODE (operands[0]) == SImode || GET_MODE (operands[0]) == HImode)))
    {
      return gen_split_677 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5915;

 L5916: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  switch (GET_CODE (x2))
    {
    case NEG:
      goto L5917;
    case ABS:
      goto L5980;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L5922;

 L5917: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (memory_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L5918;
    }
  x2 = XEXP (x1, 0);
  goto L5922;

 L5918: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5919;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5922;

 L5919: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && reload_completed && FLOAT_MODE_P (GET_MODE (operands[0]))))
    {
      return gen_split_695 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5922;

 L5980: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (memory_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L5981;
    }
  x2 = XEXP (x1, 0);
  goto L5922;

 L5981: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5982;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5922;

 L5982: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_80387 && reload_completed && FLOAT_MODE_P (GET_MODE (operands[0]))))
    {
      return gen_split_708 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L5922;

 L7500: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DFmode))
    {
      operands[0] = x2;
      goto L5923;
    }
  goto L6294;

 L5923: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DFmode)
    goto L7560;
  x2 = XEXP (x1, 0);
  goto L6294;

 L7560: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case NEG:
      goto L5924;
    case ABS:
      goto L5987;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L6294;

 L5924: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L5925;
    }
  x2 = XEXP (x1, 0);
  goto L6294;

 L5925: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5926;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L5926: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7562;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7562: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7564;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7564: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7566;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7566: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FP_REGNO_P (REGNO (operands[0])) && reload_completed))
    {
      return gen_split_697 (operands);
    }
 L7567: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed && !FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_698 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L5987: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DFmode))
    {
      operands[1] = x3;
      goto L5988;
    }
  x2 = XEXP (x1, 0);
  goto L6294;

 L5988: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5989;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L5989: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7568;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7568: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7570;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7570: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7572;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7572: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FP_REGNO_P (REGNO (operands[0])) && reload_completed))
    {
      return gen_split_710 (operands);
    }
 L7573: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed && !FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_711 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7501: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, XFmode))
    {
      operands[0] = x2;
      goto L5937;
    }
  goto L6294;

 L5937: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == XFmode)
    goto L7574;
  x2 = XEXP (x1, 0);
  goto L6294;

 L7574: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case NEG:
      goto L5938;
    case ABS:
      goto L6001;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L6294;

 L5938: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L5939;
    }
  x2 = XEXP (x1, 0);
  goto L6294;

 L5939: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5940;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L5940: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7576;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7576: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7578;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7578: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7580;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7580: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FP_REGNO_P (REGNO (operands[0])) && reload_completed))
    {
      return gen_split_701 (operands);
    }
 L7581: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed && !FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_702 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L6001: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, XFmode))
    {
      operands[1] = x3;
      goto L6002;
    }
  x2 = XEXP (x1, 0);
  goto L6294;

 L6002: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6003;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L6003: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7582;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7582: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7584;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7584: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7586;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7586: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FP_REGNO_P (REGNO (operands[0])) && reload_completed))
    {
      return gen_split_714 (operands);
    }
 L7587: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed && !FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_715 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7502: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, TFmode))
    {
      operands[0] = x2;
      goto L5951;
    }
  goto L6294;

 L5951: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == TFmode)
    goto L7588;
  x2 = XEXP (x1, 0);
  goto L6294;

 L7588: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case NEG:
      goto L5952;
    case ABS:
      goto L6015;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L6294;

 L5952: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L5953;
    }
  x2 = XEXP (x1, 0);
  goto L6294;

 L5953: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5954;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L5954: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7590;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7590: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7592;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7592: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7594;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7594: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FP_REGNO_P (REGNO (operands[0])) && reload_completed))
    {
      return gen_split_703 (operands);
    }
 L7595: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed && !FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_704 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L6015: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, TFmode))
    {
      operands[1] = x3;
      goto L6016;
    }
  x2 = XEXP (x1, 0);
  goto L6294;

 L6016: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6017;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L6017: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7596;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7596: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7598;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7598: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7600;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L7600: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && FP_REGNO_P (REGNO (operands[0])) && reload_completed))
    {
      return gen_split_716 (operands);
    }
 L7601: ATTRIBUTE_UNUSED_LABEL
  if ((TARGET_80387 && reload_completed && !FP_REGNO_P (REGNO (operands[0]))))
    {
      return gen_split_717 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6294;

 L6323: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == NEG)
    goto L6324;
  if (promotable_binary_operator (x2, VOIDmode))
    {
      operands[3] = x2;
      goto L6296;
    }
  goto ret0;

 L6324: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L6325;
    }
  goto ret0;

 L6325: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6326;
  goto ret0;

 L6326: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (! TARGET_PARTIAL_REG_STALL && reload_completed
   && (GET_MODE (operands[0]) == HImode
       || (GET_MODE (operands[0]) == QImode 
	   && (TARGET_PROMOTE_QImode || optimize_size)))))
    {
      return gen_split_836 (operands);
    }
  goto ret0;

 L6296: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L6297;
    }
  goto ret0;

 L6297: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (aligned_operand (x3, VOIDmode))
    {
      operands[2] = x3;
      goto L6298;
    }
  goto ret0;

 L6298: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6299;
  goto ret0;

 L6299: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (! TARGET_PARTIAL_REG_STALL && reload_completed
   && ((GET_MODE (operands[0]) == HImode 
	&& (!optimize_size || GET_CODE (operands[2]) != CONST_INT
	    || CONST_OK_FOR_LETTER_P (INTVAL (operands[2]), 'K')))
       || (GET_MODE (operands[0]) == QImode 
	   && (TARGET_PROMOTE_QImode || optimize_size)))))
    {
      return gen_split_833 (operands);
    }
  goto ret0;
 ret0:
  return 0;
}

static rtx split_3 PARAMS ((rtx, rtx));
static rtx
split_3 (x0, insn)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;

  switch (XVECLEN (x0, 0))
    {
    case 2:
      goto L5544;
    case 3:
      goto L5607;
    case 5:
      goto L5742;
    case 4:
      goto L5756;
    default:
      break;
    }
  goto ret0;

 L5544: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L5545;
  goto ret0;

 L5545: ATTRIBUTE_UNUSED_LABEL
  return split_2 (x0, insn);

 L5607: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L5608;
  goto ret0;

 L5608: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case DImode:
      goto L7602;
    case SImode:
      goto L7604;
    default:
      break;
    }
 L6122: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == PC)
    goto L6123;
  goto ret0;

 L7602: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L5609;
    }
 L7603: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L5629;
    }
  goto L6122;

 L5609: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == SIGN_EXTEND)
    goto L5610;
  x2 = XEXP (x1, 0);
  goto L7603;

 L5610: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L5611;
    }
  x2 = XEXP (x1, 0);
  goto L7603;

 L5611: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5612;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7603;

 L5612: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L5613;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7603;

 L5613: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L5614;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7603;

 L5614: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L5615;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7603;

 L5615: ATTRIBUTE_UNUSED_LABEL
  if (((reload_completed
    && dead_or_set_p (insn, operands[1])
    && !reg_mentioned_p (operands[1], operands[0]))))
    {
      return gen_split_592 (operands);
    }
 L5625: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return gen_split_593 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7603;

 L5629: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode)
    goto L7605;
  x2 = XEXP (x1, 0);
  goto L6122;

 L7605: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case SIGN_EXTEND:
      goto L5630;
    case ASHIFT:
      goto L6062;
    case ASHIFTRT:
      goto L6088;
    case LSHIFTRT:
      goto L6106;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L6122;

 L5630: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L5631;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L5631: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5632;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5632: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L5633;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5633: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L5634;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5634: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L5635;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5635: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return gen_split_594 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6062: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L6063;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L6063: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L6064;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L6064: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6065;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6065: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L6066;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6066: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6067;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6067: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_CMOVE && reload_completed))
    {
      return gen_split_725 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6088: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L6089;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L6089: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L6090;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L6090: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6091;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6091: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L6092;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6092: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6093;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6093: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_CMOVE && reload_completed))
    {
      return gen_split_734 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6106: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, DImode))
    {
      operands[1] = x3;
      goto L6107;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L6107: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, QImode))
    {
      operands[2] = x3;
      goto L6108;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L6108: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6109;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6109: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L6110;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6110: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6111;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6111: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_CMOVE && reload_completed))
    {
      return gen_split_741 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L7604: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L5837;
    }
  goto L6122;

 L5837: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode)
    goto L7609;
  x2 = XEXP (x1, 0);
  goto L6122;

 L7609: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case DIV:
      goto L5838;
    case UDIV:
      goto L5851;
    default:
     break;
   }
  x2 = XEXP (x1, 0);
  goto L6122;

 L5838: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L5839;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L5839: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L5840;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L5840: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L5841;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5841: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L5842;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5842: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == MOD)
    goto L5843;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5843: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L5844;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5844: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L5845;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5845: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L5846;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5846: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_667 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5851: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L5852;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L5852: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonimmediate_operand (x3, SImode))
    {
      operands[2] = x3;
      goto L5853;
    }
  x2 = XEXP (x1, 0);
  goto L6122;

 L5853: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L5854;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5854: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L5855;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5855: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == UMOD)
    goto L5856;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5856: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L5857;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5857: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[2]))
    goto L5858;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5858: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L5859;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L5859: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_668 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6122;

 L6123: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == IF_THEN_ELSE)
    goto L6124;
  goto ret0;

 L6124: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (comparison_operator (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L6125;
    }
  goto ret0;

 L6125: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L6126;
    }
  goto ret0;

 L6126: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonimmediate_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L6127;
    }
  goto ret0;

 L6127: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  operands[3] = x3;
  goto L6128;

 L6128: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  operands[4] = x3;
  goto L6129;

 L6129: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6130;
  goto ret0;

 L6130: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18)
    goto L6131;
  goto ret0;

 L6131: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6132;
  goto ret0;

 L6132: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (reload_completed))
    {
      return gen_split_791 (operands);
    }
  goto ret0;

 L5742: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L5743;
  goto ret0;

 L5743: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, DImode))
    {
      operands[0] = x2;
      goto L5744;
    }
  goto ret0;

 L5744: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == DImode
      && GET_CODE (x2) == FIX)
    goto L5745;
  goto ret0;

 L5745: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L5746;
    }
  goto ret0;

 L5746: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5747;
  goto ret0;

 L5747: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L5748;
    }
  goto ret0;

 L5748: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L5749;
  goto ret0;

 L5749: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, DImode))
    {
      operands[3] = x2;
      goto L5750;
    }
  goto ret0;

 L5750: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L5751;
  goto ret0;

 L5751: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[4] = x2;
      goto L5752;
    }
  goto ret0;

 L5752: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == CLOBBER)
    goto L5753;
  goto ret0;

 L5753: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, VOIDmode))
    {
      operands[5] = x2;
      goto L5754;
    }
  goto ret0;

 L5754: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed && !reg_overlap_mentioned_p (operands[4], operands[3])))
    {
      return gen_split_624 (operands);
    }
  goto ret0;

 L5756: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L5757;
  goto ret0;

 L5757: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L7611;
    case HImode:
      goto L7612;
    default:
      break;
    }
 L6135: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == PC)
    goto L6136;
  goto ret0;

 L7611: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L5758;
    }
  goto L6135;

 L5758: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == FIX)
    goto L5759;
  x2 = XEXP (x1, 0);
  goto L6135;

 L5759: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L5760;
    }
  x2 = XEXP (x1, 0);
  goto L6135;

 L5760: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5761;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5761: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L5762;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5762: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L5763;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5763: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L5764;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5764: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L5765;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5765: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[4] = x2;
      goto L5766;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5766: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return gen_split_629 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L7612: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L5770;
    }
  goto L6135;

 L5770: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == HImode
      && GET_CODE (x2) == FIX)
    goto L5771;
  x2 = XEXP (x1, 0);
  goto L6135;

 L5771: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L5772;
    }
  x2 = XEXP (x1, 0);
  goto L6135;

 L5772: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L5773;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5773: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L5774;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5774: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L5775;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5775: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (memory_operand (x2, HImode))
    {
      operands[3] = x2;
      goto L5776;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5776: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L5777;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5777: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[4] = x2;
      goto L5778;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L5778: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return gen_split_634 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L6135;

 L6136: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == IF_THEN_ELSE)
    goto L6153;
  goto ret0;

 L6153: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == NE)
    goto L6154;
 L6137: ATTRIBUTE_UNUSED_LABEL
  if (comparison_operator (x3, VOIDmode))
    {
      operands[0] = x3;
      goto L6138;
    }
  goto ret0;

 L6154: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, SImode))
    {
      operands[1] = x4;
      goto L6155;
    }
  goto L6137;

 L6155: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 1)
    goto L6156;
  goto L6137;

 L6156: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  operands[0] = x3;
  goto L6157;

 L6157: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == PC)
    goto L6158;
  x3 = XEXP (x2, 0);
  goto L6137;

 L6158: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == SET)
    goto L6159;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6159: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[1]))
    goto L6160;
 L6177: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L6178;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6160: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L6161;
  x2 = XEXP (x1, 0);
  goto L6177;

 L6161: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L6162;
  x2 = XEXP (x1, 0);
  goto L6177;

 L6162: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == -1)
    goto L6163;
  x2 = XEXP (x1, 0);
  goto L6177;

 L6163: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6164;
  x1 = XVECEXP (x0, 0, 1);
  x2 = XEXP (x1, 0);
  goto L6177;

 L6164: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[2] = x2;
      goto L6165;
    }
  x1 = XVECEXP (x0, 0, 1);
  x2 = XEXP (x1, 0);
  goto L6177;

 L6165: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L6166;
  x1 = XVECEXP (x0, 0, 1);
  x2 = XEXP (x1, 0);
  goto L6177;

 L6166: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_USE_LOOP
   && reload_completed
   && REGNO (operands[1]) != 2))
    {
      return gen_split_795 (operands);
    }
  x1 = XVECEXP (x0, 0, 1);
  x2 = XEXP (x1, 0);
  goto L6177;

 L6178: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L6179;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6179: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1]))
    goto L6180;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6180: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == -1)
    goto L6181;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6181: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6182;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6182: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L6183;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6183: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L6184;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6184: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (TARGET_USE_LOOP
   && reload_completed
   && (! REG_P (operands[2])
       || ! rtx_equal_p (operands[1], operands[2]))))
    {
      return gen_split_796 (operands);
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6137;

 L6138: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[1] = x4;
      goto L6139;
    }
  goto ret0;

 L6139: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (nonimmediate_operand (x4, VOIDmode))
    {
      operands[2] = x4;
      goto L6140;
    }
  goto ret0;

 L6140: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  operands[3] = x3;
  goto L6141;

 L6141: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  operands[4] = x3;
  goto L6142;

 L6142: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6143;
  goto ret0;

 L6143: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 18)
    goto L6144;
  goto ret0;

 L6144: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6145;
  goto ret0;

 L6145: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCFPmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6146;
  goto ret0;

 L6146: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == CLOBBER)
    goto L6147;
  goto ret0;

 L6147: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (scratch_operand (x2, HImode))
    {
      operands[5] = x2;
      goto L6148;
    }
  goto ret0;

 L6148: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return gen_split_792 (operands);
    }
  goto ret0;
 ret0:
  return 0;
}

rtx split_insns PARAMS ((rtx, rtx));
rtx
split_insns (x0, insn)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;
  recog_data.insn = NULL_RTX;

  switch (GET_CODE (x0))
    {
    case SET:
      goto L5481;
    case PARALLEL:
      goto L7459;
    case UNSPEC_VOLATILE:
      goto L7463;
    default:
     break;
   }
  goto ret0;

 L5481: ATTRIBUTE_UNUSED_LABEL
  return split_1 (x0, insn);

 L7459: ATTRIBUTE_UNUSED_LABEL
  return split_3 (x0, insn);

 L7463: ATTRIBUTE_UNUSED_LABEL
  if (XVECLEN (x0, 0) == 1
      && XINT (x0, 1) == 13)
    goto L6199;
  goto ret0;

 L6199: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (register_operand (x1, VOIDmode))
    {
      operands[0] = x1;
      goto L6200;
    }
  goto ret0;

 L6200: ATTRIBUTE_UNUSED_LABEL
  if ((reload_completed))
    {
      return gen_split_808 (operands);
    }
  goto ret0;
 ret0:
  return 0;
}

static rtx peephole2_1 PARAMS ((rtx, rtx, int *));
static rtx
peephole2_1 (x0, insn, _pmatch_len)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *_pmatch_len ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;

  x1 = XEXP (x0, 0);
  switch (GET_MODE (x1))
    {
    case SImode:
      goto L7616;
    case SFmode:
      goto L7617;
    case HImode:
      goto L7618;
    case QImode:
      goto L7619;
    default:
      break;
    }
 L6187: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L6188;
 L6396: ATTRIBUTE_UNUSED_LABEL
  switch (GET_MODE (x1))
    {
    case SImode:
      goto L7623;
    case HImode:
      goto L7624;
    case QImode:
      goto L7625;
    default:
      break;
    }
 L6481: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == STRICT_LOW_PART)
    goto L6482;
  if (register_operand (x1, VOIDmode))
    {
      operands[0] = x1;
      goto L6478;
    }
 L6642: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == REG
      && XINT (x1, 0) == 17)
    goto L6643;
  goto ret0;

 L7616: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L6344;
    }
 L7620: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L6364;
    }
  goto L6187;

 L6344: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (memory_operand (x1, SImode))
    {
      operands[1] = x1;
      goto L6345;
    }
  x1 = XEXP (x0, 0);
  goto L7620;

 L6345: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L7620;
  x1 = PATTERN (tem);
  if ((! optimize_size && ! TARGET_PUSH_MEMORY))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_839 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L7620;

 L6364: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 0
      && (! optimize_size
   && ! TARGET_USE_MOV0
   && TARGET_SPLIT_LONG_MOVES
   && get_attr_length (insn) >= ix86_cost->large_insn
   && peep2_regno_dead_p (0, FLAGS_REG)))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_843 (insn, operands);
      if (tem != 0)
        return tem;
    }
 L6376: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x1, SImode))
    {
      operands[1] = x1;
      goto L6377;
    }
  x1 = XEXP (x0, 0);
  goto L6187;

 L6377: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6187;
  x1 = PATTERN (tem);
  if ((! optimize_size
   && get_attr_length (insn) >= ix86_cost->large_insn
   && TARGET_SPLIT_LONG_MOVES))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_846 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6187;

 L7617: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, SFmode))
    {
      operands[0] = x1;
      goto L6349;
    }
  goto L6187;

 L6349: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (memory_operand (x1, SFmode))
    {
      operands[1] = x1;
      goto L6350;
    }
  x1 = XEXP (x0, 0);
  goto L6187;

 L6350: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6187;
  x1 = PATTERN (tem);
  if ((! optimize_size && ! TARGET_PUSH_MEMORY))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_840 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6187;

 L7618: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L6354;
    }
 L7621: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L6368;
    }
  goto L6187;

 L6354: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (memory_operand (x1, HImode))
    {
      operands[1] = x1;
      goto L6355;
    }
  x1 = XEXP (x0, 0);
  goto L7621;

 L6355: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L7621;
  x1 = PATTERN (tem);
  if ((! optimize_size && ! TARGET_PUSH_MEMORY))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_841 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L7621;

 L6368: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 0
      && (! optimize_size
   && ! TARGET_USE_MOV0
   && TARGET_SPLIT_LONG_MOVES
   && get_attr_length (insn) >= ix86_cost->large_insn
   && peep2_regno_dead_p (0, FLAGS_REG)))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_844 (insn, operands);
      if (tem != 0)
        return tem;
    }
 L6381: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x1, HImode))
    {
      operands[1] = x1;
      goto L6382;
    }
  x1 = XEXP (x0, 0);
  goto L6187;

 L6382: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6187;
  x1 = PATTERN (tem);
  if ((! optimize_size && get_attr_length (insn) >= ix86_cost->large_insn
  && TARGET_SPLIT_LONG_MOVES))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_847 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6187;

 L7619: ATTRIBUTE_UNUSED_LABEL
  if (push_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L6359;
    }
 L7622: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L6372;
    }
  goto L6187;

 L6359: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (memory_operand (x1, QImode))
    {
      operands[1] = x1;
      goto L6360;
    }
  x1 = XEXP (x0, 0);
  goto L7622;

 L6360: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L7622;
  x1 = PATTERN (tem);
  if ((! optimize_size && ! TARGET_PUSH_MEMORY))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_842 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L7622;

 L6372: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 0
      && (! optimize_size
   && ! TARGET_USE_MOV0
   && TARGET_SPLIT_LONG_MOVES
   && get_attr_length (insn) >= ix86_cost->large_insn
   && peep2_regno_dead_p (0, FLAGS_REG)))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_845 (insn, operands);
      if (tem != 0)
        return tem;
    }
 L6386: ATTRIBUTE_UNUSED_LABEL
  if (immediate_operand (x1, QImode))
    {
      operands[1] = x1;
      goto L6387;
    }
  x1 = XEXP (x0, 0);
  goto L6187;

 L6387: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6187;
  x1 = PATTERN (tem);
  if ((! optimize_size && get_attr_length (insn) >= ix86_cost->large_insn
  && TARGET_SPLIT_LONG_MOVES))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_848 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6187;

 L6188: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  operands[0] = x1;
  goto L6189;
 L6391: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x1) == COMPARE)
    goto L6392;
  x1 = XEXP (x0, 0);
  goto L6396;

 L6189: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  if (tem == NULL_RTX)
    goto L6391;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6190;
  x1 = XEXP (x0, 1);
  goto L6391;

 L6190: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L6191;
    }
  x1 = XEXP (x0, 1);
  goto L6391;

 L6191: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (ix86_comparison_operator (x2, QImode))
    {
      operands[2] = x2;
      goto L6192;
    }
  x1 = XEXP (x0, 1);
  goto L6391;

 L6192: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L6193;
  x1 = XEXP (x0, 1);
  goto L6391;

 L6193: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6194;
  x1 = XEXP (x0, 1);
  goto L6391;

 L6194: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  if (tem == NULL_RTX)
    goto L6391;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6195;
  x1 = XEXP (x0, 1);
  goto L6391;

 L6195: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (q_regs_operand (x2, VOIDmode))
    {
      operands[3] = x2;
      goto L6196;
    }
  x1 = XEXP (x0, 1);
  goto L6391;

 L6196: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == ZERO_EXTEND)
    goto L6197;
  x1 = XEXP (x0, 1);
  goto L6391;

 L6197: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (peep2_reg_dead_p (3, operands[1])
   && ! reg_overlap_mentioned_p (operands[3], operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_797 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 1);
  goto L6391;

 L6392: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  switch (GET_MODE (x2))
    {
    case SImode:
      goto L7628;
    case QImode:
      goto L7629;
    case HImode:
      goto L7631;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L7628: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == AND)
    goto L6417;
  if (memory_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L6393;
    }
 L7630: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L6612;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6417: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode)
    goto L7634;
  x1 = XEXP (x0, 0);
  goto L6396;

 L7634: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x3) == ZERO_EXTRACT)
    goto L6434;
  if (register_operand (x3, SImode))
    {
      operands[0] = x3;
      goto L6418;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6434: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (ext_register_operand (x4, VOIDmode))
    {
      operands[0] = x4;
      goto L6435;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6435: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L6436;
  x1 = XEXP (x0, 0);
  goto L6396;

 L6436: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 2);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 8)
    goto L6437;
  x1 = XEXP (x0, 0);
  goto L6396;

 L6437: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (const_int_operand (x3, VOIDmode))
    {
      operands[1] = x3;
      goto L6438;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6438: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (! TARGET_PARTIAL_REG_STALL
   && ix86_match_ccmode (insn, CCNOmode)
   && true_regnum (operands[0]) != 0
   && find_regno_note (insn, REG_DEAD, true_regnum (operands[0]))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_855 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6418: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (immediate_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L6419;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6419: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode)
   && (true_regnum (operands[0]) != 0
       || CONST_OK_FOR_LETTER_P (INTVAL (operands[1]), 'K'))
   && find_regno_note (insn, REG_DEAD, true_regnum (operands[0]))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_853 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6393: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (ix86_match_ccmode (insn, CCNOmode) && ! optimize_size))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_849 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x2 = XEXP (x1, 0);
  goto L7630;

 L6612: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT)
    goto L7635;
  x1 = XEXP (x0, 0);
  goto L6396;

 L7635: ATTRIBUTE_UNUSED_LABEL
  if (incdec_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L6613;
    }
 L7636: ATTRIBUTE_UNUSED_LABEL
  if (XWINT (x2, 0) == 128
      && (ix86_match_ccmode (insn, CCGCmode)
   && find_regno_note (insn, REG_DEAD, true_regnum (operands[0]))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_878 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6613: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L7636;
  x1 = PATTERN (tem);
  if ((ix86_match_ccmode (insn, CCGCmode)
   && find_regno_note (insn, REG_DEAD, true_regnum (operands[0]))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_875 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L7636;

 L7629: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == AND)
    goto L6425;
  if (register_operand (x2, QImode))
    {
      operands[0] = x2;
      goto L6626;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6425: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (register_operand (x3, QImode))
    {
      operands[0] = x3;
      goto L6426;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6426: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (immediate_operand (x3, QImode))
    {
      operands[1] = x3;
      goto L6427;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6427: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT
      && XWINT (x2, 0) == 0
      && (! TARGET_PARTIAL_REG_STALL
   && ix86_match_ccmode (insn, CCNOmode)
   && true_regnum (operands[0]) != 0
   && find_regno_note (insn, REG_DEAD, true_regnum (operands[0]))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_854 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6626: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (incdec_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L6627;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6627: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6396;
  x1 = PATTERN (tem);
  if ((ix86_match_ccmode (insn, CCGCmode)
   && find_regno_note (insn, REG_DEAD, true_regnum (operands[0]))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_877 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L7631: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, HImode))
    {
      operands[0] = x2;
      goto L6619;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6619: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == CONST_INT)
    goto L7637;
  x1 = XEXP (x0, 0);
  goto L6396;

 L7637: ATTRIBUTE_UNUSED_LABEL
  if (incdec_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L6620;
    }
 L7638: ATTRIBUTE_UNUSED_LABEL
  if (XWINT (x2, 0) == 128
      && (ix86_match_ccmode (insn, CCGCmode)
   && find_regno_note (insn, REG_DEAD, true_regnum (operands[0]))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_879 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6396;

 L6620: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L7638;
  x1 = PATTERN (tem);
  if ((ix86_match_ccmode (insn, CCGCmode)
   && find_regno_note (insn, REG_DEAD, true_regnum (operands[0]))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_876 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 1);
  x2 = XEXP (x1, 1);
  goto L7638;

 L7623: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L6397;
    }
 L7626: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x1, SImode))
    {
      operands[0] = x1;
      goto L6491;
    }
  goto L6481;

 L6397: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode
      && GET_CODE (x1) == NOT)
    goto L6398;
  x1 = XEXP (x0, 0);
  goto L7626;

 L6398: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L6399;
    }
  x1 = XEXP (x0, 0);
  goto L7626;

 L6399: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L7626;
  x1 = PATTERN (tem);
  if ((!optimize_size
   && peep2_regno_dead_p (0, FLAGS_REG)
   && ((TARGET_PENTIUM 
        && (GET_CODE (operands[0]) != MEM
            || !memory_displacement_operand (operands[0], SImode)))
       || (TARGET_K6 && long_memory_operand (operands[0], SImode)))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_850 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L7626;

 L6491: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == SImode)
    goto L7639;
  x1 = XEXP (x0, 0);
  goto L6481;

 L7639: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x1))
    {
    case PLUS:
      goto L6492;
    case MULT:
      goto L6499;
    default:
     break;
   }
  x1 = XEXP (x0, 0);
  goto L6481;

 L6492: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L6493;
  x1 = XEXP (x0, 0);
  goto L6481;

 L6493: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (nonmemory_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L6494;
    }
  x1 = XEXP (x0, 0);
  goto L6481;

 L6494: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6481;
  x1 = PATTERN (tem);
  if ((peep2_regno_dead_p (0, FLAGS_REG)))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_863 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6481;

 L6499: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (rtx_equal_p (x2, operands[0]))
    goto L6500;
  x1 = XEXP (x0, 0);
  goto L6481;

 L6500: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (immediate_operand (x2, SImode))
    {
      operands[1] = x2;
      goto L6501;
    }
  x1 = XEXP (x0, 0);
  goto L6481;

 L6501: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6481;
  x1 = PATTERN (tem);
  if ((exact_log2 (INTVAL (operands[1])) >= 0
   && peep2_regno_dead_p (0, FLAGS_REG)))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_864 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6481;

 L7624: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, HImode))
    {
      operands[0] = x1;
      goto L6403;
    }
  goto L6481;

 L6403: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == HImode
      && GET_CODE (x1) == NOT)
    goto L6404;
  x1 = XEXP (x0, 0);
  goto L6481;

 L6404: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, HImode))
    {
      operands[1] = x2;
      goto L6405;
    }
  x1 = XEXP (x0, 0);
  goto L6481;

 L6405: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6481;
  x1 = PATTERN (tem);
  if ((!optimize_size
   && peep2_regno_dead_p (0, FLAGS_REG)
   && ((TARGET_PENTIUM 
        && (GET_CODE (operands[0]) != MEM
            || !memory_displacement_operand (operands[0], HImode)))
       || (TARGET_K6 && long_memory_operand (operands[0], HImode)))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_851 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6481;

 L7625: ATTRIBUTE_UNUSED_LABEL
  if (nonimmediate_operand (x1, QImode))
    {
      operands[0] = x1;
      goto L6409;
    }
  goto L6481;

 L6409: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_MODE (x1) == QImode
      && GET_CODE (x1) == NOT)
    goto L6410;
  x1 = XEXP (x0, 0);
  goto L6481;

 L6410: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (nonimmediate_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L6411;
    }
  x1 = XEXP (x0, 0);
  goto L6481;

 L6411: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (0);
  if (tem == NULL_RTX)
    goto L6481;
  x1 = PATTERN (tem);
  if ((!optimize_size
   && peep2_regno_dead_p (0, FLAGS_REG)
   && ((TARGET_PENTIUM 
        && (GET_CODE (operands[0]) != MEM
            || !memory_displacement_operand (operands[0], QImode)))
       || (TARGET_K6 && long_memory_operand (operands[0], QImode)))))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_852 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6481;

 L6482: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L6483;
    }
  goto ret0;

 L6483: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CONST_INT
      && XWINT (x1, 0) == 0
      && ((GET_MODE (operands[0]) == QImode
    || GET_MODE (operands[0]) == HImode)
   && (! TARGET_USE_MOV0 || optimize_size)
   && peep2_regno_dead_p (0, FLAGS_REG)))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_861 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;

 L6478: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  if (GET_CODE (x1) == CONST_INT)
    goto L7641;
  x1 = XEXP (x0, 0);
  goto L6642;

 L7641: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x1, 0))
    {
    case 0:
      goto L7643;
    case -1:
      goto L7644;
    default:
      break;
    }
  x1 = XEXP (x0, 0);
  goto L6642;

 L7643: ATTRIBUTE_UNUSED_LABEL
  if (((GET_MODE (operands[0]) == QImode
    || GET_MODE (operands[0]) == HImode
    || GET_MODE (operands[0]) == SImode)
   && (! TARGET_USE_MOV0 || optimize_size)
   && peep2_regno_dead_p (0, FLAGS_REG)))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_860 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6642;

 L7644: ATTRIBUTE_UNUSED_LABEL
  if (((GET_MODE (operands[0]) == HImode
    || GET_MODE (operands[0]) == SImode)
   && (optimize_size || TARGET_PENTIUM)
   && peep2_regno_dead_p (0, FLAGS_REG)))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_862 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XEXP (x0, 0);
  goto L6642;

 L6643: ATTRIBUTE_UNUSED_LABEL
  x1 = XEXP (x0, 1);
  operands[0] = x1;
  goto L6644;

 L6644: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  if (tem == NULL_RTX)
    goto ret0;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6645;
  goto ret0;

 L6645: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[1] = x2;
      goto L6646;
    }
  goto ret0;

 L6646: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (ix86_comparison_operator (x2, QImode))
    {
      operands[2] = x2;
      goto L6647;
    }
  goto ret0;

 L6647: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L6648;
  goto ret0;

 L6648: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6649;
  goto ret0;

 L6649: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  if (tem == NULL_RTX)
    goto ret0;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6650;
  goto ret0;

 L6650: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (q_regs_operand (x2, VOIDmode))
    {
      operands[3] = x2;
      goto L6651;
    }
  goto ret0;

 L6651: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == ZERO_EXTEND)
    goto L6652;
  goto ret0;

 L6652: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[1])
      && (peep2_reg_dead_p (3, operands[1])
   && ! reg_overlap_mentioned_p (operands[3], operands[0])))
    {
      *_pmatch_len = 2;
      tem = gen_peephole2_880 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;
 ret0:
  return 0;
}

static rtx peephole2_2 PARAMS ((rtx, rtx, int *));
static rtx
peephole2_2 (x0, insn, _pmatch_len)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *_pmatch_len ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;

  switch (XVECLEN (x0, 0))
    {
    case 7:
      goto L6217;
    case 2:
      goto L6441;
    case 3:
      goto L6504;
    default:
      break;
    }
  goto ret0;

 L6217: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L6218;
  goto ret0;

 L6218: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6219;
  goto ret0;

 L6219: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == CCmode)
    goto L7645;
  goto ret0;

 L7645: ATTRIBUTE_UNUSED_LABEL
  switch (GET_CODE (x2))
    {
    case COMPARE:
      goto L6220;
    case IF_THEN_ELSE:
      goto L6256;
    default:
     break;
   }
  goto ret0;

 L6220: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == BLKmode
      && GET_CODE (x3) == MEM)
    goto L6221;
  goto ret0;

 L6221: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[4] = x4;
      goto L6222;
    }
  goto ret0;

 L6222: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == BLKmode
      && GET_CODE (x3) == MEM)
    goto L6223;
  goto ret0;

 L6223: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[5] = x4;
      goto L6224;
    }
  goto ret0;

 L6224: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == USE)
    goto L6225;
  goto ret0;

 L6225: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[6] = x2;
      goto L6226;
    }
  goto ret0;

 L6226: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L6227;
  goto ret0;

 L6227: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (immediate_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L6228;
    }
  goto ret0;

 L6228: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L6229;
  goto ret0;

 L6229: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    goto L6230;
  goto ret0;

 L6230: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == CLOBBER)
    goto L6231;
  goto ret0;

 L6231: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L6232;
    }
  goto ret0;

 L6232: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == CLOBBER)
    goto L6233;
  goto ret0;

 L6233: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L6234;
    }
  goto ret0;

 L6234: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 6);
  if (GET_CODE (x1) == CLOBBER)
    goto L6235;
  goto ret0;

 L6235: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[2] = x2;
      goto L6236;
    }
  goto ret0;

 L6236: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  if (tem == NULL_RTX)
    goto ret0;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6237;
  goto ret0;

 L6237: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[7] = x2;
      goto L6238;
    }
  goto ret0;

 L6238: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == GTU)
    goto L6239;
  goto ret0;

 L6239: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == CCmode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L6240;
  goto ret0;

 L6240: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6241;
  goto ret0;

 L6241: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  if (tem == NULL_RTX)
    goto ret0;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6242;
  goto ret0;

 L6242: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[8] = x2;
      goto L6243;
    }
  goto ret0;

 L6243: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == LTU)
    goto L6244;
  goto ret0;

 L6244: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == CCmode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L6245;
  goto ret0;

 L6245: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6246;
  goto ret0;

 L6246: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (3);
  if (tem == NULL_RTX)
    goto ret0;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6247;
  goto ret0;

 L6247: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6248;
  goto ret0;

 L6248: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == COMPARE)
    goto L6249;
  goto ret0;

 L6249: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[7]))
    goto L6250;
  goto ret0;

 L6250: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[8])
      && (peep2_reg_dead_p (4, operands[7]) && peep2_reg_dead_p (4, operands[8])))
    {
      *_pmatch_len = 3;
      tem = gen_peephole2_823 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;

 L6256: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == NE)
    goto L6257;
  goto ret0;

 L6257: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (register_operand (x4, VOIDmode))
    {
      operands[6] = x4;
      goto L6258;
    }
  goto ret0;

 L6258: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_CODE (x4) == CONST_INT
      && XWINT (x4, 0) == 0)
    goto L6259;
  goto ret0;

 L6259: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_MODE (x3) == CCmode
      && GET_CODE (x3) == COMPARE)
    goto L6260;
  goto ret0;

 L6260: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 0);
  if (GET_MODE (x4) == BLKmode
      && GET_CODE (x4) == MEM)
    goto L6261;
  goto ret0;

 L6261: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, VOIDmode))
    {
      operands[4] = x5;
      goto L6262;
    }
  goto ret0;

 L6262: ATTRIBUTE_UNUSED_LABEL
  x4 = XEXP (x3, 1);
  if (GET_MODE (x4) == BLKmode
      && GET_CODE (x4) == MEM)
    goto L6263;
  goto ret0;

 L6263: ATTRIBUTE_UNUSED_LABEL
  x5 = XEXP (x4, 0);
  if (register_operand (x5, VOIDmode))
    {
      operands[5] = x5;
      goto L6264;
    }
  goto ret0;

 L6264: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 2);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6265;
  goto ret0;

 L6265: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == USE)
    goto L6266;
  goto ret0;

 L6266: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (immediate_operand (x2, SImode))
    {
      operands[3] = x2;
      goto L6267;
    }
  goto ret0;

 L6267: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == USE)
    goto L6268;
  goto ret0;

 L6268: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6269;
  goto ret0;

 L6269: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 3);
  if (GET_CODE (x1) == USE)
    goto L6270;
  goto ret0;

 L6270: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 19)
    goto L6271;
  goto ret0;

 L6271: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 4);
  if (GET_CODE (x1) == CLOBBER)
    goto L6272;
  goto ret0;

 L6272: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[0] = x2;
      goto L6273;
    }
  goto ret0;

 L6273: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 5);
  if (GET_CODE (x1) == CLOBBER)
    goto L6274;
  goto ret0;

 L6274: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[1] = x2;
      goto L6275;
    }
  goto ret0;

 L6275: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 6);
  if (GET_CODE (x1) == CLOBBER)
    goto L6276;
  goto ret0;

 L6276: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, VOIDmode))
    {
      operands[2] = x2;
      goto L6277;
    }
  goto ret0;

 L6277: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (1);
  if (tem == NULL_RTX)
    goto ret0;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6278;
  goto ret0;

 L6278: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[7] = x2;
      goto L6279;
    }
  goto ret0;

 L6279: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == GTU)
    goto L6280;
  goto ret0;

 L6280: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == CCmode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L6281;
  goto ret0;

 L6281: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6282;
  goto ret0;

 L6282: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (2);
  if (tem == NULL_RTX)
    goto ret0;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6283;
  goto ret0;

 L6283: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (register_operand (x2, QImode))
    {
      operands[8] = x2;
      goto L6284;
    }
  goto ret0;

 L6284: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == QImode
      && GET_CODE (x2) == LTU)
    goto L6285;
  goto ret0;

 L6285: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == CCmode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 17)
    goto L6286;
  goto ret0;

 L6286: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT
      && XWINT (x3, 0) == 0)
    goto L6287;
  goto ret0;

 L6287: ATTRIBUTE_UNUSED_LABEL
  tem = peep2_next_insn (3);
  if (tem == NULL_RTX)
    goto ret0;
  x1 = PATTERN (tem);
  if (GET_CODE (x1) == SET)
    goto L6288;
  goto ret0;

 L6288: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6289;
  goto ret0;

 L6289: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_CODE (x2) == COMPARE)
    goto L6290;
  goto ret0;

 L6290: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[7]))
    goto L6291;
  goto ret0;

 L6291: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[8])
      && (peep2_reg_dead_p (4, operands[7]) && peep2_reg_dead_p (4, operands[8])))
    {
      *_pmatch_len = 3;
      tem = gen_peephole2_824 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;

 L6441: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L6442;
  goto ret0;

 L6442: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode)
    goto L7649;
  goto ret0;

 L7649: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L6530;
 L7647: ATTRIBUTE_UNUSED_LABEL
  if (register_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L6443;
    }
 L7648: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x2, SImode))
    {
      operands[0] = x2;
      goto L6461;
    }
  goto ret0;

 L6530: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L6531;
  x2 = XEXP (x1, 0);
  goto L7647;

 L6531: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L6532;
  x2 = XEXP (x1, 0);
  goto L7647;

 L6532: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT)
    goto L7650;
  x2 = XEXP (x1, 0);
  goto L7647;

 L7650: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x3, 0))
    {
    case -4:
      goto L6533;
    case -8:
      goto L6542;
    case 4:
      goto L6587;
    case 8:
      goto L6596;
    default:
      break;
    }
  x2 = XEXP (x1, 0);
  goto L7647;

 L6533: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6534;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L6534: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (optimize_size || !TARGET_SUB_ESP_4))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_867 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L6542: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6543;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L6543: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (optimize_size || !TARGET_SUB_ESP_8))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_868 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L6587: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6588;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L6588: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_872 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L6596: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6597;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L6597: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode)
    goto L7654;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L7654: ATTRIBUTE_UNUSED_LABEL
  if (GET_CODE (x2) == REG)
    goto L7656;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L7656: ATTRIBUTE_UNUSED_LABEL
  if (XINT (x2, 0) == 17)
    goto L7658;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L7658: ATTRIBUTE_UNUSED_LABEL
  *_pmatch_len = 0;
  tem = gen_peephole2_873 (insn, operands);
  if (tem != 0)
    return tem;
 L7659: ATTRIBUTE_UNUSED_LABEL
  if ((optimize_size))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_874 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7647;

 L6443: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (arith_or_logical_operator (x2, SImode))
    {
      operands[3] = x2;
      goto L6444;
    }
  x2 = XEXP (x1, 0);
  goto L7648;

 L6444: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L6445;
 L6453: ATTRIBUTE_UNUSED_LABEL
  if (memory_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L6454;
    }
  x2 = XEXP (x1, 0);
  goto L7648;

 L6445: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (memory_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L6446;
    }
  x3 = XEXP (x2, 0);
  goto L6453;

 L6446: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6447;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6453;

 L6447: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (! optimize_size && ! TARGET_READ_MODIFY))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_856 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6453;

 L6454: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[0]))
    goto L6455;
  x2 = XEXP (x1, 0);
  goto L7648;

 L6455: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6456;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7648;

 L6456: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (! optimize_size && ! TARGET_READ_MODIFY))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_857 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 0);
  goto L7648;

 L6461: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (arith_or_logical_operator (x2, SImode))
    {
      operands[3] = x2;
      goto L6462;
    }
  goto ret0;

 L6462: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (rtx_equal_p (x3, operands[0]))
    goto L6463;
 L6471: ATTRIBUTE_UNUSED_LABEL
  if (nonmemory_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L6472;
    }
  goto ret0;

 L6463: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (nonmemory_operand (x3, SImode))
    {
      operands[1] = x3;
      goto L6464;
    }
  x3 = XEXP (x2, 0);
  goto L6471;

 L6464: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6465;
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6471;

 L6465: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (! optimize_size && ! TARGET_READ_MODIFY_WRITE))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_858 (insn, operands);
      if (tem != 0)
        return tem;
    }
  x1 = XVECEXP (x0, 0, 0);
  x2 = XEXP (x1, 1);
  x3 = XEXP (x2, 0);
  goto L6471;

 L6472: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (rtx_equal_p (x3, operands[0]))
    goto L6473;
  goto ret0;

 L6473: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6474;
  goto ret0;

 L6474: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17
      && (! optimize_size && ! TARGET_READ_MODIFY_WRITE))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_859 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;

 L6504: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 0);
  if (GET_CODE (x1) == SET)
    goto L6505;
  goto ret0;

 L6505: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 7)
    goto L6506;
  goto ret0;

 L6506: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 1);
  if (GET_MODE (x2) == SImode
      && GET_CODE (x2) == PLUS)
    goto L6507;
  goto ret0;

 L6507: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_MODE (x3) == SImode
      && GET_CODE (x3) == REG
      && XINT (x3, 0) == 7)
    goto L6508;
  goto ret0;

 L6508: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 1);
  if (GET_CODE (x3) == CONST_INT)
    goto L7660;
  goto ret0;

 L7660: ATTRIBUTE_UNUSED_LABEL
  switch ((int) XWINT (x3, 0))
    {
    case -4:
      goto L6509;
    case -8:
      goto L6521;
    case 4:
      goto L6551;
    case 8:
      goto L6563;
    default:
      break;
    }
  goto ret0;

 L6509: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6510;
  goto ret0;

 L6510: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6511;
  goto ret0;

 L6511: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6512;
  goto ret0;

 L6512: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L6513;
  goto ret0;

 L6513: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == SCRATCH
      && (optimize_size || !TARGET_SUB_ESP_4))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_865 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;

 L6521: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6522;
  goto ret0;

 L6522: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6523;
  goto ret0;

 L6523: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6524;
  goto ret0;

 L6524: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L6525;
  goto ret0;

 L6525: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == SCRATCH
      && (optimize_size || !TARGET_SUB_ESP_8))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_866 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;

 L6551: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6552;
  goto ret0;

 L6552: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6553;
  goto ret0;

 L6553: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6554;
  goto ret0;

 L6554: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L6555;
  goto ret0;

 L6555: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == SCRATCH
      && (optimize_size || !TARGET_ADD_ESP_4))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_869 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;

 L6563: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 1);
  if (GET_CODE (x1) == CLOBBER)
    goto L6564;
  goto ret0;

 L6564: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == CCmode
      && GET_CODE (x2) == REG
      && XINT (x2, 0) == 17)
    goto L6565;
  goto ret0;

 L6565: ATTRIBUTE_UNUSED_LABEL
  x1 = XVECEXP (x0, 0, 2);
  if (GET_CODE (x1) == CLOBBER)
    goto L6566;
  goto ret0;

 L6566: ATTRIBUTE_UNUSED_LABEL
  x2 = XEXP (x1, 0);
  if (GET_MODE (x2) == BLKmode
      && GET_CODE (x2) == MEM)
    goto L6567;
  goto ret0;

 L6567: ATTRIBUTE_UNUSED_LABEL
  x3 = XEXP (x2, 0);
  if (GET_CODE (x3) == SCRATCH)
    goto L7664;
  goto ret0;

 L7664: ATTRIBUTE_UNUSED_LABEL
  if ((optimize_size || !TARGET_ADD_ESP_8))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_870 (insn, operands);
      if (tem != 0)
        return tem;
    }
 L7665: ATTRIBUTE_UNUSED_LABEL
  if ((optimize_size))
    {
      *_pmatch_len = 0;
      tem = gen_peephole2_871 (insn, operands);
      if (tem != 0)
        return tem;
    }
  goto ret0;
 ret0:
  return 0;
}

rtx peephole2_insns PARAMS ((rtx, rtx, int *));
rtx
peephole2_insns (x0, insn, _pmatch_len)
     register rtx x0;
     rtx insn ATTRIBUTE_UNUSED;
     int *_pmatch_len ATTRIBUTE_UNUSED;
{
  register rtx * const operands ATTRIBUTE_UNUSED = &recog_data.operand[0];
  register rtx x1 ATTRIBUTE_UNUSED;
  register rtx x2 ATTRIBUTE_UNUSED;
  register rtx x3 ATTRIBUTE_UNUSED;
  register rtx x4 ATTRIBUTE_UNUSED;
  register rtx x5 ATTRIBUTE_UNUSED;
  register rtx x6 ATTRIBUTE_UNUSED;
  rtx tem ATTRIBUTE_UNUSED;
  recog_data.insn = NULL_RTX;

  switch (GET_CODE (x0))
    {
    case SET:
      goto L6343;
    case PARALLEL:
      goto L7613;
    default:
     break;
   }
  goto ret0;

 L6343: ATTRIBUTE_UNUSED_LABEL
  return peephole2_1 (x0, insn, _pmatch_len);

 L7613: ATTRIBUTE_UNUSED_LABEL
  return peephole2_2 (x0, insn, _pmatch_len);
 ret0:
  return 0;
}

