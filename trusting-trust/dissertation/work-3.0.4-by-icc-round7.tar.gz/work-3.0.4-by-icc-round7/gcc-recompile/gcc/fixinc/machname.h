#define MN_NAME_PAT "\\<i386\\>|\\<linux\\>|\\<unix\\>"
