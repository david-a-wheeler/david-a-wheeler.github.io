
#include <stdio.h>

main()
{
 int i;
 for (i=1; i < 256; i++)
   putchar(i);
}
