
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { heap_size  = 512*1024 };
enum { stack_size =  64*1024 };

static void die (const char *message) {
  fprintf (stderr, "%s\n", message);
  exit (1);
}

typedef int obj;

#define tag(o)        ( (o) & 0x7 )
#define bits(o)       ( (o) >> 3 )

#define entag(t, ptr) ( (t) | ((ptr) << 3) )
#define mkptr(t, ptr) ( check_ptr (ptr), entag ((t), (ptr)) )
#define mkchar(n)     ( (obj) (a_char | ((n) << 3)) )
#define boolean(f)    ( (f) ? true : false )

enum { nil, eof, a_boolean, a_char, a_symbol, a_string, a_pair };
enum { false = entag (a_boolean, 0) };
enum { true  = entag (a_boolean, 1) };

#define check_ptr(p)  ( assert (0 <= (p) && (p) < heap_size) )

static obj heap[2 * heap_size];
static char marks[heap_size];
static int hp = heap_size;	/* heap pointer */

static obj stack[stack_size];
static int sp = 0;		/* stack pointer */

static void mark (obj x) {
  while (a_symbol == tag (x) || a_string == tag (x) || a_pair == tag (x)) {
    int i = bits (x);
    check_ptr (i);
    if (marks[i]) break;
    marks[i] = 1;
    mark (heap[2*i + 0]);
    x =   heap[2*i + 1];
  }
}

static int find_unmarked_slot (void) {
  while (0 <= --hp) {
    if (!marks[hp]) return 1;
    marks[hp] = 0;
  }
  return 0;
}

static void collect_garbage (void) {
  int i;
  for (i = 0; i < sp; ++i)
    mark (stack[i]);
  hp = heap_size;
  if (!find_unmarked_slot ())
    die ("Heap exhausted");
}

static void push (obj x) {
  if (stack_size <= sp)
    die ("Stack exhausted");
  stack[sp++] = x;
}

static obj pop (void) {
  assert (0 < sp);
  return stack[--sp]; 
}

#define TOP                   ( stack[sp-1] )

#define typecheck(type, x)    ( assert ((type) == tag (x)) )

#define DEF_PRIM(name)        static void name (void)

DEF_PRIM(prim0_abort)         { die ("Aborted"); }

DEF_PRIM(prim1_nullP)         { TOP = boolean (TOP == nil); }
DEF_PRIM(prim1_pairP)         { TOP = boolean (tag (TOP) == a_pair); }
DEF_PRIM(prim1_symbolP)       { TOP = boolean (tag (TOP) == a_symbol); }
DEF_PRIM(prim1_stringP)       { TOP = boolean (tag (TOP) == a_string); }
DEF_PRIM(prim1_booleanP)      { TOP = boolean (tag (TOP) == a_boolean); }
DEF_PRIM(prim1_charP)         { TOP = boolean (tag (TOP) == a_char); }
DEF_PRIM(prim1_eof_objectP)   { TOP = boolean (TOP == eof); }

DEF_PRIM(prim1_car) { 
  typecheck (a_pair, TOP); check_ptr (bits (TOP));
  TOP = heap[2 * bits (TOP) + 0]; 
}
DEF_PRIM(prim1_cdr) { 
  typecheck (a_pair, TOP); check_ptr (bits (TOP));
  TOP = heap[2 * bits (TOP) + 1]; 
}

DEF_PRIM(prim2_cons) {
  if (!find_unmarked_slot ())
    collect_garbage ();
  heap[2*hp + 1] = pop();
  heap[2*hp + 0] = TOP;
  TOP = mkptr (a_pair, hp);
}

DEF_PRIM(prim1_write_char) { 
  typecheck (a_char, TOP);
  putc (bits (TOP), stdout);
  fflush (stdout);
}

DEF_PRIM(prim0_read_char) {
  int c = getc (stdin);
  push (EOF == c ? eof : mkchar (c));
}

DEF_PRIM(prim0_peek_char) {
  int c = getc (stdin);
  ungetc (c, stdin);
  push (EOF == c ? eof : mkchar (c));
}

DEF_PRIM(prim2_EEP) {
  obj y = pop ();
  TOP = boolean (TOP == y);
}

#define DEF_CVT(name, from_tag, to_tag) \
  DEF_PRIM(name) {                      \
    typecheck (from_tag, TOP);          \
    TOP = mkptr (to_tag, bits (TOP));   \
  }

DEF_CVT(prim1_explode, a_symbol, a_pair)
DEF_CVT(prim1_implode, a_pair, a_symbol)
DEF_CVT(prim1_string_Glist, a_string, a_pair)
DEF_CVT(prim1_list_Gstring, a_pair, a_string)

#define push_local(i)         ( push (stack[bp + (i)]) )

#define call(label, arity)    ( run ((label), sp - (arity)) )

#define tailcall(label, arity) do {        \
    memmove (stack + bp, stack + sp - (arity), (arity) * sizeof stack[0]); \
    sp = bp + (arity);                     \
    pc = (label);                          \
    goto again;                            \
  } while (0)

#define answer()      do { \
    stack[bp] = TOP;       \
    sp = bp + 1;           \
    return;                \
  } while (0)
enum { proc_list1, proc_list2, proc_list3, proc_caar, proc_cdar, proc_cadr, proc_cddr, proc_caadr, proc_cdadr, proc_sameP, proc_each_EEP, proc_same_lengthP, proc_lengthE1P, proc_memq, proc_whitespaceP, proc_punctuationP, proc_error, proc_write, proc_write_each_char, proc_write_tail, proc_write_char_literal, proc_read, proc_eofP, proc_read_1, proc_read_tail, proc_read_tail_1, proc_read_hash, proc_read_char_literal, proc_read_char_literal_1, proc_read_char_literal_2, proc_read_symbol, proc_read_symbol_1, proc_read_string_literal, proc_main, proc_repl, proc_defineP, proc_eval_expr, proc_apply_proc, proc_eval_exprs, proc_eval_seq, proc_eval_cond, proc_bind, proc_value, proc_value1, proc_lookup, proc_lookup1, proc_apply_prim, };

static void run (int pc, int bp) {
  again: switch (pc) {

case proc_list1:
{
enum { arg_z, };
assert(sp-bp==1);
push_local(arg_z);
push(nil);
prim2_cons();
answer();
}

case proc_list2:
{
enum { arg_y, arg_z, };
assert(sp-bp==2);
push_local(arg_y);
push_local(arg_z);
push(nil);
prim2_cons();
prim2_cons();
answer();
}

case proc_list3:
{
enum { arg_x, arg_y, arg_z, };
assert(sp-bp==3);
push_local(arg_x);
push_local(arg_y);
push_local(arg_z);
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
answer();
}

case proc_caar:
{
enum { arg_x, };
assert(sp-bp==1);
push_local(arg_x);
prim1_car();
prim1_car();
answer();
}

case proc_cdar:
{
enum { arg_x, };
assert(sp-bp==1);
push_local(arg_x);
prim1_car();
prim1_cdr();
answer();
}

case proc_cadr:
{
enum { arg_x, };
assert(sp-bp==1);
push_local(arg_x);
prim1_cdr();
prim1_car();
answer();
}

case proc_cddr:
{
enum { arg_x, };
assert(sp-bp==1);
push_local(arg_x);
prim1_cdr();
prim1_cdr();
answer();
}

case proc_caadr:
{
enum { arg_x, };
assert(sp-bp==1);
push_local(arg_x);
prim1_cdr();
prim1_car();
prim1_car();
answer();
}

case proc_cdadr:
{
enum { arg_x, };
assert(sp-bp==1);
push_local(arg_x);
prim1_cdr();
prim1_car();
prim1_cdr();
answer();
}

case proc_sameP:
{
enum { arg_x, arg_y, };
assert(sp-bp==2);
push_local(arg_x);
push_local(arg_y);
prim2_EEP();
if (false != pop ()) {
push(true);
} else {
push_local(arg_x);
prim1_symbolP();
if (false != pop ()) {
push_local(arg_y);
prim1_symbolP();
if (false != pop ()) {
push_local(arg_x);
prim1_explode();
push_local(arg_y);
prim1_explode();
tailcall(proc_each_EEP,2);
} else {
push(true);
if (false != pop ()) {
push(false);
} else {
prim0_abort();
}
}
} else {
push(true);
if (false != pop ()) {
push(false);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_each_EEP:
{
enum { arg_xs, arg_ys, };
assert(sp-bp==2);
push_local(arg_xs);
prim1_nullP();
if (false != pop ()) {
push_local(arg_ys);
prim1_nullP();
} else {
push_local(arg_ys);
prim1_nullP();
if (false != pop ()) {
push(false);
} else {
push_local(arg_xs);
prim1_car();
push_local(arg_ys);
prim1_car();
prim2_EEP();
if (false != pop ()) {
push_local(arg_xs);
prim1_cdr();
push_local(arg_ys);
prim1_cdr();
tailcall(proc_each_EEP,2);
} else {
push(true);
if (false != pop ()) {
push(false);
} else {
prim0_abort();
}
}
}
}
answer();
}

case proc_same_lengthP:
{
enum { arg_xs, arg_ys, };
assert(sp-bp==2);
push_local(arg_xs);
prim1_nullP();
if (false != pop ()) {
push_local(arg_ys);
prim1_nullP();
} else {
push_local(arg_ys);
prim1_nullP();
if (false != pop ()) {
push(false);
} else {
push(true);
if (false != pop ()) {
push_local(arg_xs);
prim1_cdr();
push_local(arg_ys);
prim1_cdr();
tailcall(proc_same_lengthP,2);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_lengthE1P:
{
enum { arg_xs, };
assert(sp-bp==1);
push_local(arg_xs);
push(mkchar('x'));
push(nil);
prim2_cons();
prim1_implode();
push(nil);
prim2_cons();
tailcall(proc_same_lengthP,2);
answer();
}

case proc_memq:
{
enum { arg_x, arg_ls, };
assert(sp-bp==2);
push_local(arg_ls);
prim1_nullP();
if (false != pop ()) {
push(false);
} else {
push_local(arg_x);
push_local(arg_ls);
prim1_car();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_ls);
} else {
push(true);
if (false != pop ()) {
push_local(arg_x);
push_local(arg_ls);
prim1_cdr();
tailcall(proc_memq,2);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_whitespaceP:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
push(mkchar(' '));
push(mkchar('\t'));
push(mkchar('\r'));
push(mkchar('\n'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
tailcall(proc_memq,2);
answer();
}

case proc_punctuationP:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
push(mkchar('#'));
push(mkchar('\''));
push(mkchar('('));
push(mkchar(')'));
push(mkchar('"'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
tailcall(proc_memq,2);
answer();
}

case proc_error:
{
enum { arg_complaint, arg_irritant, };
assert(sp-bp==2);
push(mkchar('e'));
push(mkchar('r'));
push(mkchar('r'));
push(mkchar('o'));
push(mkchar('r'));
push(mkchar(':'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_write,1);
pop();
push(mkchar(' '));
prim1_write_char();
pop();
push_local(arg_complaint);
call(proc_write,1);
pop();
push(mkchar(' '));
prim1_write_char();
pop();
push_local(arg_irritant);
call(proc_write,1);
pop();
push(mkchar('\n'));
prim1_write_char();
pop();
prim0_abort();
answer();
}

case proc_write:
{
enum { arg_x, };
assert(sp-bp==1);
push_local(arg_x);
prim1_nullP();
if (false != pop ()) {
push(mkchar('('));
prim1_write_char();
pop();
push(mkchar(')'));
prim1_write_char();
} else {
push_local(arg_x);
prim1_booleanP();
if (false != pop ()) {
push(mkchar('#'));
prim1_write_char();
pop();
push_local(arg_x);
if (false != pop ()) {
push(mkchar('t'));
} else {
push(true);
if (false != pop ()) {
push(mkchar('f'));
} else {
prim0_abort();
}
}
prim1_write_char();
} else {
push_local(arg_x);
prim1_charP();
if (false != pop ()) {
push(mkchar('#'));
prim1_write_char();
pop();
push(mkchar('\\'));
prim1_write_char();
pop();
push_local(arg_x);
tailcall(proc_write_char_literal,1);
} else {
push_local(arg_x);
prim1_symbolP();
if (false != pop ()) {
push_local(arg_x);
prim1_explode();
tailcall(proc_write_each_char,1);
} else {
push_local(arg_x);
prim1_stringP();
if (false != pop ()) {
push(mkchar('"'));
prim1_write_char();
pop();
push_local(arg_x);
prim1_string_Glist();
call(proc_write_each_char,1);
pop();
push(mkchar('"'));
prim1_write_char();
} else {
push_local(arg_x);
prim1_pairP();
if (false != pop ()) {
push(mkchar('('));
prim1_write_char();
pop();
push_local(arg_x);
prim1_car();
call(proc_write,1);
pop();
push_local(arg_x);
prim1_cdr();
call(proc_write_tail,1);
pop();
push(mkchar(')'));
prim1_write_char();
} else {
push_local(arg_x);
prim1_eof_objectP();
if (false != pop ()) {
push(mkchar('#'));
prim1_write_char();
pop();
push(mkchar('<'));
push(mkchar('e'));
push(mkchar('o'));
push(mkchar('f'));
push(mkchar('>'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_write,1);
} else {
push(true);
if (false != pop ()) {
push(mkchar('c'));
push(mkchar('a'));
push(mkchar('n'));
push(mkchar('t'));
push(mkchar('-'));
push(mkchar('w'));
push(mkchar('r'));
push(mkchar('i'));
push(mkchar('t'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push(mkchar('<'));
push(mkchar('s'));
push(mkchar('o'));
push(mkchar('m'));
push(mkchar('e'));
push(mkchar('t'));
push(mkchar('h'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('g'));
push(mkchar('>'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_error,2);
} else {
prim0_abort();
}
}
}
}
}
}
}
}
answer();
}

case proc_write_each_char:
{
enum { arg_chars, };
assert(sp-bp==1);
push_local(arg_chars);
prim1_nullP();
if (false != pop ()) {
push(false);
} else {
push(true);
if (false != pop ()) {
push_local(arg_chars);
prim1_car();
prim1_write_char();
pop();
push_local(arg_chars);
prim1_cdr();
tailcall(proc_write_each_char,1);
} else {
prim0_abort();
}
}
answer();
}

case proc_write_tail:
{
enum { arg_xs, };
assert(sp-bp==1);
push_local(arg_xs);
prim1_nullP();
if (false != pop ()) {
push(false);
} else {
push_local(arg_xs);
prim1_pairP();
if (false != pop ()) {
push(mkchar(' '));
prim1_write_char();
pop();
push_local(arg_xs);
prim1_car();
call(proc_write,1);
pop();
push_local(arg_xs);
prim1_cdr();
tailcall(proc_write_tail,1);
} else {
push(true);
if (false != pop ()) {
push(mkchar(' '));
prim1_write_char();
pop();
push(mkchar('.'));
prim1_write_char();
pop();
push(mkchar(' '));
prim1_write_char();
pop();
push_local(arg_xs);
tailcall(proc_write,1);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_write_char_literal:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
push(mkchar(' '));
prim2_EEP();
if (false != pop ()) {
push(mkchar('s'));
push(mkchar('p'));
push(mkchar('a'));
push(mkchar('c'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_write,1);
} else {
push_local(arg_c);
push(mkchar('\t'));
prim2_EEP();
if (false != pop ()) {
push(mkchar('t'));
push(mkchar('a'));
push(mkchar('b'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_write,1);
} else {
push_local(arg_c);
push(mkchar('\r'));
prim2_EEP();
if (false != pop ()) {
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('t'));
push(mkchar('u'));
push(mkchar('r'));
push(mkchar('n'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_write,1);
} else {
push_local(arg_c);
push(mkchar('\n'));
prim2_EEP();
if (false != pop ()) {
push(mkchar('n'));
push(mkchar('e'));
push(mkchar('w'));
push(mkchar('l'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_write,1);
} else {
push(true);
if (false != pop ()) {
push_local(arg_c);
prim1_write_char();
} else {
prim0_abort();
}
}
}
}
}
answer();
}

case proc_read:
{
assert(sp-bp==0);
prim0_read_char();
tailcall(proc_read_1,1);
answer();
}

case proc_eofP:
{
enum { arg_x, };
assert(sp-bp==1);
push_local(arg_x);
prim1_eof_objectP();
if (false != pop ()) {
push(true);
} else {
push_local(arg_x);
push(mkchar('*'));
push(mkchar('e'));
push(mkchar('o'));
push(mkchar('f'));
push(mkchar('*'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
prim0_read_char();
pop();
push(true);
} else {
push(true);
if (false != pop ()) {
push(false);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_read_1:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
call(proc_eofP,1);
if (false != pop ()) {
push_local(arg_c);
} else {
push_local(arg_c);
call(proc_whitespaceP,1);
if (false != pop ()) {
tailcall(proc_read,0);
} else {
push_local(arg_c);
push(mkchar('#'));
prim2_EEP();
if (false != pop ()) {
prim0_read_char();
tailcall(proc_read_hash,1);
} else {
push_local(arg_c);
push(mkchar('\''));
prim2_EEP();
if (false != pop ()) {
push(mkchar('q'));
push(mkchar('u'));
push(mkchar('o'));
push(mkchar('t'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_read,0);
tailcall(proc_list2,2);
} else {
push_local(arg_c);
push(mkchar('('));
prim2_EEP();
if (false != pop ()) {
prim0_read_char();
tailcall(proc_read_tail,1);
} else {
push_local(arg_c);
push(mkchar(')'));
prim2_EEP();
if (false != pop ()) {
push(mkchar('m'));
push(mkchar('i'));
push(mkchar('s'));
push(mkchar('m'));
push(mkchar('a'));
push(mkchar('t'));
push(mkchar('c'));
push(mkchar('h'));
push(mkchar('e'));
push(mkchar('d'));
push(mkchar('-'));
push(mkchar('p'));
push(mkchar('a'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('n'));
push(mkchar('s'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('a'));
push(mkchar('d'));
push(mkchar('-'));
push(mkchar('1'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_error,2);
} else {
push_local(arg_c);
push(mkchar('"'));
prim2_EEP();
if (false != pop ()) {
prim0_read_char();
call(proc_read_string_literal,1);
prim1_list_Gstring();
} else {
push(true);
if (false != pop ()) {
push_local(arg_c);
call(proc_read_symbol,1);
prim1_implode();
} else {
prim0_abort();
}
}
}
}
}
}
}
}
answer();
}

case proc_read_tail:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
call(proc_eofP,1);
if (false != pop ()) {
push(mkchar('p'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('m'));
push(mkchar('a'));
push(mkchar('t'));
push(mkchar('u'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('-'));
push(mkchar('e'));
push(mkchar('o'));
push(mkchar('f'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('a'));
push(mkchar('d'));
push(mkchar('-'));
push(mkchar('t'));
push(mkchar('a'));
push(mkchar('i'));
push(mkchar('l'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_error,2);
} else {
push_local(arg_c);
call(proc_whitespaceP,1);
if (false != pop ()) {
prim0_read_char();
tailcall(proc_read_tail,1);
} else {
push_local(arg_c);
push(mkchar(')'));
prim2_EEP();
if (false != pop ()) {
push(nil);
} else {
push(true);
if (false != pop ()) {
push_local(arg_c);
call(proc_read_1,1);
tailcall(proc_read_tail_1,1);
} else {
prim0_abort();
}
}
}
}
answer();
}

case proc_read_tail_1:
{
enum { arg_e, };
assert(sp-bp==1);
push_local(arg_e);
prim0_read_char();
call(proc_read_tail,1);
prim2_cons();
answer();
}

case proc_read_hash:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
call(proc_eofP,1);
if (false != pop ()) {
push(mkchar('p'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('m'));
push(mkchar('a'));
push(mkchar('t'));
push(mkchar('u'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('-'));
push(mkchar('e'));
push(mkchar('o'));
push(mkchar('f'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('a'));
push(mkchar('d'));
push(mkchar('-'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('s'));
push(mkchar('h'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_error,2);
} else {
push_local(arg_c);
push(mkchar('f'));
prim2_EEP();
if (false != pop ()) {
push(false);
} else {
push_local(arg_c);
push(mkchar('t'));
prim2_EEP();
if (false != pop ()) {
push(true);
} else {
push_local(arg_c);
push(mkchar('\\'));
prim2_EEP();
if (false != pop ()) {
prim0_read_char();
tailcall(proc_read_char_literal,1);
} else {
push(true);
if (false != pop ()) {
push(mkchar('u'));
push(mkchar('n'));
push(mkchar('k'));
push(mkchar('n'));
push(mkchar('o'));
push(mkchar('w'));
push(mkchar('n'));
push(mkchar('-'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('s'));
push(mkchar('h'));
push(mkchar('-'));
push(mkchar('c'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('r'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push_local(arg_c);
tailcall(proc_error,2);
} else {
prim0_abort();
}
}
}
}
}
answer();
}

case proc_read_char_literal:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
call(proc_eofP,1);
if (false != pop ()) {
push(mkchar('p'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('m'));
push(mkchar('a'));
push(mkchar('t'));
push(mkchar('u'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('-'));
push(mkchar('e'));
push(mkchar('o'));
push(mkchar('f'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('a'));
push(mkchar('d'));
push(mkchar('-'));
push(mkchar('c'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('r'));
push(mkchar('-'));
push(mkchar('l'));
push(mkchar('i'));
push(mkchar('t'));
push(mkchar('e'));
push(mkchar('r'));
push(mkchar('a'));
push(mkchar('l'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_error,2);
} else {
push(true);
if (false != pop ()) {
push_local(arg_c);
call(proc_read_symbol,1);
tailcall(proc_read_char_literal_1,1);
} else {
prim0_abort();
}
}
answer();
}

case proc_read_char_literal_1:
{
enum { arg_cs, };
assert(sp-bp==1);
push_local(arg_cs);
push_local(arg_cs);
prim1_implode();
tailcall(proc_read_char_literal_2,2);
answer();
}

case proc_read_char_literal_2:
{
enum { arg_cs, arg_symbol, };
assert(sp-bp==2);
push_local(arg_symbol);
push(mkchar('s'));
push(mkchar('p'));
push(mkchar('a'));
push(mkchar('c'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push(mkchar(' '));
} else {
push_local(arg_symbol);
push(mkchar('t'));
push(mkchar('a'));
push(mkchar('b'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push(mkchar('\t'));
} else {
push_local(arg_symbol);
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('t'));
push(mkchar('u'));
push(mkchar('r'));
push(mkchar('n'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push(mkchar('\r'));
} else {
push_local(arg_symbol);
push(mkchar('n'));
push(mkchar('e'));
push(mkchar('w'));
push(mkchar('l'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push(mkchar('\n'));
} else {
push_local(arg_cs);
call(proc_lengthE1P,1);
if (false != pop ()) {
push_local(arg_cs);
prim1_car();
} else {
push(true);
if (false != pop ()) {
push(mkchar('u'));
push(mkchar('n'));
push(mkchar('k'));
push(mkchar('n'));
push(mkchar('o'));
push(mkchar('w'));
push(mkchar('n'));
push(mkchar('-'));
push(mkchar('c'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('r'));
push(mkchar('-'));
push(mkchar('c'));
push(mkchar('o'));
push(mkchar('n'));
push(mkchar('s'));
push(mkchar('t'));
push(mkchar('a'));
push(mkchar('n'));
push(mkchar('t'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push_local(arg_symbol);
tailcall(proc_error,2);
} else {
prim0_abort();
}
}
}
}
}
}
answer();
}

case proc_read_symbol:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
prim0_peek_char();
call(proc_read_symbol_1,1);
prim2_cons();
answer();
}

case proc_read_symbol_1:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
call(proc_eofP,1);
if (false != pop ()) {
push(nil);
} else {
push_local(arg_c);
call(proc_whitespaceP,1);
if (false != pop ()) {
push(nil);
} else {
push_local(arg_c);
call(proc_punctuationP,1);
if (false != pop ()) {
push(nil);
} else {
push(true);
if (false != pop ()) {
prim0_read_char();
pop();
push_local(arg_c);
tailcall(proc_read_symbol,1);
} else {
prim0_abort();
}
}
}
}
answer();
}

case proc_read_string_literal:
{
enum { arg_c, };
assert(sp-bp==1);
push_local(arg_c);
call(proc_eofP,1);
if (false != pop ()) {
push(mkchar('p'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('m'));
push(mkchar('a'));
push(mkchar('t'));
push(mkchar('u'));
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('-'));
push(mkchar('e'));
push(mkchar('o'));
push(mkchar('f'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('a'));
push(mkchar('d'));
push(mkchar('-'));
push(mkchar('s'));
push(mkchar('t'));
push(mkchar('r'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('g'));
push(mkchar('-'));
push(mkchar('l'));
push(mkchar('i'));
push(mkchar('t'));
push(mkchar('e'));
push(mkchar('r'));
push(mkchar('a'));
push(mkchar('l'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_error,2);
} else {
push_local(arg_c);
push(mkchar('"'));
prim2_EEP();
if (false != pop ()) {
push(nil);
} else {
push_local(arg_c);
push(mkchar('\\'));
prim2_EEP();
if (false != pop ()) {
prim0_read_char();
prim0_read_char();
call(proc_read_string_literal,1);
prim2_cons();
} else {
push(true);
if (false != pop ()) {
push_local(arg_c);
prim0_read_char();
call(proc_read_string_literal,1);
prim2_cons();
} else {
prim0_abort();
}
}
}
}
answer();
}

case proc_main:
{
assert(sp-bp==0);
push(mkchar('m'));
push(mkchar('a'));
push(mkchar('i'));
push(mkchar('n'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push(nil);
prim2_cons();
push(nil);
call(proc_read,0);
push(nil);
call(proc_repl,2);
tailcall(proc_eval_expr,3);
answer();
}

case proc_repl:
{
enum { arg_form, arg_procedures, };
assert(sp-bp==2);
push_local(arg_form);
call(proc_eofP,1);
if (false != pop ()) {
push_local(arg_procedures);
} else {
push_local(arg_form);
call(proc_defineP,1);
if (false != pop ()) {
call(proc_read,0);
push_local(arg_form);
call(proc_caadr,1);
call(proc_list1,1);
push_local(arg_form);
call(proc_cdadr,1);
push_local(arg_form);
call(proc_cddr,1);
prim2_cons();
call(proc_list1,1);
push_local(arg_procedures);
call(proc_bind,3);
tailcall(proc_repl,2);
} else {
push(true);
if (false != pop ()) {
push_local(arg_form);
push(nil);
push_local(arg_procedures);
call(proc_eval_expr,3);
call(proc_write,1);
pop();
push(mkchar('\n'));
prim1_write_char();
pop();
call(proc_read,0);
push_local(arg_procedures);
tailcall(proc_repl,2);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_defineP:
{
enum { arg_form, };
assert(sp-bp==1);
push_local(arg_form);
prim1_pairP();
if (false != pop ()) {
push_local(arg_form);
prim1_car();
push(mkchar('d'));
push(mkchar('e'));
push(mkchar('f'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
tailcall(proc_sameP,2);
} else {
push(true);
if (false != pop ()) {
push(false);
} else {
prim0_abort();
}
}
answer();
}

case proc_eval_expr:
{
enum { arg_expr, arg_env, arg_procedures, };
assert(sp-bp==3);
push_local(arg_expr);
prim1_symbolP();
if (false != pop ()) {
push_local(arg_expr);
push_local(arg_env);
tailcall(proc_value,2);
} else {
push(false);
push_local(arg_expr);
prim1_pairP();
prim2_EEP();
if (false != pop ()) {
push_local(arg_expr);
} else {
push_local(arg_expr);
prim1_car();
push(mkchar('q'));
push(mkchar('u'));
push(mkchar('o'));
push(mkchar('t'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_expr);
tailcall(proc_cadr,1);
} else {
push_local(arg_expr);
prim1_car();
push(mkchar('c'));
push(mkchar('o'));
push(mkchar('n'));
push(mkchar('d'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_expr);
prim1_cdr();
push_local(arg_env);
push_local(arg_procedures);
tailcall(proc_eval_cond,3);
} else {
push(true);
if (false != pop ()) {
push_local(arg_expr);
prim1_car();
push_local(arg_expr);
prim1_car();
push_local(arg_procedures);
call(proc_lookup,2);
push_local(arg_expr);
prim1_cdr();
push_local(arg_env);
push_local(arg_procedures);
call(proc_eval_exprs,3);
push_local(arg_procedures);
tailcall(proc_apply_proc,4);
} else {
prim0_abort();
}
}
}
}
}
answer();
}

case proc_apply_proc:
{
enum { arg_rator, arg_slot, arg_args, arg_procedures, };
assert(sp-bp==4);
push(false);
push_local(arg_slot);
prim2_EEP();
if (false != pop ()) {
push_local(arg_rator);
push_local(arg_args);
tailcall(proc_apply_prim,2);
} else {
push(true);
if (false != pop ()) {
push_local(arg_slot);
call(proc_cdar,1);
push_local(arg_slot);
call(proc_caar,1);
push_local(arg_args);
push(nil);
call(proc_bind,3);
push_local(arg_procedures);
tailcall(proc_eval_seq,3);
} else {
prim0_abort();
}
}
answer();
}

case proc_eval_exprs:
{
enum { arg_exprs, arg_env, arg_procedures, };
assert(sp-bp==3);
push_local(arg_exprs);
prim1_nullP();
if (false != pop ()) {
push(nil);
} else {
push(true);
if (false != pop ()) {
push_local(arg_exprs);
prim1_car();
push_local(arg_env);
push_local(arg_procedures);
call(proc_eval_expr,3);
push_local(arg_exprs);
prim1_cdr();
push_local(arg_env);
push_local(arg_procedures);
call(proc_eval_exprs,3);
prim2_cons();
} else {
prim0_abort();
}
}
answer();
}

case proc_eval_seq:
{
enum { arg_exprs, arg_env, arg_procedures, };
assert(sp-bp==3);
push_local(arg_exprs);
prim1_nullP();
if (false != pop ()) {
push(false);
} else {
push_local(arg_exprs);
prim1_cdr();
prim1_nullP();
if (false != pop ()) {
push_local(arg_exprs);
prim1_car();
push_local(arg_env);
push_local(arg_procedures);
tailcall(proc_eval_expr,3);
} else {
push(true);
if (false != pop ()) {
push_local(arg_exprs);
prim1_car();
push_local(arg_env);
push_local(arg_procedures);
call(proc_eval_expr,3);
pop();
push_local(arg_exprs);
prim1_cdr();
push_local(arg_env);
push_local(arg_procedures);
tailcall(proc_eval_seq,3);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_eval_cond:
{
enum { arg_clauses, arg_env, arg_procedures, };
assert(sp-bp==3);
push_local(arg_clauses);
prim1_nullP();
if (false != pop ()) {
push(mkchar('c'));
push(mkchar('o'));
push(mkchar('n'));
push(mkchar('d'));
push(mkchar('-'));
push(mkchar('f'));
push(mkchar('e'));
push(mkchar('l'));
push(mkchar('l'));
push(mkchar('-'));
push(mkchar('o'));
push(mkchar('f'));
push(mkchar('f'));
push(mkchar('-'));
push(mkchar('e'));
push(mkchar('n'));
push(mkchar('d'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push_local(arg_clauses);
tailcall(proc_error,2);
} else {
push_local(arg_clauses);
call(proc_caar,1);
push_local(arg_env);
push_local(arg_procedures);
call(proc_eval_expr,3);
if (false != pop ()) {
push_local(arg_clauses);
call(proc_cdar,1);
push_local(arg_env);
push_local(arg_procedures);
tailcall(proc_eval_seq,3);
} else {
push(true);
if (false != pop ()) {
push_local(arg_clauses);
prim1_cdr();
push_local(arg_env);
push_local(arg_procedures);
tailcall(proc_eval_cond,3);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_bind:
{
enum { arg_vars, arg_args, arg_env, };
assert(sp-bp==3);
push_local(arg_vars);
push_local(arg_args);
call(proc_same_lengthP,2);
if (false != pop ()) {
push_local(arg_vars);
push_local(arg_args);
prim2_cons();
push_local(arg_env);
prim2_cons();
} else {
push(true);
if (false != pop ()) {
push(mkchar('b'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('d'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push_local(arg_vars);
push_local(arg_args);
call(proc_list2,2);
tailcall(proc_error,2);
} else {
prim0_abort();
}
}
answer();
}

case proc_value:
{
enum { arg_name, arg_env, };
assert(sp-bp==2);
push_local(arg_name);
push_local(arg_name);
push_local(arg_env);
call(proc_lookup,2);
tailcall(proc_value1,2);
answer();
}

case proc_value1:
{
enum { arg_name, arg_slot, };
assert(sp-bp==2);
push_local(arg_slot);
if (false != pop ()) {
push_local(arg_slot);
prim1_car();
} else {
push(true);
if (false != pop ()) {
push(mkchar('u'));
push(mkchar('n'));
push(mkchar('b'));
push(mkchar('o'));
push(mkchar('u'));
push(mkchar('n'));
push(mkchar('d'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push_local(arg_name);
tailcall(proc_error,2);
} else {
prim0_abort();
}
}
answer();
}

case proc_lookup:
{
enum { arg_name, arg_env, };
assert(sp-bp==2);
push_local(arg_env);
prim1_nullP();
if (false != pop ()) {
push(false);
} else {
push(true);
if (false != pop ()) {
push_local(arg_name);
push_local(arg_env);
call(proc_caar,1);
push_local(arg_env);
call(proc_cdar,1);
push_local(arg_env);
tailcall(proc_lookup1,4);
} else {
prim0_abort();
}
}
answer();
}

case proc_lookup1:
{
enum { arg_name, arg_vars, arg_vals, arg_env, };
assert(sp-bp==4);
push_local(arg_vars);
prim1_nullP();
if (false != pop ()) {
push_local(arg_name);
push_local(arg_env);
prim1_cdr();
tailcall(proc_lookup,2);
} else {
push_local(arg_name);
push_local(arg_vars);
prim1_car();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_vals);
} else {
push(true);
if (false != pop ()) {
push_local(arg_name);
push_local(arg_vars);
prim1_cdr();
push_local(arg_vals);
prim1_cdr();
push_local(arg_env);
tailcall(proc_lookup1,4);
} else {
prim0_abort();
}
}
}
answer();
}

case proc_apply_prim:
{
enum { arg_proc, arg_args, };
assert(sp-bp==2);
push_local(arg_proc);
push(mkchar('='));
push(mkchar('='));
push(mkchar('?'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
push_local(arg_args);
call(proc_cadr,1);
prim2_EEP();
} else {
push_local(arg_proc);
push(mkchar('c'));
push(mkchar('o'));
push(mkchar('n'));
push(mkchar('s'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
push_local(arg_args);
call(proc_cadr,1);
prim2_cons();
} else {
push_local(arg_proc);
push(mkchar('c'));
push(mkchar('a'));
push(mkchar('r'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_car();
} else {
push_local(arg_proc);
push(mkchar('c'));
push(mkchar('d'));
push(mkchar('r'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_cdr();
} else {
push_local(arg_proc);
push(mkchar('n'));
push(mkchar('u'));
push(mkchar('l'));
push(mkchar('l'));
push(mkchar('?'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_nullP();
} else {
push_local(arg_proc);
push(mkchar('p'));
push(mkchar('a'));
push(mkchar('i'));
push(mkchar('r'));
push(mkchar('?'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_pairP();
} else {
push_local(arg_proc);
push(mkchar('s'));
push(mkchar('y'));
push(mkchar('m'));
push(mkchar('b'));
push(mkchar('o'));
push(mkchar('l'));
push(mkchar('?'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_symbolP();
} else {
push_local(arg_proc);
push(mkchar('s'));
push(mkchar('t'));
push(mkchar('r'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('g'));
push(mkchar('?'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_stringP();
} else {
push_local(arg_proc);
push(mkchar('b'));
push(mkchar('o'));
push(mkchar('o'));
push(mkchar('l'));
push(mkchar('e'));
push(mkchar('a'));
push(mkchar('n'));
push(mkchar('?'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_booleanP();
} else {
push_local(arg_proc);
push(mkchar('c'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('r'));
push(mkchar('?'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_charP();
} else {
push_local(arg_proc);
push(mkchar('w'));
push(mkchar('r'));
push(mkchar('i'));
push(mkchar('t'));
push(mkchar('e'));
push(mkchar('-'));
push(mkchar('c'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('r'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_write_char();
} else {
push_local(arg_proc);
push(mkchar('r'));
push(mkchar('e'));
push(mkchar('a'));
push(mkchar('d'));
push(mkchar('-'));
push(mkchar('c'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('r'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
prim0_read_char();
} else {
push_local(arg_proc);
push(mkchar('p'));
push(mkchar('e'));
push(mkchar('e'));
push(mkchar('k'));
push(mkchar('-'));
push(mkchar('c'));
push(mkchar('h'));
push(mkchar('a'));
push(mkchar('r'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
prim0_peek_char();
} else {
push_local(arg_proc);
push(mkchar('e'));
push(mkchar('x'));
push(mkchar('p'));
push(mkchar('l'));
push(mkchar('o'));
push(mkchar('d'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_explode();
} else {
push_local(arg_proc);
push(mkchar('i'));
push(mkchar('m'));
push(mkchar('p'));
push(mkchar('l'));
push(mkchar('o'));
push(mkchar('d'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_implode();
} else {
push_local(arg_proc);
push(mkchar('s'));
push(mkchar('t'));
push(mkchar('r'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('g'));
push(mkchar('-'));
push(mkchar('>'));
push(mkchar('l'));
push(mkchar('i'));
push(mkchar('s'));
push(mkchar('t'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_string_Glist();
} else {
push_local(arg_proc);
push(mkchar('l'));
push(mkchar('i'));
push(mkchar('s'));
push(mkchar('t'));
push(mkchar('-'));
push(mkchar('>'));
push(mkchar('s'));
push(mkchar('t'));
push(mkchar('r'));
push(mkchar('i'));
push(mkchar('n'));
push(mkchar('g'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_list_Gstring();
} else {
push_local(arg_proc);
push(mkchar('e'));
push(mkchar('o'));
push(mkchar('f'));
push(mkchar('-'));
push(mkchar('o'));
push(mkchar('b'));
push(mkchar('j'));
push(mkchar('e'));
push(mkchar('c'));
push(mkchar('t'));
push(mkchar('?'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
push_local(arg_args);
prim1_car();
prim1_eof_objectP();
} else {
push_local(arg_proc);
push(mkchar('a'));
push(mkchar('b'));
push(mkchar('o'));
push(mkchar('r'));
push(mkchar('t'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
call(proc_sameP,2);
if (false != pop ()) {
prim0_abort();
} else {
push(true);
if (false != pop ()) {
push(mkchar('u'));
push(mkchar('n'));
push(mkchar('k'));
push(mkchar('n'));
push(mkchar('o'));
push(mkchar('w'));
push(mkchar('n'));
push(mkchar('-'));
push(mkchar('p'));
push(mkchar('r'));
push(mkchar('o'));
push(mkchar('c'));
push(mkchar('e'));
push(mkchar('d'));
push(mkchar('u'));
push(mkchar('r'));
push(mkchar('e'));
push(nil);
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim2_cons();
prim1_implode();
push_local(arg_proc);
tailcall(proc_error,2);
} else {
prim0_abort();
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
answer();
}

    default: die ("Bug: unknown pc");
  }
}
int main (void) {
  run (proc_main, 0);
  return 0;
}
