#!/bin/sh
cat "$@" eof - | stable/terp
