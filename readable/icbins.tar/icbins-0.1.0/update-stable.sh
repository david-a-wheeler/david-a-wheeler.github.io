#!/bin/sh
make &&
mv stable tmp &&
mkdir stable &&
cp src/library.scm src/terp.scm src/compiler.scm stable/ &&
cp work/comp.comp.c stable/compiler.c &&
cp work/comp.terp.c stable/terp.c
