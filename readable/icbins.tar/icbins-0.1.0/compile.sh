#!/bin/sh
binfile=$1
shift

cat "$@" | stable/compiler >$binfile.c &&
cc $binfile.c -o $1

rm -f $binfile.c
