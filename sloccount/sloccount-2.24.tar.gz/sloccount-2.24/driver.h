/* driver: given a list of files on the command line,
   count the SLOC in each one.

   (C) Copyright 2002 David A. Wheeler
   Covered by the GNU GPL, version 2.
   This version 2002-08-24.
   This is part of "SLOCCount"; see the documentation for details.

*/

#ifndef DRIVER_H
#define DRIVER_H

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/* Not all C compilers support a boolean type, so for portability's sake,
   we'll fake it. */
#define BOOLEAN int
#define TRUE 1
#define FALSE 0


/* Globals */
unsigned long sloc;           /* For current file */
unsigned long line_number;    /* Of current file */
char *filename;               /* Name of current file */

unsigned long total_sloc;     /* For all files seen */



#endif
