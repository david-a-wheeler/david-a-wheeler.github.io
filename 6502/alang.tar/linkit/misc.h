
void error();

void fatal();


