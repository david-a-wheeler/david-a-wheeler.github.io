
unsigned allocate_memory(/* unsigned, unsigned */);

unsigned to_real_location(/* unsigned */);

void set_offset(/* unsigned unsigned */);

