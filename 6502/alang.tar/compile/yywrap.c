
yywrap()
{
return(1); /* end processing normally */
}
