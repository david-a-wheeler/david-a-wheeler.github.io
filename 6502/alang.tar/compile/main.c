
int main(argc, argv)
int argc;
char **argv;
{
 return( yyparse() );
}
