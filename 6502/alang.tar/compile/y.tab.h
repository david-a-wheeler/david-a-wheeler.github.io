
typedef union  {
       char *y_str;
       int y_num;
       } YYSTYPE;
extern YYSTYPE yylval;
# define Identifier 257
# define Constant 258
# define T_INT 259
# define T_CHAR 260
# define STRING 261
# define ASSEMBLE 262
