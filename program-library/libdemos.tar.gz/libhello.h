/* libhello.h - demonstrate library use. */


void hello(void);

