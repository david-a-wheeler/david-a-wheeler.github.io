static void a()
{
  printf(_("a"));
  printf(_("b"
           "c"));
  printf("a");
  printf("b"
         "c");
}
