
// Buggy �

main() {
 char x[1];
 strcpy(x,"aaaa�");
}

